import assert from "node:assert/strict";
import test from "node:test";
import { createHash } from "node:crypto";
import {
  createResearchSnapshot,
  replayResearchSlice,
  RESEARCH_SNAPSHOT_SCHEMA,
} from "./research-bridge.ts";
import type { ResearchSnapshot } from "./research-bridge.ts";
import { DEFAULT_CONFIG, sampleSlice } from "./penteract.ts";
import type { FiveStrings, SliceConfig } from "./penteract.ts";
import { importRawWord } from "./raw-words.ts";
import type { WordSources } from "./raw-words.ts";
import { encodePixel160, encodeStatePixel160, pixelHex } from "./pixel.ts";
import { MAX_TICK } from "./dynamics.ts";

const lengths = [4, 4, 3, 3, 3];
const config = (patch: Partial<SliceConfig> = {}): SliceConfig => ({
  ...DEFAULT_CONFIG,
  words: lengths.map(String) as FiveStrings,
  tick: "7",
  axes: [0, 1],
  couplingAxis: 4,
  fixed: ["0", "0", "1", "1", "0"],
  origin: ["0", "0"],
  size: 2,
  ...patch,
});
function bytes(axis: number, count: number): Uint8Array {
  const result = new Uint8Array(count * 20);
  for (let index = 0; index < count; index++)
    result.set(
      encodePixel160(
        encodeStatePixel160({
          q: (1n << BigInt(79 - axis)) ^ BigInt(index * 29 + axis + 3),
          p: (1n << BigInt(70 - index)) ^ BigInt(index * 53 + axis + 11),
        }),
      ),
      index * 20,
    );
  return result;
}
async function fixtures(): Promise<WordSources> {
  const imported = await Promise.all(
    lengths.map((count, axis) =>
      importRawWord(bytes(axis, count), { name: `fixture-${axis}.bin`, format: "russl-be" }),
    ),
  );
  return imported as unknown as WordSources;
}
const copy = (snapshot: ResearchSnapshot): any => JSON.parse(JSON.stringify(snapshot));

test("generated-only snapshot replays exact v2 states, coordinates, invariants and selected inverse witness", () => {
  const slice = sampleSlice(config()),
    snapshot = createResearchSnapshot(slice, { selectedIndex: 3, inverseWitness: true }),
    replay = replayResearchSlice(JSON.parse(JSON.stringify(snapshot)));
  assert.equal(snapshot.schema, RESEARCH_SNAPSHOT_SCHEMA);
  assert.deepEqual(snapshot.manifest, slice.manifest);
  assert.equal(snapshot.manifest.schema, "RUSSL-five-word-cube/2");
  assert.deepEqual(replay.pixelBytes, slice.pixelBytes);
  assert.deepEqual(replay.cells, slice.cells);
  assert.equal(replay.checks.observedCells, 4);
  assert.equal(replay.checks.evaluatedCells, 8);
  assert.equal(replay.checks.inverseVerified, true);
  assert.equal(replay.selected!.pixelHex, pixelHex(slice.cells[3].pixel));
  assert.equal(replay.selected!.partnerAddress, slice.cells[3].partnerIndex!.toString());
  assert.equal(replay.selected!.inverseVerified, true);
  assert.equal(replay.sourceHashScope.importedWords.length, 0);
  assert.match(replay.sourceHashScope.explanation, /generated word recipes/);
  assert.doesNotThrow(() =>
    JSON.stringify({
      checks: replay.checks,
      sourceHashScope: replay.sourceHashScope,
      selected: replay.selected,
    }),
  );
});

test("all imported words replay step 7 without original bytes and hashes remain unverified identifiers", async () => {
  const sources = await fixtures(),
    slice = sampleSlice(config(), sources),
    snapshot = createResearchSnapshot(slice),
    replay = replayResearchSlice(snapshot);
  assert.deepEqual(replay.pixelBytes, slice.pixelBytes);
  assert.deepEqual(replay.cells, slice.cells);
  assert.equal(replay.sourceHashScope.importedWords.length, 5);
  assert.equal(replay.sourceHashScope.verifiedFromOriginalBytes, false);
  assert.match(replay.sourceHashScope.explanation, /not verified from bounded witnesses/);
  for (const source of replay.sourceHashScope.importedWords) {
    assert.equal(source.sourceSha256, sources[source.axis]!.sha256);
    assert.equal(source.canonicalSha256, sources[source.axis]!.canonicalSha256);
    assert.equal(source.originalHashesVerified, false);
    assert(source.witnessUnits < Number(sources[source.axis]!.unitCount));
  }
  const modifiedHash = copy(snapshot);
  modifiedHash.manifest.words[0].sourceSha256 = "f".repeat(64);
  const other = replayResearchSlice(modifiedHash);
  assert.equal(other.sourceHashScope.importedWords[0].sourceSha256, "f".repeat(64));
  assert.equal(other.sourceHashScope.importedWords[0].originalHashesVerified, false);
  assert.equal("sourceBytes" in snapshot, false);
  assert.equal("canonicalBytes" in snapshot, false);
});

test("mixed generated and imported axes independently reconstruct their actual source units", async () => {
  const imported = await fixtures(),
    mixed: WordSources = [imported[0], null, null, imported[3], imported[4]],
    slice = sampleSlice(config(), mixed),
    snapshot = createResearchSnapshot(slice),
    replay = replayResearchSlice(snapshot);
  assert.deepEqual(replay.cells, slice.cells);
  assert.deepEqual(replay.pixelBytes, slice.pixelBytes);
  assert.deepEqual(
    replay.sourceHashScope.importedWords.map((word) => word.axis),
    [0, 3, 4],
  );
  assert.deepEqual(
    (snapshot.manifest.words as any[]).map((word) => word.source),
    ["imported", "generated", "generated", "imported", "imported"],
  );
});

test("native partial final unit and an odd boundary replay without losing high-padding semantics", async () => {
  const native = Uint8Array.from({ length: 41 }, (_, index) => (index * 17 + 31) & 255),
    source = await importRawWord(native, { name: "ceiling-native.bin", format: "appliance-le" }),
    sources: WordSources = [null, null, null, null, source];
  const slice = sampleSlice(config({ fixed: ["0", "0", "1", "1", "2"] }), sources),
    snapshot = createResearchSnapshot(slice, { selectedIndex: 0 }),
    replay = replayResearchSlice(snapshot);
  assert.equal(source.paddingBits, 152);
  assert.deepEqual(replay.cells, slice.cells);
  assert(replay.cells.every((cell) => cell.partnerState === null));
  const badPadding = copy(snapshot);
  badPadding.manifest.wordWitnesses[0].units[0].pixelHex =
    "01" + badPadding.manifest.wordWitnesses[0].units[0].pixelHex.slice(2);
  assert.throws(() => replayResearchSlice(badPadding), /nonzero high padding/);
});

test("raw witness coverage includes off-slice pair dependencies and cannot silently regenerate missing axes", async () => {
  const sources = await fixtures(),
    snapshot = createResearchSnapshot(sampleSlice(config(), sources));
  const missingPartner = copy(snapshot);
  missingPartner.manifest.wordWitnesses[4].units.pop();
  assert.throws(() => replayResearchSlice(missingPartner), /coverage/);
  const missingAxis = copy(snapshot);
  missingAxis.manifest.wordWitnesses.pop();
  assert.throws(() => replayResearchSlice(missingAxis), /one complete word witness/);
  const duplicate = copy(snapshot);
  duplicate.manifest.wordWitnesses[0].units[1] = duplicate.manifest.wordWitnesses[0].units[0];
  assert.throws(() => replayResearchSlice(duplicate), /sorted, unique/);
  const wrongDependency = copy(snapshot);
  wrongDependency.manifest.wordWitnesses[4].units[1].index = "2";
  assert.throws(() => replayResearchSlice(wrongDependency), /unused unit/);
  const extraAxis = copy(snapshot);
  extraAxis.manifest.wordWitnesses[1].axis = 0;
  assert.throws(() => replayResearchSlice(extraAxis), /witness axis/);
});

test("modified witness bits, exported pixels and full states each fail reconstruction", async () => {
  const sources = await fixtures(),
    snapshot = createResearchSnapshot(sampleSlice(config(), sources));
  const changedWord = copy(snapshot);
  changedWord.manifest.wordWitnesses[0].units[0].pixelHex =
    "00" + changedWord.manifest.wordWitnesses[0].units[0].pixelHex.slice(2);
  assert.throws(() => replayResearchSlice(changedWord), /Pixel160 payload/);
  const changedPayload = copy(snapshot);
  changedPayload.pixelPayloadHex = "ff" + changedPayload.pixelPayloadHex.slice(2);
  assert.throws(() => replayResearchSlice(changedPayload), /Pixel160 payload/);
  const changedState = copy(snapshot);
  changedState.manifest.fullStatesHex[0].q = "0".repeat(20);
  assert.throws(() => replayResearchSlice(changedState), /full states/);
});

test("the profile rejects old GF100 and research terminal synthetic 64-bit packing", () => {
  const snapshot = createResearchSnapshot(sampleSlice(config()));
  for (const mutate of [
    (value: any) => {
      value.manifest.field.id = "gf100";
    },
    (value: any) => {
      value.manifest.field.degree = 100;
    },
    (value: any) => {
      value.manifest.observation.profile = "q64-p64-padding32";
    },
    (value: any) => {
      value.manifest.observation.map = "(q<<96)|(p<<32)";
    },
    (value: any) => {
      value.manifest.dynamics.K = [
        ["9", "1"],
        ["1", "9"],
      ];
    },
    (value: any) => {
      value.manifest.generator.cellCombiner = "synthetic terminal packing";
    },
  ]) {
    const invalid = copy(snapshot);
    mutate(invalid);
    assert.throws(() => replayResearchSlice(invalid), /differs from the declared GF80/);
  }
});

test("imported descriptor source width, unit count, hashes and format are checked before use", async () => {
  const snapshot = createResearchSnapshot(sampleSlice(config(), await fixtures()));
  for (const patch of [
    { sourceBits: 639 },
    { sourceByteLength: 79 },
    { paddingBits: 1 },
    { sourceFormat: "guess" },
    { unitCount: "3" },
    { sourceSha256: "not-a-hash" },
    { originalName: "../word.bin" },
    { entry: "word.bin" },
  ]) {
    const invalid = copy(snapshot);
    Object.assign(invalid.manifest.words[0], patch);
    assert.throws(() => replayResearchSlice(invalid));
  }
});

test("all slice metadata and generated recipes must agree with the exact configuration", () => {
  const snapshot = createResearchSnapshot(sampleSlice(config()));
  for (const mutate of [
    (value: any) => {
      value.manifest.domain.cells = "1";
    },
    (value: any) => {
      value.manifest.slice.evaluatedCells = 4;
    },
    (value: any) => {
      value.manifest.words[0].coefficientsHex.aq = "0".repeat(20);
    },
    (value: any) => {
      value.manifest.config.axes = [0, 0];
    },
    (value: any) => {
      value.manifest.config.tick = "0x7";
    },
    (value: any) => {
      value.manifest.config.size = 64;
    },
    (value: any) => {
      value.manifest.config.tick = (MAX_TICK + 1n).toString();
    },
    (value: any) => {
      value.manifest.checks.invariantPreserved = false;
    },
    (value: any) => {
      value.manifest.schema = "RUSSL-five-word-cube/3";
    },
  ]) {
    const invalid = copy(snapshot);
    mutate(invalid);
    assert.throws(() => replayResearchSlice(invalid));
  }
});

test("maximum tick and a 32x32 tile replay within bounded exact dynamics", () => {
  const cfg = config({ words: ["64", "64", "3", "3", "3"], tick: MAX_TICK.toString(), size: 32 }),
    slice = sampleSlice(cfg),
    snapshot = createResearchSnapshot(slice),
    replay = replayResearchSlice(snapshot);
  assert.equal(replay.cells.length, 1024);
  assert.equal(replay.checks.evaluatedCells, 2048);
  assert.equal(replay.checks.inverseVerified, true);
  assert.deepEqual(replay.pixelBytes, slice.pixelBytes);
});

test("malformed transfer wrappers, oversized payloads, sparse arrays and executable values are rejected", () => {
  const snapshot = createResearchSnapshot(sampleSlice(config()));
  assert.throws(
    () => replayResearchSlice({ ...snapshot, schema: "terminal-ledger/64" }),
    /Unsupported research/,
  );
  assert.throws(
    () => replayResearchSlice({ ...snapshot, pixelPayloadHex: snapshot.pixelPayloadHex.slice(2) }),
    /exactly/,
  );
  assert.throws(
    () => replayResearchSlice({ ...snapshot, pixelPayloadHex: "0".repeat(2 * 1024 * 1024) }),
    /2 MiB/,
  );
  assert.throws(
    () => replayResearchSlice({ ...snapshot, executable: () => undefined }),
    /serializable/,
  );
  const sparse = copy(snapshot);
  delete sparse.manifest.words[0];
  assert.throws(() => replayResearchSlice(sparse), /sparse/);
  const cycle: any = { ...snapshot };
  cycle.parent = cycle;
  assert.throws(() => replayResearchSlice(cycle), /cycles/);
  const accessor: any = { ...snapshot };
  Object.defineProperty(accessor, "instruction", {
    get() {
      throw new Error("getter must not run");
    },
    enumerable: true,
  });
  assert.throws(() => replayResearchSlice(accessor), /accessors/);
  let callbackRan = false;
  const arrayAccessor = copy(snapshot);
  Object.defineProperty(arrayAccessor.manifest.words, "0", {
    get() {
      callbackRan = true;
      return snapshot.manifest.words;
    },
    enumerable: true,
  });
  assert.throws(() => replayResearchSlice(arrayAccessor), /accessors/);
  assert.equal(callbackRan, false);
  const arrayToJson = copy(snapshot);
  arrayToJson.manifest.words.toJSON = () => {
    callbackRan = true;
    return [];
  };
  assert.throws(() => replayResearchSlice(arrayToJson), /extra or executable/);
  assert.equal(callbackRan, false);
  const inheritedToJson = copy(snapshot);
  Object.setPrototypeOf(inheritedToJson.manifest.words, {
    toJSON() {
      callbackRan = true;
      return [];
    },
  });
  assert.throws(() => replayResearchSlice(inheritedToJson), /plain JSON arrays/);
  assert.equal(callbackRan, false);
});

test("snapshot output is copied, self-contained and cannot be altered through the source slice", () => {
  const slice = sampleSlice(config()),
    snapshot = createResearchSnapshot(slice),
    expected = snapshot.pixelPayloadHex;
  slice.pixelBytes.fill(0);
  slice.manifest.fullStatesHex[0].q = "0".repeat(20);
  assert.equal(snapshot.pixelPayloadHex, expected);
  assert.doesNotThrow(() => replayResearchSlice(snapshot));
  assert.throws(() => createResearchSnapshot(slice), /Pixel160 payload|full states/);
});

test("selected inverse witness indices, states, coordinates and claimed verification are checked", () => {
  const slice = sampleSlice(config()),
    snapshot = createResearchSnapshot(slice, { selectedIndex: 0 });
  assert.throws(() => createResearchSnapshot(slice, { selectedIndex: 4 }), /outside/);
  assert.throws(
    () => createResearchSnapshot(slice, { inverseWitness: true }),
    /requires a selected/,
  );
  assert.throws(
    () => createResearchSnapshot(slice, { selectedIndex: 0, inverseWitness: false }),
    /disagrees/,
  );
  for (const patch of [
    { rowMajorIndex: 4 },
    { address: "0" },
    { inverseVerified: false },
    { qHex: "0".repeat(20) },
    { coordinates: ["9", "9", "9", "9", "9"] },
  ]) {
    const invalid = copy(snapshot);
    Object.assign(invalid.selected, patch);
    assert.throws(() => replayResearchSlice(invalid));
  }
});

test("zero tick and independent cells retain exact source identity and inverse checks", async () => {
  const sources = await fixtures();
  for (const patch of [
    { tick: "0" },
    { mode: "cell" as const },
    { mode: "cell" as const, tick: "0" },
  ]) {
    const slice = sampleSlice(config(patch), sources),
      snapshot = createResearchSnapshot(slice),
      replay = replayResearchSlice(snapshot);
    assert.deepEqual(replay.cells, slice.cells);
    assert.equal(replay.checks.inverseVerified, true);
  }
});

test("an export-enriched manifest preserves its declared payload hash without claiming a digest check", () => {
  const slice = sampleSlice(config()),
    snapshot = createResearchSnapshot(slice),
    digest = createHash("sha256").update(slice.pixelBytes).digest("hex");
  snapshot.manifest.sha256 = { pixelPayloadBE: digest };
  snapshot.manifest.checks = {
    invariantPreserved: true,
    selectedInverseReplay: true,
    selectedInverseWitness: {
      addressHex: slice.cells[3].index.toString(16).padStart(20, "0"),
      coordinates: slice.cells[3].coords.map(String),
      column: 1,
      row: 1,
      tick: slice.config.tick,
    },
  };
  const replay = replayResearchSlice(snapshot);
  assert.equal(replay.checks.declaredPixelPayloadSha256, digest);
  assert.equal(replay.checks.declaredPixelPayloadHashVerified, false);
  const bad = copy(snapshot);
  bad.manifest.sha256.pixelPayloadBE = "BAD";
  assert.throws(() => replayResearchSlice(bad), /canonical SHA-256/);
  const badInverse = copy(snapshot);
  badInverse.manifest.checks.selectedInverseWitness.coordinates[4] = "2";
  assert.throws(() => replayResearchSlice(badInverse), /inverse witness address/);
});
