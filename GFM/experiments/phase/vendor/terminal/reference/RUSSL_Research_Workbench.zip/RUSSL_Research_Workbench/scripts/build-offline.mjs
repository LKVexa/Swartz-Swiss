import "./build-research-terminal.mjs";
import { build } from "vite";
import react from "@vitejs/plugin-react";
import tailwind from "@tailwindcss/vite";
import { writeFile } from "node:fs/promises";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const result = await build({
  root,
  configFile: false,
  publicDir: false,
  define: { "process.env.NODE_ENV": JSON.stringify("production") },
  resolve: { alias: { "@": path.join(root, "src") } },
  plugins: [react(), tailwind()],
  build: {
    write: false,
    minify: true,
    cssCodeSplit: false,
    lib: {
      entry: path.join(root, "src/offline-workbench.tsx"),
      formats: ["iife"],
      name: "RusslWorkbench",
    },
  },
});
const outputs = (Array.isArray(result) ? result : [result]).flatMap((value) => value.output);
const script = outputs
  .filter((value) => value.type === "chunk")
  .map((value) => value.code)
  .join("\n")
  .replace(/<\/script/gi, "<\\/script");
const css = outputs
  .filter((value) => value.type === "asset" && value.fileName.endsWith(".css"))
  .map((value) => value.source)
  .join("\n");
if (!script || !css) throw new Error("The standalone build requires both code and styles.");
const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#10120e"><title>RUSSL word workbench</title><style>${css}</style></head>
<body><div id="workbench"></div><noscript>This workbench needs JavaScript enabled.</noscript><script>${script}</script></body></html>
`;
await writeFile(path.join(root, "standalone.html"), html);
console.log("Standalone workbench saved to standalone.html");
