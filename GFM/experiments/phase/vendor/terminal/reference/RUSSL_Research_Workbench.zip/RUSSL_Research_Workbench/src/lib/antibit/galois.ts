export const POLY: Record<number, bigint> = {
  2: 0b11n,
  3: 0b11n,
  4: 0b11n,
  8: 0b11101n,
  16: 0b101101n,
  32: 0b10101111n,
};

export type FieldReport = {
  bits: number;
  polynomial: string;
  element: string;
  ringNegation: string;
  fieldNegation: string;
  fieldSum: string;
  inverse: string;
  product: string;
  negationAgrees: boolean;
  inverseHolds: boolean;
  frobeniusHolds: boolean;
  holds: boolean;
};

export function polynomial(bits: number): string {
  const low = POLY[bits];
  const parts = [`x^${bits}`];
  for (let degree = bits - 1; degree >= 0; degree--) {
    if ((low & (1n << BigInt(degree))) === 0n) continue;
    parts.push(degree === 0 ? "1" : degree === 1 ? "x" : `x^${degree}`);
  }
  return parts.join(" + ");
}

export function gfAdd(left: bigint, right: bigint): bigint {
  return left ^ right;
}

export function gfMul(left: bigint, right: bigint, bits: number, poly = POLY[bits]): bigint {
  const mask = (1n << BigInt(bits)) - 1n;
  const top = 1n << BigInt(bits - 1);
  let result = 0n;
  let factor = left & mask;
  let other = right & mask;
  while (other) {
    if (other & 1n) result ^= factor;
    other >>= 1n;
    const carry = factor & top;
    factor = (factor << 1n) & mask;
    if (carry) factor ^= poly;
  }
  return result;
}

export function gfPow(base: bigint, exponent: bigint, bits: number, poly = POLY[bits]): bigint {
  let result = 1n;
  let square = base;
  let power = exponent;
  while (power) {
    if (power & 1n) result = gfMul(result, square, bits, poly);
    square = gfMul(square, square, bits, poly);
    power >>= 1n;
  }
  return result;
}

export function gfInv(element: bigint, bits: number, poly = POLY[bits]): bigint | null {
  const mask = (1n << BigInt(bits)) - 1n;
  const value = element & mask;
  if (value === 0n) return null;
  return gfPow(value, mask - 1n, bits, poly);
}

export function fieldOf(word: bigint, bits: number): FieldReport {
  const mask = (1n << BigInt(bits)) - 1n;
  const element = word & mask;
  const ringNegation = element === 0n ? 0n : (1n << BigInt(bits)) - element;
  const inverse = gfInv(element, bits);
  const product = inverse === null ? null : gfMul(element, inverse, bits);
  const square = gfMul(element, element, bits);
  const shifted = gfMul(element ^ 1n, element ^ 1n, bits);
  const frobeniusHolds = shifted === (square ^ 1n);
  const inverseHolds = element === 0n ? inverse === null : product === 1n;
  return {
    bits,
    polynomial: polynomial(bits),
    element: element.toString(),
    ringNegation: ringNegation.toString(),
    fieldNegation: element.toString(),
    fieldSum: (element ^ ringNegation).toString(),
    inverse: inverse === null ? "none" : inverse.toString(),
    product: product === null ? "none" : product.toString(),
    negationAgrees: ringNegation === element,
    inverseHolds,
    frobeniusHolds,
    holds: inverseHolds && frobeniusHolds && gfAdd(element, element) === 0n,
  };
}

export function productTable(bits: number): number[][] {
  const order = 1 << bits;
  return Array.from({ length: order }, (_, row) =>
    Array.from({ length: order }, (_, column) => Number(gfMul(BigInt(row), BigInt(column), bits))),
  );
}
