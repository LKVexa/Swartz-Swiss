"""Independent byte and arithmetic verification of a RUSSL/GFM browser export.

Requires Pillow. Uses no application JavaScript or generated state as a reference.
The GF80 multiplier forms the complete binary polynomial and then divides it.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
import zipfile

from PIL import Image

BITS = 80
MASK = (1 << BITS) - 1
POLYNOMIAL = (1 << 80) | (1 << 9) | (1 << 4) | (1 << 2) | 1
AXIS_NAMES = ("length", "width", "depth", "height", "ceiling")
PIXEL_PROFILE = "gfm-full-state-q80-p80-v1"


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def polynomial_remainder(value, divisor):
    require(divisor != 0, "Polynomial divisor cannot be zero")
    while value.bit_length() >= divisor.bit_length():
        value ^= divisor << (value.bit_length() - divisor.bit_length())
    return value


def multiply(left, right):
    require(0 <= left <= MASK and 0 <= right <= MASK, "GF80 input out of bounds")
    # Full polynomial product, not the application's masked shift/reduction loop.
    if left.bit_length() < right.bit_length():
        left, right = right, left
    product = 0
    while right:
        if right & 1:
            product ^= left
        left <<= 1
        right >>= 1
    return polynomial_remainder(product, POLYNOMIAL)


def polynomial_gcd(left, right):
    while right:
        left, right = right, polynomial_remainder(left, right)
    return left


def irreducibility():
    power = 2
    checkpoints = []
    for exponent in range(1, 81):
        power = multiply(power, power)
        if exponent in (16, 40):
            checkpoints.append({"exponent": exponent, "gcdHex": hex(polynomial_gcd(power ^ 2, POLYNOMIAL))[2:]})
    require(power == 2 and all(item["gcdHex"] == "1" for item in checkpoints), "GF80 polynomial is not irreducible")
    return {"polynomial": "x^80+x^9+x^4+x^2+1", "criterion": "Rabin over GF(2), prime degree divisors 2 and 5", "gcdChecks": checkpoints, "finalFrobeniusHolds": power == 2, "irreducible": True}


def fold(value):
    require(value >= 0, "Integer folding requires a nonnegative value")
    state = 0
    for byte in value.to_bytes(max(1, (value.bit_length() + 7) // 8), "big"):
        state = multiply(state, 256) ^ byte
    return state


def independent_parameters(seed):
    s = fold(seed)
    parameters = []
    for axis in range(5):
        salt = s ^ multiply(axis + 1, 0x13579BDF2468ACE1)
        parameters.append({
            "aq": salt or 1,
            "ap": (salt ^ 0x4D595DF4D0F33173) or 1,
            "bq": multiply(salt, 0xC4E17D938AB),
            "bp": multiply(salt, salt),
        })
    return parameters


def make_initial_state(parameters, imported):
    @lru_cache(maxsize=None)
    def word_unit(axis, index):
        if axis in imported:
            canonical = imported[axis]
            unit = int.from_bytes(canonical[index * 20:(index + 1) * 20], "big")
            return unit >> 80, unit & MASK
        coefficients = parameters[axis]
        folded = fold(index)
        return (multiply(coefficients["aq"], folded) ^ coefficients["bq"],
                multiply(coefficients["ap"], folded) ^ coefficients["bp"])

    @lru_cache(maxsize=None)
    def initial(coordinates):
        q, p = 0, 0
        for axis, index in enumerate(coordinates):
            uq, up = word_unit(axis, index)
            q ^= multiply(uq, axis + 1)
            p ^= multiply(up, 3 * (axis + 1))
        return q, p
    return initial


def restore_imported_words(manifest, files, dimensions):
    """Decode originals independently of the TypeScript raw-word adapter."""
    require(manifest["schema"] in ("RUSSL-five-word-cube/2", "RUSSL-five-word-cube/3"), "Unsupported manifest schema")
    words = manifest["words"]
    require(isinstance(words, list) and len(words) == 5, "Manifest needs five word descriptors")
    imported, checked = {}, []
    for axis, word in enumerate(words):
        require(word["name"] == AXIS_NAMES[axis] and word["unitBytes"] == 20, "Axis name or unit size mismatch")
        require(word["unitProfile"] == PIXEL_PROFILE and int(word["unitCount"]) == dimensions[axis], "Word unit profile/count mismatch")
        require(int(word["length"]) == dimensions[axis], "Word length mismatch")
        if word.get("source") != "imported":
            require(word.get("source") in ((None, "generated") if manifest["schema"].endswith("/2") else ("generated",)), "Unknown word source kind")
            continue
        require(manifest["schema"] == "RUSSL-five-word-cube/3", "Imported source requires schema 3")
        entry = f"words/{axis}-{AXIS_NAMES[axis]}.bin"
        require(word["entry"] == entry, "Imported source entry differs from safe axis path")
        require(entry in files, "Missing original imported source")
        name = word["originalName"]
        require(isinstance(name, str) and 1 <= len(name) <= 255 and name.strip() and name not in (".", "..")
                and not re.search(r"[\x00-\x1f\x7f/\\]", name), "Invalid original source filename")
        original = files[entry]
        bits, padding, byte_count = word["sourceBits"], word["paddingBits"], word["sourceByteLength"]
        require(type(bits) is int and type(padding) is int and type(byte_count) is int, "Source size metadata must be integral")
        require(byte_count == len(original) and byte_count > 0, "Original source byte count mismatch")
        require(8 <= bits <= byte_count * 8 and (bits + 7) // 8 == byte_count, "Source bit count/storage mismatch")
        count = (bits + 159) // 160
        require(count == dimensions[axis] and padding == count * 160 - bits and 0 <= padding < 160, "Source unit count/padding mismatch")
        require(int(word["wordBytes"]) == count * 20, "Canonical source byte count mismatch")
        source_format = word["sourceFormat"]
        if source_format == "appliance-le":
            require(byte_count <= 131072 and bits <= 1048576, "Native appliance word exceeds supported size")
            unused_high_bits = byte_count * 8 - bits
            require(original[-1] >> (8 - unused_high_bits) == 0, "Unused high bits of native source are nonzero")
            # Unit zero is the least-significant 160-bit integer chunk. Reverse each
            # complete chunk as a whole; do not swap bytes only within BE32 lanes.
            canonical = b"".join(int.from_bytes(original[start:start + 20], "little").to_bytes(20, "big")
                                 for start in range(0, byte_count, 20))
        elif source_format == "russl-be":
            require(byte_count <= 8 * 1024 * 1024 and byte_count % 20 == 0 and bits == byte_count * 8, "Canonical BE source size is invalid")
            canonical = original
        else:
            raise AssertionError("Unsupported imported source format")
        source_sha = hashlib.sha256(original).hexdigest()
        canonical_sha = hashlib.sha256(canonical).hexdigest()
        require(source_sha == word["sourceSha256"].lower(), "Original source SHA256 mismatch")
        require(canonical_sha == word["canonicalSha256"].lower(), "Canonical source SHA256 mismatch")
        require(len(canonical) == count * 20, "Canonical source encoding length mismatch")
        imported[axis] = canonical
        checked.append({"axis": axis, "name": AXIS_NAMES[axis], "entry": entry, "originalName": name,
                        "sourceFormat": source_format, "sourceBits": bits, "sourceByteLength": byte_count,
                        "paddingBits": padding, "unitCount": str(count), "sourceSha256": source_sha,
                        "canonicalSha256": canonical_sha})
    return imported, checked


def verify_word_witnesses(manifest, imported, used_indices, dimensions):
    witnesses = manifest.get("wordWitnesses", [])
    require(isinstance(witnesses, list), "Imported source witnesses must be a list")
    require(len(witnesses) == len(imported), "Imported source witness axis count mismatch")
    seen_axes, unit_count = set(), 0
    for witness in witnesses:
        axis = witness["axis"]
        require(type(axis) is int and axis in imported and axis not in seen_axes, "Duplicate or unexpected witness axis")
        seen_axes.add(axis)
        require(witness["name"] == AXIS_NAMES[axis] and int(witness["unitCount"]) == dimensions[axis], "Source witness descriptor mismatch")
        units = witness["units"]
        require(isinstance(units, list), "Source unit witnesses must be a list")
        indices = [int(item["index"]) for item in units]
        require(indices == sorted(used_indices[axis]), "Source witnesses must cover every observed and partner unit exactly once")
        for item, index in zip(units, indices, strict=True):
            require(0 <= index < dimensions[axis], "Witness unit lies outside source")
            require(item["pixelHex"].lower() == imported[axis][20 * index:20 * (index + 1)].hex(), "Source unit witness differs from independently decoded original bytes")
            unit_count += 1
    require(seen_axes == set(imported), "Missing imported axis witnesses")
    return unit_count


def step_cell(state, kappa):
    q, p = state
    p ^= multiply(kappa, q)
    return q ^ p, p


def inverse_cell(state, kappa):
    q, p = state
    old_q = q ^ p
    return old_q, p ^ multiply(kappa, old_q)


def step_pair(pair, kappa, coupling):
    (q0, p0), (q1, p1) = pair
    new_p0 = p0 ^ multiply(kappa, q0) ^ multiply(coupling, q1)
    new_p1 = p1 ^ multiply(coupling, q0) ^ multiply(kappa, q1)
    return ((q0 ^ new_p0, new_p0), (q1 ^ new_p1, new_p1))


def inverse_pair(pair, kappa, coupling):
    (q0, p0), (q1, p1) = pair
    old_q0, old_q1 = q0 ^ p0, q1 ^ p1
    return ((old_q0, p0 ^ multiply(kappa, old_q0) ^ multiply(coupling, old_q1)),
            (old_q1, p1 ^ multiply(coupling, old_q0) ^ multiply(kappa, old_q1)))


def cell_invariant(state, kappa):
    q, p = state
    return multiply(kappa, multiply(q, q)) ^ multiply(kappa, multiply(q, p)) ^ multiply(p, p)


def pair_invariant(pair, kappa, coupling):
    (q0, p0), (q1, p1) = pair
    return (cell_invariant(pair[0], kappa) ^ cell_invariant(pair[1], kappa)
            ^ multiply(coupling, multiply(q0, p1)) ^ multiply(coupling, multiply(q1, p0)))


def mixed_radix(coordinates, dimensions):
    stride, address = 1, 0
    for coordinate, dimension in zip(coordinates, dimensions, strict=True):
        require(0 <= coordinate < dimension, "Coordinate lies outside its word")
        address += coordinate * stride
        stride *= dimension
    return address


def read_tiff(tiff_bytes, manifest):
    image = Image.open(io.BytesIO(tiff_bytes))
    require(image.n_frames == 5, "The TIFF must contain all five lanes")
    require(json.loads(image.tag_v2[270]) == manifest, "Embedded TIFF JSON differs from manifest.json")
    size = manifest["config"]["size"]
    pages, modes = [], []
    for page in range(5):
        image.seek(page)
        require(image.size == (size, size), "TIFF shape differs from the selected slice")
        require(image.tag_v2[258] == (32,), "TIFF samples must be 32 bits")
        require(image.tag_v2[339] == (1,), "TIFF SampleFormat must be unsigned integer")
        require(image.tag_v2[259] == 1, "TIFF must be uncompressed")
        require(image.tag_v2[285] == f"L{4 + page}", "TIFF page name differs from lane order")
        # Pillow mode I exposes signed values; reinterpret the documented uint32 bits.
        pages.append([value & 0xFFFFFFFF for value in image.get_flattened_data()])
        modes.append(image.mode)
    return pages, modes


def verify(zip_path, standalone_path=None):
    zip_bytes = zip_path.read_bytes()
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
        require(archive.testzip() is None, "ZIP CRC validation failed")
        names = archive.namelist()
        require(len(names) == len(set(names)), "Replay bundle must contain distinct entries")
        require(all(item.compress_type == zipfile.ZIP_STORED for item in archive.infolist()), "ZIP entries must use stored compression")
        require(sum(item.file_size for item in archive.infolist()) <= 64 * 1024 * 1024, "Replay bundle exceeds supported aggregate size")
        files = {name: archive.read(name) for name in names}
        manifest = json.loads(archive.read("manifest.json"))
        payload = archive.read("pixel160.bin")
        tiff_names = [name for name in names if name.endswith(".tiff")]
        require(len(tiff_names) == 1, "Replay needs one TIFF entry")
        tiff_name = tiff_names[0]
        require(not re.search(r"[\\/:\x00-\x1f\x7f]", tiff_name), "TIFF entry must have a safe basename")
        tiff_bytes = archive.read(tiff_name)
        require("README.txt" in names, "Replay bundle lacks README")

    config = manifest["config"]
    require(manifest["observation"]["profile"] == PIXEL_PROFILE, "Unsupported pixel profile")
    require(manifest["field"]["polynomial"].replace(" ", "") == "x^80+x^9+x^4+x^2+1", "Unsupported field polynomial")
    witness = irreducibility()
    pages, modes = read_tiff(tiff_bytes, manifest)
    count = config["size"] ** 2
    require(len(payload) == 20 * count, "Canonical Pixel160 payload has the wrong length")
    reassembled = b"".join(pages[lane][index].to_bytes(4, "big") for index in range(count) for lane in range(5))
    require(reassembled == payload, "TIFF lanes do not reconstruct pixel160.bin exactly")
    payload_sha = hashlib.sha256(payload).hexdigest()
    require(payload_sha == manifest["sha256"]["pixelPayloadBE"], "Canonical payload SHA256 mismatch")
    require(len(manifest["fullStatesHex"]) == count, "Full-state witness count mismatch")
    for index, expected in enumerate(manifest["fullStatesHex"]):
        word = int.from_bytes(payload[20 * index:20 * (index + 1)], "big")
        require((word >> 80, word & MASK) == (int(expected["q"], 16), int(expected["p"], 16)), "Pixel state differs from fullStatesHex")

    dimensions = [int(value) for value in config["words"]]
    require(len(dimensions) == 5, "Five word lengths are required")
    domain_size = 1
    for dimension in dimensions:
        require(dimension >= 1, "Each word must be nonempty")
        domain_size *= dimension
    require(str(domain_size) == manifest["domain"]["cells"], "Mixed-radix domain count mismatch")
    require(dimensions == [int(value) for value in manifest["domain"]["axes"]], "Domain axes mismatch")
    imported, imported_checks = restore_imported_words(manifest, files, dimensions)
    expected_generator = "five-axis-source-pixel160-units-v1" if imported else "five-uww-pixel160-units-v1"
    require(manifest["generator"]["id"] == expected_generator, "Unsupported source/generator recipe")
    require(set(names) == {"manifest.json", "pixel160.bin", "README.txt", tiff_name}
            | {item["entry"] for item in imported_checks}, "Replay bundle has missing or unexpected entries")
    parameters = independent_parameters(int(config["seed"]))
    generated_coefficients = 0
    for axis, coefficients in enumerate(parameters):
        expected = manifest["words"][axis]
        if axis in imported:
            continue
        require(expected["unitBytes"] == 20 and int(expected["unitCount"]) == dimensions[axis], "Word unit/length metadata mismatch")
        require(int(expected["virtualWordBytes"]) == 20 * dimensions[axis], "Virtual word byte count mismatch")
        require(all(int(expected["coefficientsHex"][key], 16) == value for key, value in coefficients.items()), "Word coefficients differ from the seed recipe")
        generated_coefficients += 4
    initial = make_initial_state(parameters, imported)
    kappa, coupling, tick = int(config["kappa"]), int(config["coupling"]), int(config["tick"])
    require(0 <= tick <= 10000, "This direct-step verifier supports at most 10000 steps")
    dependencies, paired_cells, unpaired_cells = set(), 0, 0
    outside_slice_partners = 0
    used_indices = {axis: set() for axis in imported}
    initial_invariants, final_invariants, selected_previous, selected_final = [], [], None, None
    selected_paired = False
    selected_witness = manifest["checks"]["selectedInverseWitness"]
    selected_index = selected_witness["row"] * config["size"] + selected_witness["column"]
    for index in range(count):
        row, column = divmod(index, config["size"])
        coordinates = [int(value) for value in config["fixed"]]
        coordinates[config["axes"][0]] = int(config["origin"][0]) + column
        coordinates[config["axes"][1]] = int(config["origin"][1]) + row
        dependencies.add(mixed_radix(coordinates, dimensions))
        for axis in imported:
            used_indices[axis].add(coordinates[axis])
        partner_coordinates = coordinates.copy()
        partner_coordinates[config["couplingAxis"]] ^= 1
        paired = config["mode"] == "pair" and partner_coordinates[config["couplingAxis"]] < dimensions[config["couplingAxis"]]
        state = initial(tuple(coordinates))
        if paired:
            paired_cells += 1
            dependencies.add(mixed_radix(partner_coordinates, dimensions))
            for axis in imported:
                used_indices[axis].add(partner_coordinates[axis])
            if partner_coordinates[config["couplingAxis"]] != coordinates[config["couplingAxis"]] and config["couplingAxis"] not in config["axes"]:
                outside_slice_partners += 1
            pair = (state, initial(tuple(partner_coordinates)))
            before_invariant = pair_invariant(pair, kappa, coupling)
            for step in range(tick):
                previous = pair
                pair = step_pair(pair, kappa, coupling)
                require(inverse_pair(pair, kappa, coupling) == previous, "Independent pair inverse failed")
                require(pair_invariant(pair, kappa, coupling) == before_invariant, "Independent pair invariant changed")
                if index == selected_index and step == tick - 1:
                    selected_previous, selected_final = previous, pair
                    selected_paired = True
            state, after_invariant = pair[0], pair_invariant(pair, kappa, coupling)
        else:
            unpaired_cells += 1
            before_invariant = cell_invariant(state, kappa)
            for step in range(tick):
                previous = state
                state = step_cell(state, kappa)
                require(inverse_cell(state, kappa) == previous, "Independent cell inverse failed")
                require(cell_invariant(state, kappa) == before_invariant, "Independent cell invariant changed")
                if index == selected_index and step == tick - 1:
                    selected_previous, selected_final = previous, state
            after_invariant = cell_invariant(state, kappa)
        expected = manifest["fullStatesHex"][index]
        require(state == (int(expected["q"], 16), int(expected["p"], 16)), f"Independent dynamics mismatch at row={row},column={column}")
        initial_invariants.append(before_invariant)
        final_invariants.append(after_invariant)

    require(len(dependencies) == manifest["slice"]["evaluatedCells"], "Dependency-address count mismatch")
    source_witness_count = verify_word_witnesses(manifest, imported, used_indices, dimensions)
    require(manifest["slice"]["observedSliceCells"] == count, "Observed-cell count mismatch")
    selected_coords = [int(value) for value in selected_witness["coordinates"]]
    require(0 <= selected_witness["row"] < config["size"] and 0 <= selected_witness["column"] < config["size"], "Selected cell lies outside the slice")
    expected_selected_coords = [int(value) for value in config["fixed"]]
    expected_selected_coords[config["axes"][0]] = int(config["origin"][0]) + selected_witness["column"]
    expected_selected_coords[config["axes"][1]] = int(config["origin"][1]) + selected_witness["row"]
    require(selected_coords == expected_selected_coords, "Selected five-coordinate witness differs from slice configuration")
    require(selected_coords[config["axes"][0]] == int(config["origin"][0]) + selected_witness["column"], "Selected column witness mismatch")
    require(selected_coords[config["axes"][1]] == int(config["origin"][1]) + selected_witness["row"], "Selected row witness mismatch")
    require(int(selected_witness["addressHex"], 16) == mixed_radix(selected_coords, dimensions), "Selected mixed-radix address mismatch")
    require(selected_witness["tick"] == config["tick"], "Selected step witness mismatch")
    if selected_final is not None:
        recovered = inverse_pair(selected_final, kappa, coupling) if selected_paired else inverse_cell(selected_final, kappa)
        require(recovered == selected_previous, "Selected direct inverse witness mismatch")
    require(manifest["checks"]["selectedInverseReplay"] is True, "Browser reported failed selected inverse")
    require(manifest["checks"]["invariantPreserved"] is True and initial_invariants == final_invariants, "Invariant certificate mismatch")

    standalone_sha = None
    if standalone_path is not None:
        standalone_bytes = standalone_path.read_bytes()
        require(standalone_bytes == tiff_bytes, "Separate browser TIFF differs from replay-bundle TIFF")
        standalone_sha = hashlib.sha256(standalone_bytes).hexdigest()
    return {
        "schema": "RUSSL-GFM-independent-export-validation/1",
        "validatedUTC": datetime.now(timezone.utc).isoformat(),
        "status": "PASS",
        "scope": [
            "Validates the supplied replay ZIP bytes and optional separate TIFF; acquisition is recorded by the caller.",
            "Native file-download transport is not validated by this byte/arithmetic verifier.",
            "Independent Python/Pillow/zipfile/stdlib readback and full-polynomial GF80 arithmetic; no application JavaScript imports.",
            "Tests the exported bounded slice and its dependencies, not the entire virtual domain or physical theory.",
        ],
        "inputs": {"replayZip": str(zip_path.resolve()), "standaloneTiff": str(standalone_path.resolve()) if standalone_path else None},
        "config": config,
        "checks": {"zipCRC": "PASS", "storedZipEntries": len(names), "tiffPages": 5, "tiffUnsignedSampleFormat": "PASS", "tiffEmbeddedManifest": "PASS",
                   "tiffReassemblesCanonicalPixelPayload": "PASS", "fullQ80P80StatesMatch": count, "canonicalPayloadSHA256": "PASS",
                   "independentSeedRecipeCoefficients": generated_coefficients, "importedWordAxes": len(imported),
                   "originalSourceBytesHashesPadding": "PASS" if imported else "NOT_APPLICABLE",
                   "independentRawSourceUnitWitnesses": source_witness_count,
                   "directEvolutionStatesMatch": count, "directStepsPerState": tick,
                   "pairedCells": paired_cells, "unpairedCells": unpaired_cells, "distinctDependencyAddresses": len(dependencies),
                   "partnersOutsideSelectedPlane": outside_slice_partners, "invariantChecksDuringDirectEvolution": count * tick,
                   "selectedMixedRadixWitness": "PASS", "selectedInverseWitness": "PASS" if tick else "INITIAL_STATE", "standaloneTIFFMatchesBundle": "PASS" if standalone_path else "NOT_CHECKED"},
        "arithmetic": {"field": "GF(2^80)", "multiplier": "Full binary polynomial product followed by polynomial division", "irreducibility": witness},
        "importedSources": imported_checks,
        "payload": {"cells": count, "pixelBytesPerCell": 20, "pixelPayloadBytes": len(payload), "pillowPageModes": modes,
                    "unsignedReadback": "Pillow mode I values are reinterpreted as uint32 after validating TIFF SampleFormat=1", "domainPositions": str(domain_size)},
        "sha256": {"replayZip": hashlib.sha256(zip_bytes).hexdigest(), "tiff": hashlib.sha256(tiff_bytes).hexdigest(),
                   "standaloneTiff": standalone_sha, "pixelPayloadBE": payload_sha},
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip", required=True, type=Path)
    parser.add_argument("--tiff", type=Path)
    parser.add_argument("--report", type=Path)
    arguments = parser.parse_args()
    result = verify(arguments.zip, arguments.tiff)
    if arguments.report:
        arguments.report.parent.mkdir(parents=True, exist_ok=True)
        arguments.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "checks": result["checks"], "sha256": result["sha256"]}, indent=2))
