import type { StackSpec } from "./audit.ts";

export const STACK: StackSpec = {
  version: "1.0.0",
  previous: "0.9.0-chat",
  llama70bFp16KvBytes: 327_680_000_000,
  homonyms: [
    {
      token: "bit",
      senses: [
        { name: "BMV bit / anti-bit sector", livesIn: "closed.bit-antibit" },
        { name: "1-bit LAMB momentum sign", livesIn: "train.one-bit-lamb" },
        { name: "Ternary weight in {−1, 0, 1}", livesIn: "infer.quant" },
        { name: "Machine bit in Z/2^n Z", livesIn: "math.padic" },
        { name: "Positional digit in an OAM shift demo", livesIn: "optics.field" },
      ],
    },
    {
      token: "holographic",
      senses: [
        { name: "Complex optical field, CGH, ASM", livesIn: "optics.field" },
        { name: "Plate HRR, circular convolution", livesIn: "algebra.hrr" },
        { name: "AdS/CFT or HaPPY tensor network", livesIn: "lexicon only — not a layer" },
      ],
    },
    {
      token: "GIF",
      senses: [
        { name: "GIF89a paletted byte stream", livesIn: "lexicon only — not a layer" },
        {
          name: "Gaussian interaction frame",
          livesIn: "ref.gaussian-interaction-frame",
        },
      ],
    },
    {
      token: "RAM sampling",
      senses: [
        { name: "PEBS / perf on a hybrid Intel laptop", livesIn: "ref.ideapad" },
        { name: "Audio direct-from-disk preload", livesIn: "ref.ideapad" },
        { name: "Live forensic memory image", livesIn: "ref.ideapad" },
        { name: "DRAM stress, Rowhammer, on-die ECC", livesIn: "ref.ideapad" },
        { name: "DMA of an optical field", livesIn: "rejected — not this stack" },
      ],
    },
  ],
  layers: [
    {
      id: "closed.bit-antibit",
      n: "01",
      title: "Bit / anti-bit",
      status: "closed",
      summary:
        "Bose–Marletto–Vedral toy theory. Two classical sectors sit inside one quantum message. Product observables miss a global sector phase, so the tomography is non-local. The witness is the five-swap protocol. This layer is an explanation of that loophole. It is not a wire, a weight, or a sign.",
      invariants: [
        "A sector label is not a voltage and not a sign bit.",
        "The anti-bit is not bitwise complement, not two’s-complement −1, and not an HRR involution.",
        "No other layer may import this one.",
      ],
      rejects: ["Using the toy model as a memory cell, a quantizer, or a 2-adic negation."],
    },
    {
      id: "math.padic",
      n: "02",
      title: "p-adic geometry",
      status: "normative",
      summary:
        "The normative object is Q_p and the ring of p-adic integers. Ultrametric inequality, Hensel lifting of units, the Monna map, Kozyrev wavelets, the Vladimirov operator, and the Bruhat–Tits tree are mathematics. The only hardware sentence allowed: an n-bit two’s-complement word is Z/2^n Z, the truncation of the 2-adic integers. That licenses exact inversion of odd denominators. It does not license an optimizer.",
      invariants: [
        "Odd modular inverses via Hensel lifting are exact in Z/2^n Z.",
        "Carry runs from low significance to high. That is a statement about the ring, not about gradient descent.",
        "The Monna map is a named bridge to a Euclidean grid. It is not an encoding of model weights.",
      ],
      rejects: [
        "rej.2adic-npu. sign of a real momentum is not a projection onto the 2-adic unit group. The residual against a signed scale is a real vector, not an element of the maximal ideal. Majority vote of signs is not the 1-bit LAMB reducer. Picojoule and gate-count figures in that essay are not measurements.",
      ],
    },
    {
      id: "train.one-bit-lamb",
      n: "03",
      title: "1-bit LAMB",
      status: "normative",
      summary:
        "Training-time communication compression (Li, Awan, Tang, Rajbhandari, He). LAMB’s layer ratio is a norm of a norm; Adam-style variance is nonlinear. Both facts break naive 1-bit error feedback. The repair is a warmup, a freeze, a mask, and a soft threshold. This is not an inference format.",
      invariants: [
        "Warmup runs full-precision LAMB and tracks a moving average of the layer scale.",
        "At the freeze step, store v and that average. Do not quantize the gradient that updates v.",
        "After the freeze, communicate the sign of momentum plus the local error, with a scale. Write the residual back into the error buffer.",
        "Coordinates with a structural zero gradient stay masked at zero. The sign code cannot represent 0.",
        "Collective: ReduceScatter of packed signs and scales, decompress and average on the shard, requantize, AllGather.",
        "Clamp the layer ratio to a band around the frozen average, then apply the outer clamp.",
        "The error buffer is per rank and the size of the parameter tensor. A checkpoint keeps every copy or drops the buffer. Dropping it changes the trajectory.",
      ],
      rejects: [
        "Majority vote or popcount as the reducer.",
        "Feeding a quantized gradient into v.",
        "One global freeze when layers plateau at different times, without the soft threshold.",
        "Averaging error buffers across ranks.",
        "Treating a unikernel, a columnar allocator, or a 2-adic ALU as part of this contract.",
      ],
    },
    {
      id: "infer.quant",
      n: "04",
      title: "Inference compression",
      status: "normative",
      summary:
        "Serving formats. They cut bytes so a memory-bound kernel moves right on the roofline. They do not compress the training collective in layer 03, and they do not accept its sign stream as weights.",
      invariants: [
        "GPTQ compensates a rounded weight using the inverse Hessian of the layer output error. In that local problem the Hessian is the uncentered activation covariance.",
        "AWQ scales up channels that see large activations, then rounds.",
        "SmoothQuant moves outlier scale from activations onto weights with a per-channel factor, then quantizes both.",
        "OCP microscaling, v1.0: blocks of 32 share one E8M0 power-of-two scale. MXFP4’s element is sign, 2 exponent bits, 1 mantissa bit, about 4.25 bits with the scale.",
        "BitNet b1.58 trains weights in {−1, 0, 1}. Post-training ternarization is a different method. Stored checkpoints include scales, so the file is wider than 1.58 bits.",
        "KV cache bytes = 2 · layers · kv-heads · head-dim · tokens · bytes-per-element. Llama-70B, FP16, 10^6 tokens: 80, 8, 128, two bytes → 327,680,000,000 bytes.",
        "FP8 on the cache halves that footprint. The cache tolerates it better than the weights do, because attention normalizes. That is not a license to quantize the weights the same way.",
      ],
      rejects: [
        "The essay figure of 135 GB for that Llama-70B cache.",
        "Substituting 1-bit LAMB signs for GPTQ, AWQ, MX, or BitNet weights.",
        "Treating the Horowitz-style picojoule table in the source essay as the 2014 measurements. It is a sketch, and a DRAM access without a width is not a number.",
      ],
    },
    {
      id: "optics.field",
      n: "05",
      title: "Optical field path",
      status: "normative",
      summary:
        "How a complex scalar field is propagated, encoded onto a phase panel, and stored. Computer-generated holography and a diffractive stack live here. Plate’s algebra does not, except for one gated convolution.",
      invariants: [
        "Propagator for parallel planes: angular spectrum. FFT, multiply by the exact longitudinal phase, inverse FFT.",
        "A phase-only panel needs Gerchberg–Saxton, or double phase. Double phase spends two panel pixels on one complex sample.",
        "Panel codes pass through a measured look-up table. Phase is not linear in the 8-bit code.",
        "While the field is still a field, keep floats. Uncompressed TIFF is a legal container. The panel is fed pixels, not a compressed file.",
        "Maximum diffraction angle scales as wavelength over pixel pitch.",
        "A holographic spot’s axial thickness grows with its lateral size. A thin spot at an arbitrary depth needs temporal focusing. That is the only import from the neurophotonics note.",
        "Cascaded linear masks are one linear map. Depth requires a real nonlinearity.",
        "Energy sits in the source, the panel drive, the detectors, and any absorber. Free-space propagation does not erase bits and does not repeal a Landauer cost at the detector.",
      ],
      rejects: [
        "A trained four-input sorter described as a logic family or a Turing machine.",
        "LZW, GIF89a, or a private TIFF tag as the panel interface.",
        "Orbital-angular-momentum spot shifting described as a general multiplier. A sideways route of beams is multiplication by the base only, with no carry.",
        "Rotating one phase plate and calling the result an instruction set.",
      ],
    },
    {
      id: "algebra.hrr",
      n: "06",
      title: "Holographic reduced representation",
      status: "normative",
      summary:
        "Plate’s fixed-width vector algebra. Binding is circular convolution. The representation is holographic only in that every coordinate carries every binding. It is not an optical recording.",
      invariants: [
        "Atoms are drawn independently in high dimension and are quasi-orthogonal.",
        "Bundle by addition. Bind by circular convolution, via an FFT.",
        "Unbind by circular correlation, which is convolution with the involution. The result is noisy.",
        "Cleanup against the item memory is mandatory. Without a nearest codeword there is no symbol.",
        "Convolution commutes. Sequence is a fixed permutation applied before the bind, or it is invisible.",
        "Continuous quantities use fractional binding. They do not replace random atoms.",
        "An optical Fourier stage may implement the convolution and nothing else, and only under an explicit directive. It does not implement cleanup, the lexicon, or the permutation.",
      ],
      rejects: [
        "Identifying this layer with a spatial-light-modulator hologram, a diffractive network, or a bulk reconstruction code.",
        "Reading an XOR of binary hypervectors as a saturable absorber.",
      ],
    },
    {
      id: "storage.containers",
      n: "07",
      title: "Containers",
      status: "normative",
      summary:
        "Pick the container by the query. These four names are not interchangeable, and none of them is a p-adic tree.",
      invariants: [
        "TIFF: image-file directories, 12-byte entries, magic 42, 32-bit offsets. Hard stop at 4 GiB.",
        "BigTIFF: magic 43, 64-bit offsets, 20-byte entries. Use it when one TIFF would cross 4 GiB.",
        "Cloud Optimized GeoTIFF: directories at the front, internal tiles, overviews, read by range request. It answers 2D windows. PixelIsArea versus PixelIsPoint is a half-pixel shift if missed.",
        "OME-TIFF: one plane per directory, the 5D index in OME-XML on tag 270 of the first directory. Dimension order says which axis runs fastest. Multi-file sets repeat the XML. Pyramids live in subdirectories.",
        "OME-Zarr: one object per chunk. A chunk long in time makes a time series cheap and a single plane expensive. The hot axis is the chunk axis. There is no neutral shape.",
      ],
      rejects: [
        "Private tags, stream-cipher payloads, or a hybrid that is not one of the formats above.",
        "Storing a working optical field as GIF89a.",
        "Treating a GeoTIFF, an OME-TIFF, and a Zarr as drop-in copies of the same array.",
      ],
    },
    {
      id: "ref.gaussian-interaction-frame",
      n: "08",
      title: "Gaussian interaction frame",
      status: "reference",
      summary:
        "Yanagimoto, Ng, and coauthors, Optica 2022. A bookkeeping split for pulsed squeezing once the pump depletes. The Gaussian unitary carries displacement and squeezing. The residual state carries the non-Gaussian part, including Wigner negativity. No file format, no panel, no training collective.",
      invariants: [
        "The lab state factors as a time-dependent Gaussian unitary times a residual.",
        "Choosing that unitary so the interaction-frame Hamiltonian has no linear or quadratic piece pins the residual at the origin of phase space.",
        "The pump’s equation of motion gains a back-action term. That is how particle number survives, which the undepleted-pump approximation gives up.",
        "A few principal supermodes, often kept as a matrix-product state, are a numerical basis for the residual. They are not optical “neurons”.",
      ],
      rejects: [
        "Any edge into storage, the panel path, or the training compressor.",
        "Using the bare word GIF as this layer’s name.",
      ],
    },
    {
      id: "ref.ideapad",
      n: "09a",
      title: "IdeaPad memory note",
      status: "reference",
      summary:
        "Four laptop operations share a name with an optical DMA that is not in this stack. Performance counters, sample-library preload, a live memory image, and DRAM stress. Useful only if the question is that machine.",
      invariants: [
        "Precise load-latency events exist on the performance cores. The efficiency cores do not implement the same counters.",
        "DDR5 on-die ECC corrects a single-bit cell fault inside the die and does not report it. A clean memory test does not prove healthy cells.",
        "A Windows virtualization-based dump is the normal world. The secure world comes back empty.",
      ],
      rejects: ["Importing any of these procedures as a stage of the optical path or the training collective."],
    },
    {
      id: "ref.neurophotonics",
      n: "09b",
      title: "Neurophotonics survey",
      status: "reference",
      summary:
        "Opsins, scanless two-photon stimulation, deep-tissue transducers, synaptic barcodes, and super-resolution of the synapse. A literature crib. One sentence is copied into the optical contract; the rest stays here.",
      invariants: [
        "The copied sentence: axial confinement of a wide computer-generated spot collapses as the spot grows laterally. Temporal focusing is the countermeasure. It already lives in optics.field.",
        "Channelrhodopsin variants, upconversion particles, sono-optogenetic particles, and X-ray scintillators are stimulation methods, not compute elements.",
        "The trans-synaptic nanocolumn and the spine-neck result from STED are anatomy. Synaptic MEMOIR is recent enough to treat as provisional.",
      ],
      rejects: [
        "A “biological holography” subsystem.",
        "Any further edge into optics.field, storage, or the algebras.",
      ],
    },
  ],
  edges: [
    {
      from: "optics.field",
      to: "storage.containers",
      allow: true,
      relation: "A float field may be written as TIFF or BigTIFF, or as an OME plane if it is one slice of a stack.",
    },
    {
      from: "ref.neurophotonics",
      to: "optics.field",
      allow: true,
      relation: "Only the axial-confinement fact. Already inlined. Do not add a second copy.",
    },
    {
      from: "algebra.hrr",
      to: "optics.field",
      allow: true,
      relation: "Directive-gated. Convolution only. No cleanup, no lexicon, no permutation.",
    },
    {
      from: "math.padic",
      to: "train.one-bit-lamb",
      allow: false,
      relation: "rej.2adic-npu. No Hensel datapath for layer norms or sign residuals.",
    },
    {
      from: "train.one-bit-lamb",
      to: "infer.quant",
      allow: false,
      relation: "A momentum sign is not a weight. BitNet is not 1-bit LAMB.",
    },
    {
      from: "infer.quant",
      to: "train.one-bit-lamb",
      allow: false,
      relation: "GPTQ, AWQ, SmoothQuant, and MX do not replace the freeze-and-sign collective.",
    },
    {
      from: "closed.bit-antibit",
      to: "train.one-bit-lamb",
      allow: false,
      relation: "Sector bits are not signs and not weights.",
    },
    {
      from: "ref.gaussian-interaction-frame",
      to: "storage.containers",
      allow: false,
      relation: "The interaction frame is not a file format.",
    },
    {
      from: "ref.gaussian-interaction-frame",
      to: "optics.field",
      allow: false,
      relation: "Pump-depletion bookkeeping is not a hologram encoder.",
    },
    {
      from: "ref.ideapad",
      to: "optics.field",
      allow: false,
      relation: "Laptop memory operations are not optical DMA.",
    },
    {
      from: "algebra.hrr",
      to: "storage.containers",
      allow: false,
      relation: "A hypervector is not an image directory. Do not store it as a GIF.",
    },
  ],
};
