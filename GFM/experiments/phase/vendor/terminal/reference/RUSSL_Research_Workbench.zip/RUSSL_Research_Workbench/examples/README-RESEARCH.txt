RESEARCH INTEGRATION EXAMPLE

research-step7-session.json contains four actual UI-recorded experiments: GF9 CHSH, a Bell circuit, the synthetic fixed-profile penteract, and a five-word RUSSL Pixel160 mechanical slice. Import it in the research ledger and choose Replay & compare.
The mechanical experiment uses the labeled demonstration appliance words at step 7, a 32 by 32 slice, fixed coordinates [0,0,2,3,6553] and selected cell [19,11,2,3,6553]. These are demo data, not the user's appliance state.
research-step7.tiff and research-step7-replay.zip retain the corresponding TIFF pages, exact payload and complete original words. The bounded ledger contains dependent unit witnesses; it cannot authenticate all original file bytes on its own.
Independent checks and captured browser results are in validation/research-*. Actual export bytes were checked; native download saving was canceled by the test sandbox.
