import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import app from "../.vercel/output/functions/__server.func/index.mjs";

const publicRoot = path.resolve(import.meta.dirname, "../.vercel/output/static");
const port = Number(process.env.PORT ?? 8081);
if (!Number.isInteger(port) || port < 1 || port > 65535)
  throw new Error("PORT must be a valid TCP port.");
const types = {
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".json": "application/json",
  ".webmanifest": "application/manifest+json",
};
const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url ?? "/", `http://127.0.0.1:${port}`);
    const pathname = decodeURIComponent(url.pathname);
    const file = path.resolve(publicRoot, "." + pathname);
    if (file.startsWith(publicRoot + path.sep)) {
      try {
        if ((await stat(file)).isFile()) {
          res.writeHead(200, {
            "content-type": types[path.extname(file)] ?? "application/octet-stream",
          });
          res.end(req.method === "HEAD" ? undefined : await readFile(file));
          return;
        }
      } catch (e) {
        if (e.code !== "ENOENT" && e.code !== "ENOTDIR") throw e;
      }
    }
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    const request = new Request(url, {
      method: req.method,
      headers: req.headers,
      ...(chunks.length ? { body: Buffer.concat(chunks), duplex: "half" } : {}),
    });
    const response = await app.fetch(request, { waitUntil: (p) => p.catch(console.error) });
    res.writeHead(response.status, Object.fromEntries(response.headers));
    res.end(req.method === "HEAD" ? undefined : Buffer.from(await response.arrayBuffer()));
  } catch (e) {
    console.error(e);
    res.writeHead(500, { "content-type": "text/plain" });
    res.end("Workbench request failed.");
  }
});
server.listen(port, "127.0.0.1", () => console.log(`GFM workbench: http://127.0.0.1:${port}/`));
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () => server.close(() => process.exit(0)));
