import "./build-research-terminal.mjs";
import { spawn } from "node:child_process";
import path from "node:path";
import { readAppEnv, mergeAppEnv, exitStatusFromChild } from "./with-app-env.mjs";

const root = path.resolve(import.meta.dirname, "..");
const child = spawn(process.execPath, [path.join(root, "node_modules/vite/bin/vite.js"), "build"], {
  cwd: root,
  stdio: "inherit",
  env: mergeAppEnv(readAppEnv(root), process.env),
});
child.on("error", (error) => {
  console.error(error.message);
  process.exit(1);
});
child.on("exit", (code, signal) => process.exit(exitStatusFromChild(code, signal)));
for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, () => child.kill(signal));
