"""Export five complete BRIM register operands as raw appliance words.

Uses an existing UltraWide Appliance checkout; it does not ship or modify it.
The browser imports the resulting .bin files with 'Ultra-wide appliance word'.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys

AXES = ('length', 'width', 'depth', 'height', 'ceiling')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bounded_read(path, maximum):
    with Path(path).open('rb') as stream:
        data = stream.read(maximum + 1)
    if len(data) > maximum:
        raise ValueError(f'{Path(path).name} exceeds its input size limit')
    return data


def load_appliance(root):
    source = Path(root).resolve() / 'src'
    if not (source / 'ultrawide/brim.py').is_file() or not (source / 'ultrawide/word.py').is_file():
        raise ValueError('Choose the UltraWide Appliance repository root containing src/ultrawide')
    sys.path.insert(0, str(source))
    brim = importlib.import_module('ultrawide.brim')
    word = importlib.import_module('ultrawide.word')
    if Path(brim.__file__).resolve() != source / 'ultrawide/brim.py':
        raise ValueError('An already-loaded ultrawide module belongs to another checkout')
    return brim, word.Word


def export_program(appliance_root, program_path, output, selected=(0, 1, 2, 3, 4),
                   initial_words=(), max_steps=4096, timeout_seconds=30):
    if len(selected) != 5 or len(set(selected)) != 5 or any(type(n) is not int or not 0 <= n < 16 for n in selected):
        raise ValueError('Choose five distinct registers from 0 through 15, in axis order')
    brim, Word = load_appliance(appliance_root)
    program_path, destination = Path(program_path), Path(output)
    if program_path.suffix.lower() == '.lctlb':
        source = bounded_read(program_path, 65536)
        image = brim.compile_lctl(source.decode('utf-8'), max_steps=max_steps).image
    elif program_path.suffix.lower() == '.brimg':
        source = bounded_read(program_path, brim.MAX_IMAGE)
        image = source
    else:
        raise ValueError('Choose a .brimg image or LCTL-BRIM/1 .lctlb source; chains and receipt JSON are not operands')
    registers, initial_receipts = {}, []
    for index, path in initial_words:
        if type(index) is not int or not 0 <= index < 16 or index in registers:
            raise ValueError('Initial registers must have distinct indices from 0 through 15')
        data = bounded_read(path, brim.WORD_BYTES)
        if len(data) != brim.WORD_BYTES:
            raise ValueError('A BRIM initial operand must contain exactly 131,072 raw little-endian bytes')
        registers[index] = int.from_bytes(data, 'little')
        initial_receipts.append({'register': index, 'name': Path(path).name, 'bytes': len(data), 'sha256': sha(data)})
    result = brim.run_brim(image, registers=registers, max_steps=max_steps, timeout_seconds=timeout_seconds)
    if result['status'] != 'HALTED' or result['word_bits'] != 1048576:
        raise ValueError('The appliance did not return a complete halted full-width register state')
    files, receipts = [], []
    for axis, register in zip(AXES, selected, strict=True):
        data = Word(result['registers'][register], result['word_bits']).to_bytes()
        if len(data) != brim.WORD_BYTES or sha(data) != result['register_sha256'][register]:
            raise ValueError('Raw operand bytes disagree with the appliance register hash')
        name = f'{axis}.bin'
        files.append((name, data))
        receipts.append({'axis': axis, 'register': register, 'file': name,
                         'format': 'appliance-le', 'sourceBits': result['word_bits'],
                         'sourceByteLength': len(data), 'unitCount': str((result['word_bits'] + 159) // 160),
                         'paddingBits': (-result['word_bits']) % 160, 'sha256': sha(data)})
    receipt = {'schema': 'RUSSL-ULTRAWIDE-RAW-EXPORT/1', 'status': 'PASS',
               'execution': 'UltraWide Appliance Python BRIM VM; complete final register operands',
               'program': {'name': program_path.name, 'inputSha256': sha(source),
                           'imageSha256': result['image_sha256'], 'traceSha256': result['trace_sha256'],
                           'steps': result['steps']},
               'initialRegisters': initial_receipts, 'axes': receipts,
               'adapter': 'Least-significant 160-bit unit first; reverse each native chunk to canonical BE Pixel160; high-zero-extend final 96 bits',
               'scope': 'Software appliance execution, not booted hardware or a claim of RUSSL language conformance'}
    files.append(('appliance-export.json', (json.dumps(receipt, indent=2) + '\n').encode('utf-8')))
    if destination.exists() and not destination.is_dir():
        raise ValueError('Output must be a directory')
    for name, _ in files:
        if (destination / name).exists():
            raise FileExistsError(f'Refusing to overwrite {name}; choose a new output directory')
    destination.mkdir(parents=True, exist_ok=True)
    for name, data in files:
        with (destination / name).open('xb') as stream:
            stream.write(data)
    return receipt


def initial_spec(text):
    index, separator, path = text.partition(':')
    if not separator or not index.isdigit() or not path:
        raise argparse.ArgumentTypeError('Use REGISTER:PATH, such as 5:input.bin')
    return int(index), Path(path)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--appliance-root', required=True, type=Path)
    parser.add_argument('--program', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--registers', default='0,1,2,3,4', help='Five final registers in length,width,depth,height,ceiling order')
    parser.add_argument('--initial-register', action='append', type=initial_spec, default=[])
    parser.add_argument('--max-steps', type=int, default=4096)
    parser.add_argument('--timeout-seconds', type=float, default=30)
    args = parser.parse_args()
    try:
        receipt = export_program(args.appliance_root, args.program, args.output,
                                 tuple(int(value) for value in args.registers.split(',')),
                                 args.initial_register, args.max_steps, args.timeout_seconds)
    except (ValueError, OSError) as error:
        parser.exit(1, f'Export failed: {error}\n')
    print(json.dumps(receipt, indent=2))
