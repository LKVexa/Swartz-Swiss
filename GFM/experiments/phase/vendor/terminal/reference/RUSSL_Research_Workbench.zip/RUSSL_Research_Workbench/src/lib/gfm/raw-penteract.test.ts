import assert from "node:assert/strict";
import test from "node:test";
import {
  AXIS_NAMES,
  DEFAULT_CONFIG,
  dimensionsOf,
  makeWordGenerator,
  packCoordinates,
  sampleSlice,
  unpackCoordinates,
  verifyInverse,
  virtualField,
} from "./penteract.ts";
import type { FiveStrings, SliceConfig } from "./penteract.ts";
import { EMPTY_WORD_SOURCES, importRawWord } from "./raw-words.ts";
import type { ImportedWord, WordSources } from "./raw-words.ts";
import { decodeStatePixel160, encodePixel160, encodeStatePixel160, pixelHex } from "./pixel.ts";
import { advanceCell, advancePair } from "./dynamics.ts";
import { gfMul } from "./field.ts";

const MASK80 = (1n << 80n) - 1n;
const lengths = [4, 4, 3, 3, 3];
const config = (patch: Partial<SliceConfig> = {}): SliceConfig => ({
  ...DEFAULT_CONFIG,
  words: lengths.map(String) as FiveStrings,
  seed: "13",
  tick: "7",
  couplingAxis: 4,
  axes: [0, 1],
  fixed: ["0", "0", "1", "1", "0"],
  origin: ["0", "0"],
  size: 2,
  ...patch,
});

function fixtureBytes(axis: number, count: number): Uint8Array {
  const bytes = new Uint8Array(count * 20);
  for (let index = 0; index < count; index++) {
    const state = {
      q: ((1n << BigInt(79 - axis)) ^ BigInt(37 * (axis + 1) + index)) & MASK80,
      p: ((1n << BigInt(75 - index)) ^ BigInt(101 * (axis + 1) + index * 7)) & MASK80,
    };
    bytes.set(encodePixel160(encodeStatePixel160(state)), index * 20);
  }
  return bytes;
}

async function importedFixtures(): Promise<WordSources> {
  const sources = await Promise.all(
    lengths.map((count, axis) =>
      importRawWord(fixtureBytes(axis, count), {
        name: `actual-${AXIS_NAMES[axis]}.bin`,
        format: "russl-be",
      }),
    ),
  );
  return sources as unknown as WordSources;
}

test("all five imported words drive the exact weighted GF80 state and remain fixed during evolution", async () => {
  const sources = await importedFixtures();
  const cfg = config(),
    field = virtualField(cfg, sources);
  const coords = [1n, 1n, 1n, 1n, 0n],
    index = packCoordinates(coords, field.dimensions);
  const observation = field.observe(index);
  const units = coords.map((coordinate, axis) => sources[axis]!.unit(coordinate));
  assert.deepEqual(observation.wordUnits, units);
  const combined = units.map(decodeStatePixel160).reduce(
    (state, unit, axis) => ({
      q: state.q ^ gfMul(unit.q, BigInt(axis + 1), "gf80"),
      p: state.p ^ gfMul(unit.p, BigInt(3 * (axis + 1)), "gf80"),
    }),
    { q: 0n, p: 0n },
  );
  assert.deepEqual(observation.initial, combined);
  assert.deepEqual(field.generator.stateAt(index), combined);
  assert.deepEqual(decodeStatePixel160(observation.pixel), observation.state);
  const partner = field.observe(observation.partnerIndex!);
  assert.deepEqual(
    [observation.state, partner.state],
    advancePair([combined, partner.initial], 7n, "gf80"),
  );
  assert.equal(observation.initialInvariant, observation.currentInvariant);
  assert(verifyInverse(observation, cfg, sources));
  const initialField = virtualField(config({ tick: "0" }), sources);
  assert.deepEqual(initialField.generator.wordUnit(0, 1n), field.generator.wordUnit(0, 1n));
  assert.notDeepEqual(observation.state, initialField.observe(index).state);
  assert.deepEqual(
    sampleSlice(config({ seed: "9999" }), sources).pixelBytes,
    sampleSlice(cfg, sources).pixelBytes,
  );
});

test("changing source bits on each axis changes the active dynamics and does not silently regenerate that word", async () => {
  const sources = await importedFixtures(),
    cfg = config({ mode: "cell" });
  const before = virtualField(cfg, sources).observe(0n);
  for (let axis = 0; axis < 5; axis++) {
    const changedBytes = sources[axis]!.bytes();
    changedBytes[0] ^= 0x80;
    changedBytes[19] ^= 1;
    const changed = await importRawWord(changedBytes, {
      name: sources[axis]!.name,
      format: "russl-be",
    });
    const active = [...sources] as (ImportedWord | null)[];
    active[axis] = changed;
    const field = virtualField(cfg, active as unknown as WordSources),
      after = field.observe(0n);
    assert.deepEqual(field.generator.wordUnit(axis, 0n), changed.unit(0n));
    assert.notDeepEqual(after.initial, before.initial);
    assert.notDeepEqual(after.state, before.state);
    assert.notDeepEqual(after.pixel, before.pixel);
    assert.equal(verifyInverse(before, cfg, active as unknown as WordSources), false);
  }
});

test("mixed imported and generated sources retain the virtual fallback and preserve virtual-only v2 manifests", async () => {
  const imported = await importedFixtures();
  const mixed: WordSources = [imported[0], null, null, imported[3], null];
  const cfg = config(),
    field = virtualField(cfg, mixed);
  const generated = makeWordGenerator(BigInt(cfg.seed), dimensionsOf(cfg));
  for (let axis = 0; axis < 5; axis++) {
    assert.deepEqual(
      field.generator.wordUnit(axis, 1n),
      mixed[axis] ? mixed[axis]!.unit(1n) : generated.wordUnit(axis, 1n),
    );
  }
  const mixedSlice = sampleSlice(cfg, mixed);
  assert.equal(mixedSlice.manifest.schema, "RUSSL-five-word-cube/3");
  assert.deepEqual(
    mixedSlice.manifest.words.map((word) => word.source),
    ["imported", "generated", "generated", "imported", "generated"],
  );
  assert.equal(mixedSlice.manifest.generator.arbitraryIndependentUnitStorage, true);
  assert.match(mixedSlice.manifest.generator.information, /800 bits into 160/);
  assert.match(mixedSlice.manifest.generator.information, /not an injective embedding/);
  assert.deepEqual(
    mixedSlice.manifest.wordWitnesses!.map((witness) => witness.axis),
    [0, 3],
  );
  const implicit = sampleSlice(cfg),
    explicit = sampleSlice(cfg, EMPTY_WORD_SOURCES);
  assert.deepEqual(explicit.manifest, implicit.manifest);
  assert.equal(implicit.manifest.schema, "RUSSL-five-word-cube/2");
  assert.equal("wordWitnesses" in implicit.manifest, false);
  assert(implicit.manifest.words.every((word) => !("source" in word)));
});

test("imported odd boundary and partial appliance units retain their exact source bits", async () => {
  const bytes = Uint8Array.from({ length: 41 }, (_, index) => (index * 17 + 13) & 255);
  bytes[40] = 0xad;
  const source = await importRawWord(bytes, { name: "ceiling-uww.bin", format: "appliance-le" });
  assert.equal(source.unitCount, 3n);
  assert.equal(source.paddingBits, 152);
  assert.deepEqual(decodeStatePixel160(source.unit(2n)), { q: 0n, p: 0xadn });
  const sources: WordSources = [null, null, null, null, source];
  const cfg = config({ fixed: ["0", "0", "1", "1", "2"] }),
    slice = sampleSlice(cfg, sources);
  assert(slice.cells.every((cell) => cell.partnerIndex === null));
  for (const cell of slice.cells) {
    assert.deepEqual(cell.wordUnits[4], source.unit(2n));
    assert.deepEqual(cell.state, advanceCell(cell.initial, 7n, "gf80"));
    assert(verifyInverse(cell, cfg, sources));
  }
  assert.deepEqual(slice.manifest.wordWitnesses![0].units, [
    { index: "2", pixelHex: pixelHex(source.unit(2n)) },
  ]);
  const imported = slice.manifest.words[4];
  assert.equal(imported.source, "imported");
  if (imported.source !== "imported") throw new Error("Expected imported source metadata");
  assert.equal(imported.paddingBits, 152);
  assert.equal(imported.sourceBits, 328);
});

test("word witnesses cover every observed and off-tile partner source coordinate exactly", async () => {
  const sources = await importedFixtures(),
    cfg = config(),
    slice = sampleSlice(cfg, sources);
  assert.equal(slice.cells.length, 4);
  assert.equal(slice.manifest.slice.evaluatedCells, 8);
  assert(
    slice.cells.every((cell) => unpackCoordinates(cell.partnerIndex!, dimensionsOf(cfg))[4] === 1n),
  );
  assert.equal(slice.manifest.wordWitnesses!.length, 5);
  for (const witness of slice.manifest.wordWitnesses!) {
    const expected = new Set<string>();
    for (const cell of slice.cells) {
      expected.add(cell.coords[witness.axis].toString());
      if (cell.partnerIndex !== null)
        expected.add(
          unpackCoordinates(cell.partnerIndex, dimensionsOf(cfg))[witness.axis].toString(),
        );
    }
    const sorted = [...expected].sort((a, b) =>
      BigInt(a) < BigInt(b) ? -1 : BigInt(a) > BigInt(b) ? 1 : 0,
    );
    assert.deepEqual(
      witness.units.map((unit) => unit.index),
      sorted,
    );
    for (const unit of witness.units)
      assert.equal(unit.pixelHex, pixelHex(sources[witness.axis]!.unit(BigInt(unit.index))));
    assert(witness.units.length < Number(sources[witness.axis]!.unitCount));
    assert.equal(witness.unitCount, sources[witness.axis]!.unitCount.toString());
  }
  for (let axis = 0; axis < 5; axis++) {
    const word = slice.manifest.words[axis];
    assert.equal(word.source, "imported");
    if (word.source !== "imported") throw new Error("Expected imported source metadata");
    assert.equal(word.entry, `words/${axis}-${AXIS_NAMES[axis]}.bin`);
    assert.equal(word.originalName, sources[axis]!.name);
    assert.equal(word.sourceSha256, sources[axis]!.sha256);
    assert.equal(word.canonicalSha256, sources[axis]!.canonicalSha256);
    assert.equal(word.sourceByteLength, sources[axis]!.sourceByteLength);
    assert.equal(word.sourceFormat, sources[axis]!.format);
  }
});

test("source snapshots and returned units or states cannot mutate subsequent trajectories", async () => {
  const imported = await importedFixtures(),
    sources = [...imported] as (ImportedWord | null)[];
  const cfg = config(),
    field = virtualField(cfg, sources as unknown as WordSources),
    before = field.observe(0n);
  const expectedState = { ...before.state },
    expectedUnits = before.wordUnits.map((unit) => [...unit]);
  sources[0] = null;
  imported[0]!.bytes().fill(0);
  imported[0]!.canonicalBytes().fill(0);
  const unit = field.generator.wordUnit(0, 0n),
    state = field.generator.stateAt(0n);
  unit[0] ^= 1;
  state.q ^= 1n;
  before.wordUnits[0][0] ^= 1;
  before.state.q ^= 1n;
  before.partnerState!.p ^= 1n;
  const after = field.observe(0n);
  assert.deepEqual(after.state, expectedState);
  assert.deepEqual(after.wordUnits, expectedUnits);
  assert.equal(after.initialInvariant, after.currentInvariant);
  assert(Object.isFrozen(field));
  assert(Object.isFrozen(field.sources));
  assert(field.sources.every((source) => source === null || Object.isFrozen(source)));
  assert(Object.isFrozen(field.generator));
});

test("raw replay reproduces exact Pixel160 states and zero-step replay checks active source data", async () => {
  const sources = await importedFixtures(),
    cfg = config(),
    slice = sampleSlice(cfg, sources);
  const replayConfig = JSON.parse(JSON.stringify(slice.manifest.config)) as SliceConfig;
  const replay = sampleSlice(replayConfig, sources);
  assert.deepEqual(replay.pixelBytes, slice.pixelBytes);
  assert.deepEqual(replay.manifest.fullStatesHex, slice.manifest.fullStatesHex);
  for (const cell of replay.cells) {
    assert.deepEqual(decodeStatePixel160(cell.pixel), cell.state);
    assert(verifyInverse(cell, replayConfig, sources));
  }
  const initialConfig = config({ tick: "0" }),
    observation = virtualField(initialConfig, sources).observe(0n);
  assert(verifyInverse(observation, initialConfig, sources));
  observation.state.p ^= 1n;
  assert.equal(verifyInverse(observation, initialConfig, sources), false);
});

test("mismatched raw dimensions, malformed descriptors and sparse source arrays are rejected", async () => {
  const sources = await importedFixtures(),
    cfg = config();
  const mismatch = config({ words: ["5", "4", "3", "3", "3"] });
  assert.throws(() => virtualField(mismatch, sources), /imported unit count/);
  assert.throws(() => sampleSlice(mismatch, sources), /imported unit count/);
  const observation = virtualField(config({ tick: "0" }), sources).observe(0n);
  assert.throws(
    () => verifyInverse(observation, { ...mismatch, tick: "0" }, sources),
    /imported unit count/,
  );
  assert.throws(
    () => virtualField(cfg, new Array(5) as unknown as WordSources),
    /Invalid imported/,
  );
  assert.throws(() => virtualField(cfg, [null, null] as unknown as WordSources), /exactly five/);
  assert.throws(
    () => virtualField(cfg, [undefined, null, null, null, null] as unknown as WordSources),
    /Invalid imported/,
  );
  for (const patch of [
    { kind: "generated" },
    { sha256: "bad" },
    { canonicalSha256: "bad" },
    { sourceByteLength: 0 },
    { sourceBits: 1 },
    { paddingBits: 160 },
    { sourceBits: sources[0]!.sourceBits - 8 },
    { unit: null },
    { bytes: null },
  ]) {
    const malformed = [{ ...sources[0]!, ...patch }, ...sources.slice(1)] as unknown as WordSources;
    assert.throws(() => virtualField(cfg, malformed), /Invalid imported/);
  }
  const badLane = [
    { ...sources[0]!, unit: () => [-1, 0, 0, 0, 0] },
    ...sources.slice(1),
  ] as unknown as WordSources;
  assert.throws(() => virtualField(cfg, badLane).observe(0n), /unsigned 32-bit/);
});
