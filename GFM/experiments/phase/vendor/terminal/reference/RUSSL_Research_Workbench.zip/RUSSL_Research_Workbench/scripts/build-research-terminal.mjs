import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const source = path.join(root, "vendor/gfm-research-terminal/dist");
const read = (name) => readFile(path.join(source, name), "utf8");
const [style, icon, engine, quantum, penteract, app, corpus, metadata, validation] =
  await Promise.all(
    [
      "styles.css",
      "icon.svg",
      "engine.js",
      "quantum.js",
      "penteract.js",
      "app.js",
      "corpus.json",
      "corpus-meta.json",
      "validation.json",
    ].map(read),
  );
let integrationValidation = {
  status: "PENDING",
  scope: "Combined browser validation is pending; original source checks are retained separately.",
};
try {
  integrationValidation = JSON.parse(
    await readFile(path.join(root, "validation/research-runtime-validation.json"), "utf8"),
  );
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}
const bundle = {
  "corpus.json": JSON.parse(corpus),
  "corpus-meta.json": JSON.parse(metadata),
  "validation.json": {
    schema: "RUSSL-RESEARCH-INTEGRATION-VALIDATION/1",
    integration: integrationValidation,
    sourceTerminalReport: JSON.parse(validation),
  },
  NOTICE: await read("NOTICE"),
  LICENSE: await read("LICENSE"),
  COPYRIGHT: await read("COPYRIGHT"),
  "THIRD-PARTY-NOTICES.txt": await read("THIRD-PARTY-NOTICES.txt"),
};
const script =
  `globalThis.GFMBundle=${JSON.stringify(bundle).replace(/</g, "\\u003c")};\n${engine}\n${quantum}\n${penteract}\n${app}`.replace(
    /<\/script/gi,
    "<\\/script",
  );
const dataUrl = (mime, text) => `data:${mime};base64,${Buffer.from(text).toString("base64")}`;
let html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GFM research terminal</title><style>${style}</style></head><body><div id="app"></div><noscript>This research terminal needs JavaScript.</noscript><script>${script}</script></body></html>`;
// All accession data and notices stay embedded. No network fetch is needed.
html = html.replace(/src=\\?"icon\.svg\\?"/g, `src=\\"${dataUrl("image/svg+xml", icon)}\\"`);
for (const name of ["NOTICE", "LICENSE", "COPYRIGHT", "THIRD-PARTY-NOTICES.txt"]) {
  const contents = await read(name);
  html = html.replaceAll(
    `href=\\"${name}\\"`,
    `href=\\"${dataUrl("text/plain;charset=utf-8", contents)}\\"`,
  );
  html = html.replaceAll(
    `href="${name}"`,
    `href="${dataUrl("text/plain;charset=utf-8", contents)}"`,
  );
}
const destination = path.join(root, "src/lib/research-terminal");
await mkdir(destination, { recursive: true });
await writeFile(path.join(destination, "terminal.html"), html);
console.log("Embedded research terminal built from preserved vendor sources.");
