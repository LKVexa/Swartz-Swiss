import { gfAdd, gfMul, validateElement } from "./field.ts";
import type { FieldId } from "./field.ts";

export type PhaseState = { q: bigint; p: bigint };
export type PairState = [PhaseState, PhaseState];

export const MAX_TICK = (1n << 32n) - 1n;

function validateState(state: PhaseState, field: FieldId): void {
  if (state === null || typeof state !== "object") {
    throw new TypeError("A cell state requires q and p");
  }
  validateElement(state.q, field);
  validateElement(state.p, field);
}

function validatePair(pair: PairState, field: FieldId): void {
  if (!Array.isArray(pair) || pair.length !== 2) {
    throw new TypeError("A pair requires exactly two cell states");
  }
  for (const state of Array.from(pair)) validateState(state, field);
}

function validateTick(tick: bigint): void {
  if (typeof tick !== "bigint") throw new TypeError("Tick must be an exact BigInt value");
  if (tick < 0n || tick > MAX_TICK) {
    throw new RangeError("Tick must be in [0, 2^32-1]");
  }
}

export function stepCell(state: PhaseState, field: FieldId, kappa = 2n): PhaseState {
  validateState(state, field);
  validateElement(kappa, field);
  const p = gfAdd(state.p, gfMul(kappa, state.q, field));
  return { q: gfAdd(state.q, p), p };
}

export function inverseCell(state: PhaseState, field: FieldId, kappa = 2n): PhaseState {
  validateState(state, field);
  validateElement(kappa, field);
  const q = gfAdd(state.q, state.p);
  return { q, p: gfAdd(state.p, gfMul(kappa, q, field)) };
}

export function cellInvariant(state: PhaseState, field: FieldId, kappa = 2n): bigint {
  validateState(state, field);
  validateElement(kappa, field);
  return (
    gfMul(kappa, gfMul(state.q, state.q, field), field) ^
    gfMul(kappa, gfMul(state.q, state.p, field), field) ^
    gfMul(state.p, state.p, field)
  );
}

export function stepPair(pair: PairState, field: FieldId, kappa = 2n, coupling = 1n): PairState {
  validatePair(pair, field);
  validateElement(kappa, field);
  validateElement(coupling, field);
  const p0 = pair[0].p ^ gfMul(kappa, pair[0].q, field) ^ gfMul(coupling, pair[1].q, field);
  const p1 = pair[1].p ^ gfMul(coupling, pair[0].q, field) ^ gfMul(kappa, pair[1].q, field);
  return [
    { q: pair[0].q ^ p0, p: p0 },
    { q: pair[1].q ^ p1, p: p1 },
  ];
}

export function inversePair(pair: PairState, field: FieldId, kappa = 2n, coupling = 1n): PairState {
  validatePair(pair, field);
  validateElement(kappa, field);
  validateElement(coupling, field);
  const q0 = pair[0].q ^ pair[0].p;
  const q1 = pair[1].q ^ pair[1].p;
  return [
    { q: q0, p: pair[0].p ^ gfMul(kappa, q0, field) ^ gfMul(coupling, q1, field) },
    { q: q1, p: pair[1].p ^ gfMul(coupling, q0, field) ^ gfMul(kappa, q1, field) },
  ];
}

export function pairInvariant(pair: PairState, field: FieldId, kappa = 2n, coupling = 1n): bigint {
  validatePair(pair, field);
  validateElement(kappa, field);
  validateElement(coupling, field);
  // H=Q^T K Q+Q^T K P+P^T P. Symmetric off-diagonal Q terms cancel in characteristic2.
  return (
    cellInvariant(pair[0], field, kappa) ^
    cellInvariant(pair[1], field, kappa) ^
    gfMul(coupling, gfMul(pair[0].q, pair[1].p, field), field) ^
    gfMul(coupling, gfMul(pair[1].q, pair[0].p, field), field)
  );
}

type Matrix = bigint[][];
const MATRIX_CACHE_LIMIT = 64;
const poweredMatrices = new Map<string, Matrix>();

function identity(size: number): Matrix {
  return Array.from({ length: size }, (_, row) =>
    Array.from({ length: size }, (_, column) => (row === column ? 1n : 0n)),
  );
}

function multiplyMatrix(left: Matrix, right: Matrix, field: FieldId): Matrix {
  const size = left.length;
  return Array.from({ length: size }, (_, row) =>
    Array.from({ length: size }, (_, column) => {
      let value = 0n;
      for (let term = 0; term < size; term++) {
        if (left[row][term] !== 0n && right[term][column] !== 0n) {
          value ^= gfMul(left[row][term], right[term][column], field);
        }
      }
      return value;
    }),
  );
}

function powerMatrix(matrix: Matrix, tick: bigint, field: FieldId, cacheKey: string): Matrix {
  const cached = poweredMatrices.get(cacheKey);
  if (cached) {
    poweredMatrices.delete(cacheKey);
    poweredMatrices.set(cacheKey, cached);
    return cached;
  }
  let result = identity(matrix.length);
  let factor = matrix;
  let power = tick;
  while (power !== 0n) {
    if (power & 1n) result = multiplyMatrix(result, factor, field);
    power >>= 1n;
    if (power !== 0n) factor = multiplyMatrix(factor, factor, field);
  }
  if (poweredMatrices.size >= MATRIX_CACHE_LIMIT) {
    const oldest = poweredMatrices.keys().next().value;
    if (oldest !== undefined) poweredMatrices.delete(oldest);
  }
  poweredMatrices.set(cacheKey, result);
  return result;
}

function applyMatrix(matrix: Matrix, vector: bigint[], field: FieldId): bigint[] {
  return matrix.map((row) =>
    row.reduce((sum, coefficient, column) => {
      return coefficient === 0n || vector[column] === 0n
        ? sum
        : sum ^ gfMul(coefficient, vector[column], field);
    }, 0n),
  );
}

export function advanceCell(
  state: PhaseState,
  tick: bigint,
  field: FieldId,
  kappa = 2n,
): PhaseState {
  validateState(state, field);
  validateElement(kappa, field);
  validateTick(tick);
  if (tick === 0n) return { ...state };
  const matrix: Matrix = [
    [1n ^ kappa, 1n],
    [kappa, 1n],
  ];
  const powered = powerMatrix(matrix, tick, field, `cell:${field}:${kappa}:${tick}`);
  const [q, p] = applyMatrix(powered, [state.q, state.p], field);
  return { q, p };
}

export function advancePair(
  pair: PairState,
  tick: bigint,
  field: FieldId,
  kappa = 2n,
  coupling = 1n,
): PairState {
  validatePair(pair, field);
  validateElement(kappa, field);
  validateElement(coupling, field);
  validateTick(tick);
  if (tick === 0n) return [{ ...pair[0] }, { ...pair[1] }];
  const matrix: Matrix = [
    [1n ^ kappa, coupling, 1n, 0n],
    [coupling, 1n ^ kappa, 0n, 1n],
    [kappa, coupling, 1n, 0n],
    [coupling, kappa, 0n, 1n],
  ];
  const powered = powerMatrix(matrix, tick, field, `pair:${field}:${kappa}:${coupling}:${tick}`);
  const [q0, q1, p0, p1] = applyMatrix(
    powered,
    [pair[0].q, pair[1].q, pair[0].p, pair[1].p],
    field,
  );
  return [
    { q: q0, p: p0 },
    { q: q1, p: p1 },
  ];
}
