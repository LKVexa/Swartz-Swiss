import assert from "node:assert/strict";
import test from "node:test";
import { anti, complement, modPow2, runBench } from "./ops.ts";

test("eight-bit example separates complement from negation", () => {
  assert.equal(complement(13n, 8), 242n);
  assert.equal(anti(13n, 8), 243n);
  assert.equal(modPow2(13n + 242n, 8), 255n);
  assert.equal(modPow2(13n + 243n, 8), 0n);
  assert.equal(modPow2(complement(13n, 8) + 1n, 8), anti(13n, 8));
});

test("involution pair is the successor", () => {
  for (const x of [0n, 1n, 13n, 255n]) {
    assert.equal(anti(complement(x, 8), 8), modPow2(x + 1n, 8));
    assert.equal(complement(anti(x, 8), 8), modPow2(x - 1n, 8));
  }
});

test("milestone bench recovers the field and a fault breaks it", () => {
  const clean = runBench({
    width: 8,
    word: 13n,
    bins: 32,
    faultOn: false,
    faultBin: 3,
    faultBit: 0,
  });
  assert.equal(clean.sumAnti, "0");
  assert.ok(clean.checks.every((check) => check.hold));
  assert.ok(clean.cleanRecovery.max < 1e-8);
  assert.equal(clean.faultSyndrome, "0");
  assert.equal(clean.paired[0].x, "13");
  assert.equal(clean.paired[0].a, "243");
  assert.equal(clean.paired[1].x, "44");
  assert.equal(clean.paired[1].a, "212");
  assert.ok(clean.paired.every((row) => row.sum === "0"));
  assert.ok(clean.ladder.every((rung) => rung.agrees && rung.low8 === "13"));
  assert.equal(clean.interference.intensityMatch, true);
  assert.ok(clean.interference.quadErr < 1e-12);

  const dirty = runBench({
    width: 8,
    word: 13n,
    bins: 32,
    faultOn: true,
    faultBin: 3,
    faultBit: 0,
  });
  assert.notEqual(dirty.faultSyndrome, "0");
  assert.ok(dirty.recovery.rms > 1e-3);
  assert.equal(dirty.decode.status, "corrected");
  assert.equal(dirty.decode.bit, "0");
  assert.ok(dirty.decode.correctedMax < 1e-8);

  const two = runBench({
    width: 8,
    word: 13n,
    bins: 32,
    faultOn: true,
    faultBin: 3,
    faultBit: 0,
    secondFault: true,
  });
  assert.equal(two.decode.status, "uncorrectable");
  assert.ok(two.decode.correctedMax > 1e-3);
  assert.equal(two.decode2.status, "corrected");
  assert.equal(two.decode2.bits, "0,1");
  assert.ok(two.decode2.correctedMax < 1e-8);
  assert.equal(two.exact.holds, true);
  assert.ok(two.byte.worst < 1e-8);
  assert.ok(two.complementMax > 1e-3);
  assert.ok(two.superposition.linearMax < 1e-8);
  assert.ok(two.superposition.crossMax > 1e-3);
});

test("wider residues keep the same identities", () => {
  const wide = runBench({
    width: 16,
    word: 13n + 0xab00n,
    bins: 32,
    faultOn: false,
    faultBin: 3,
    faultBit: 4,
  });
  assert.ok(wide.checks.every((check) => check.hold));
  assert.equal(modPow2(BigInt(wide.word), 8), 13n);
  assert.equal(wide.phaseScope.exhaustive, true);
  assert.equal(wide.phaseScope.samples, 65536);

  const sampled = runBench({
    width: 32,
    word: 13n,
    bins: 32,
    faultOn: false,
    faultBin: 3,
    faultBit: 0,
  });
  assert.equal(sampled.phaseScope.exhaustive, false);
  assert.ok(sampled.phaseScope.samples < 4096);
  assert.ok(sampled.checks.every((check) => check.hold));
});
