import { gfAdd, gfInv, gfMul, gfPow } from "./galois.ts";

export const AES_POLY = 0x1bn;

const AES_SBOX = [
  0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
] as const;

export type SboxReport = {
  byte: string;
  inverse: string;
  image: string;
  holds: boolean;
};

export type ErasureReport = {
  symbols: [string, string, string];
  erased: 0 | 1 | 2;
  recovered: string;
  holds: boolean;
};

function affine(inverse: number): number {
  let image = 0;
  for (let index = 0; index < 8; index++) {
    const bit =
      ((inverse >> index) ^
        (inverse >> ((index + 4) % 8)) ^
        (inverse >> ((index + 5) % 8)) ^
        (inverse >> ((index + 6) % 8)) ^
        (inverse >> ((index + 7) % 8)) ^
        (0x63 >> index)) &
      1;
    image |= bit << index;
  }
  return image;
}

export function aesSbox(byte: number): SboxReport {
  const value = byte & 0xff;
  const inverse = value === 0 ? 0n : gfPow(BigInt(value), 254n, 8, AES_POLY);
  const image = affine(Number(inverse));
  const known = value < AES_SBOX.length ? image === AES_SBOX[value] : true;
  return {
    byte: value.toString(16).padStart(2, "0"),
    inverse: inverse.toString(16).padStart(2, "0"),
    image: image.toString(16).padStart(2, "0"),
    holds: known && (value === 0 || gfMul(BigInt(value), inverse, 8, AES_POLY) === 1n),
  };
}

export function eraseSymbol(secret: bigint, partner: bigint, bits: number, erased: 0 | 1 | 2): ErasureReport {
  const mask = (1n << BigInt(bits)) - 1n;
  const data0 = secret & mask;
  const data1 = partner & mask;
  const alpha = 2n;
  const points = [1n, alpha, gfMul(alpha, alpha, bits)];
  const symbols = points.map((point) => gfAdd(data0, gfMul(data1, point, bits))) as [bigint, bigint, bigint];
  const kept = [0, 1, 2].filter((index) => index !== erased) as [number, number];
  const [left, right] = kept;
  const slope = gfMul(gfAdd(symbols[left], symbols[right]), gfInv(gfAdd(points[left], points[right]), bits)!, bits);
  const intercept = gfAdd(symbols[left], gfMul(slope, points[left], bits));
  const recovered = gfAdd(intercept, gfMul(slope, points[erased], bits));
  return {
    symbols: [symbols[0].toString(), symbols[1].toString(), symbols[2].toString()],
    erased,
    recovered: recovered.toString(),
    holds: recovered === symbols[erased] && intercept === data0 && slope === data1,
  };
}
