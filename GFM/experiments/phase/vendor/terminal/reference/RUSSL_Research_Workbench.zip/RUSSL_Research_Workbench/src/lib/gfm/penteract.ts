import { gfMul, fieldMask, FIELD_INFO } from "./field.ts";
import {
  advanceCell,
  advancePair,
  inverseCell,
  inversePair,
  cellInvariant,
  pairInvariant,
  MAX_TICK,
} from "./dynamics.ts";
import type { PhaseState, PairState } from "./dynamics.ts";
import { encodeStatePixel160, decodeStatePixel160, encodePixel160, pixelHex } from "./pixel.ts";
import type { Pixel160 } from "./pixel.ts";
import { EMPTY_WORD_SOURCES } from "./raw-words.ts";
import type { ImportedWord, WordSources } from "./raw-words.ts";

export const AXIS_NAMES = ["length", "width", "depth", "height", "ceiling"] as const;
export const GENERATOR_ID = "five-uww-pixel160-units-v1";
export const PIXEL_PROFILE = "gfm-full-state-q80-p80-v1";
export type FiveStrings = [string, string, string, string, string];
export type SliceConfig = {
  words: FiveStrings;
  seed: string;
  tick: string;
  mode: "cell" | "pair";
  kappa: string;
  coupling: string;
  couplingAxis: number;
  axes: [number, number];
  fixed: FiveStrings;
  origin: [string, string];
  size: number;
};
export const DEFAULT_CONFIG: SliceConfig = {
  words: ["64", "64", "8", "8", "8"],
  seed: "13",
  tick: "0",
  mode: "pair",
  kappa: "2",
  coupling: "1",
  couplingAxis: 0,
  axes: [0, 1],
  fixed: ["0", "0", "2", "3", "4"],
  origin: ["0", "0"],
  size: 16,
};
export function parseExact(text: string, label: string, maximum?: bigint): bigint {
  if (typeof text !== "string" || text.length > 1024 || !/^(?:\d+|0x[0-9a-f]+)$/i.test(text.trim()))
    throw new Error(`${label} requires a nonnegative integer.`);
  const value = BigInt(text.trim());
  if (maximum !== undefined && value > maximum)
    throw new Error(`${label} must be at most ${maximum}.`);
  return value;
}
function checkAxis(axis: number): void {
  if (!Number.isInteger(axis) || axis < 0 || axis > 4)
    throw new Error("Choose one of the five word axes.");
}
function checkDimensions(dimensions: readonly bigint[]): void {
  if (
    dimensions.length !== 5 ||
    Array.from(dimensions).some((n) => typeof n !== "bigint" || n < 1n)
  )
    throw new Error("Five nonempty ultra-wide words are required.");
}
export function dimensionsOf(config: SliceConfig): bigint[] {
  if (!Array.isArray(config.words) || config.words.length !== 5)
    throw new Error("Provide one ultra-wide word for each axis.");
  const lengths = Array.from(config.words).map((v, i) =>
    parseExact(v, `${AXIS_NAMES[i]} word units`),
  );
  checkDimensions(lengths);
  return lengths;
}
export function domainSize(dimensions: readonly bigint[]): bigint {
  checkDimensions(dimensions);
  return dimensions.reduce((n, d) => n * d, 1n);
}
const defaults = () => DEFAULT_CONFIG.words.map(BigInt);
export function packCoordinates(
  coords: readonly bigint[],
  dimensions: readonly bigint[] = defaults(),
): bigint {
  checkDimensions(dimensions);
  if (coords.length !== 5) throw new Error("A 5-cube address requires five coordinates.");
  let address = 0n,
    stride = 1n;
  for (let axis = 0; axis < 5; axis++) {
    const coord = coords[axis];
    if (typeof coord !== "bigint" || coord < 0n || coord >= dimensions[axis])
      throw new Error(`${AXIS_NAMES[axis]} coordinate lies outside its word.`);
    address += coord * stride;
    stride *= dimensions[axis];
  }
  return address;
}
export function unpackCoordinates(
  index: bigint,
  dimensions: readonly bigint[] = defaults(),
): bigint[] {
  if (typeof index !== "bigint" || index < 0n || index >= domainSize(dimensions))
    throw new Error("Address lies outside this 5-cube.");
  let remainder = index;
  return dimensions.map((length) => {
    const coord = remainder % length;
    remainder /= length;
    return coord;
  });
}
export function validateConfig(input: SliceConfig): SliceConfig {
  const lengths = dimensionsOf(input);
  if (input.mode !== "cell" && input.mode !== "pair")
    throw new Error("Choose single cells or coupled neighbors.");
  if (
    !Array.isArray(input.axes) ||
    input.axes.length !== 2 ||
    !Array.isArray(input.fixed) ||
    input.fixed.length !== 5 ||
    !Array.isArray(input.origin) ||
    input.origin.length !== 2
  )
    throw new Error("The slice needs two axes, five fixed coordinates and an origin.");
  Array.from(input.axes).forEach(checkAxis);
  checkAxis(input.couplingAxis);
  if (input.axes[0] === input.axes[1])
    throw new Error("The horizontal and vertical axes must differ.");
  if (![1, 2, 4, 8, 16, 32].includes(input.size))
    throw new Error("Slice size must be 1, 2, 4, 8, 16 or 32.");
  if (input.axes.some((axis) => lengths[axis] < BigInt(input.size)))
    throw new Error(
      "The slice must fit inside both selected words. Choose a smaller slice or longer words.",
    );
  const seed = parseExact(input.seed, "Word seed"),
    tick = parseExact(input.tick, "Step", MAX_TICK),
    mask = fieldMask("gf80");
  const kappa = parseExact(input.kappa, "Cell coefficient", mask),
    coupling = parseExact(input.coupling, "Coupling", mask);
  const fixed = Array.from(input.fixed).map((v, i) => {
    const inSlice = input.axes.includes(i);
    const value = parseExact(
      v,
      `${AXIS_NAMES[i]} coordinate`,
      inSlice ? undefined : lengths[i] - 1n,
    );
    return inSlice ? "0" : value.toString();
  }) as FiveStrings;
  const origin = Array.from(input.origin).map((v, i) =>
    parseExact(v, `Slice origin ${i}`, lengths[input.axes[i]] - BigInt(input.size)).toString(),
  ) as [string, string];
  return {
    ...input,
    words: lengths.map(String) as FiveStrings,
    seed: seed.toString(),
    tick: tick.toString(),
    kappa: kappa.toString(),
    coupling: coupling.toString(),
    fixed,
    origin,
    axes: [...input.axes],
  };
}
// A named virtual-word recipe, not an injective encoding of arbitrary integers.
export function foldInteger(value: bigint): bigint {
  if (typeof value !== "bigint" || value < 0n)
    throw new Error("A word index or seed must be nonnegative.");
  const bytes: bigint[] = [];
  let n = value;
  do {
    bytes.push(n & 255n);
    n >>= 8n;
  } while (n);
  return bytes.reverse().reduce((state, byte) => gfMul(state, 256n, "gf80") ^ byte, 0n);
}
export function makeWordGenerator(seed: bigint, dimensions: readonly bigint[]) {
  checkDimensions(dimensions);
  const lengths = [...dimensions],
    s = foldInteger(seed);
  const parameters = AXIS_NAMES.map((name, axis) => {
    const salt = s ^ gfMul(BigInt(axis + 1), 0x13579bdf2468ace1n, "gf80");
    return {
      name,
      length: lengths[axis].toString(),
      unitBytes: 20,
      virtualWordBytes: (lengths[axis] * 20n).toString(),
      aq: salt || 1n,
      ap: salt ^ 0x4d595df4d0f33173n || 1n,
      bq: gfMul(salt, 0xc4e17d938abn, "gf80"),
      bp: gfMul(salt, salt, "gf80"),
    };
  });
  const unitState = (axis: number, index: bigint): PhaseState => {
    checkAxis(axis);
    if (typeof index !== "bigint" || index < 0n || index >= lengths[axis])
      throw new Error("Unit index lies outside its word.");
    const p = parameters[axis],
      i = foldInteger(index);
    return { q: gfMul(p.aq, i, "gf80") ^ p.bq, p: gfMul(p.ap, i, "gf80") ^ p.bp };
  };
  return Object.freeze({
    parameters: Object.freeze(parameters.map((p) => Object.freeze(p))),
    wordUnit: (axis: number, index: bigint): Pixel160 =>
      encodeStatePixel160(unitState(axis, index)),
    stateAt: (index: bigint): PhaseState => {
      const coords = unpackCoordinates(index, lengths);
      let q = 0n,
        p = 0n;
      for (let axis = 0; axis < 5; axis++) {
        const unit = unitState(axis, coords[axis]);
        q ^= gfMul(unit.q, BigInt(axis + 1), "gf80");
        p ^= gfMul(unit.p, BigInt(3 * (axis + 1)), "gf80");
      }
      return { q, p };
    },
  });
}
export type CellObservation = {
  index: bigint;
  coords: bigint[];
  initial: PhaseState;
  state: PhaseState;
  pixel: Pixel160;
  wordUnits: Pixel160[];
  partnerIndex: bigint | null;
  partnerInitial: PhaseState | null;
  partnerState: PhaseState | null;
  initialInvariant: bigint;
  currentInvariant: bigint;
  cellInvariant: bigint;
};

function validatedSources(sources: WordSources, dimensions: readonly bigint[]): WordSources {
  if (!Array.isArray(sources) || sources.length !== 5) {
    throw new Error("Provide exactly five word sources; use null for generated axes.");
  }
  const snapshot = Array.from(sources).map((source, axis): ImportedWord | null => {
    if (source === null) return null;
    if (
      !source ||
      typeof source !== "object" ||
      source.kind !== "imported" ||
      (source.format !== "appliance-le" && source.format !== "russl-be") ||
      typeof source.name !== "string" ||
      source.name.length < 1 ||
      source.name.length > 255 ||
      !source.name.trim() ||
      Array.from(String(source.name)).some((character) => {
        const code = character.charCodeAt(0);
        return code < 32 || code === 127 || character === "/" || character === "\\";
      }) ||
      source.name === "." ||
      source.name === ".." ||
      typeof source.unitCount !== "bigint" ||
      source.unitCount < 1n ||
      !Number.isSafeInteger(source.sourceByteLength) ||
      source.sourceByteLength < 1 ||
      source.sourceByteLength > Math.floor(Number.MAX_SAFE_INTEGER / 8) ||
      !Number.isSafeInteger(source.sourceBits) ||
      source.sourceBits < 8 ||
      source.sourceBits > source.sourceByteLength * 8 ||
      Math.ceil(source.sourceBits / 8) !== source.sourceByteLength ||
      (source.format === "appliance-le" && source.sourceByteLength > 131072) ||
      (source.format === "russl-be" &&
        (source.sourceByteLength > 8 * 1024 * 1024 ||
          source.sourceByteLength % 20 !== 0 ||
          source.sourceBits !== source.sourceByteLength * 8)) ||
      !Number.isSafeInteger(source.paddingBits) ||
      source.paddingBits < 0 ||
      source.paddingBits > 159 ||
      BigInt(source.sourceBits) + BigInt(source.paddingBits) !== source.unitCount * 160n ||
      typeof source.sha256 !== "string" ||
      !/^[0-9a-f]{64}$/i.test(source.sha256) ||
      typeof source.canonicalSha256 !== "string" ||
      !/^[0-9a-f]{64}$/i.test(source.canonicalSha256) ||
      typeof source.unit !== "function" ||
      typeof source.bytes !== "function" ||
      typeof source.canonicalBytes !== "function"
    ) {
      throw new Error(`Invalid imported ${AXIS_NAMES[axis]} word descriptor.`);
    }
    if (source.unitCount !== dimensions[axis]) {
      throw new Error(
        `${AXIS_NAMES[axis]} word length must equal its imported unit count ${source.unitCount}.`,
      );
    }
    // Capture immutable metadata and method references; caller array edits cannot change the provider.
    return Object.freeze({
      kind: "imported" as const,
      name: source.name,
      format: source.format,
      unitCount: source.unitCount,
      sourceByteLength: source.sourceByteLength,
      sourceBits: source.sourceBits,
      paddingBits: source.paddingBits,
      sha256: source.sha256,
      canonicalSha256: source.canonicalSha256,
      unit: source.unit.bind(source),
      bytes: source.bytes.bind(source),
      canonicalBytes: source.canonicalBytes.bind(source),
    });
  });
  return Object.freeze(snapshot) as WordSources;
}

export function virtualField(input: SliceConfig, sources: WordSources = EMPTY_WORD_SOURCES) {
  const config = validateConfig(input),
    dimensions = dimensionsOf(config),
    seed = BigInt(config.seed),
    tick = BigInt(config.tick),
    kappa = BigInt(config.kappa),
    coupling = BigInt(config.coupling);
  Object.freeze(dimensions);
  Object.freeze(config.words);
  Object.freeze(config.axes);
  Object.freeze(config.fixed);
  Object.freeze(config.origin);
  Object.freeze(config);
  const activeSources = validatedSources(sources, dimensions),
    virtualGenerator = makeWordGenerator(seed, dimensions),
    cache = new Map<string, PairState>();
  const wordUnit = (axis: number, index: bigint): Pixel160 => {
    checkAxis(axis);
    if (typeof index !== "bigint" || index < 0n || index >= dimensions[axis]) {
      throw new Error("Unit index lies outside its word.");
    }
    const source = activeSources[axis];
    const pixel = source ? source.unit(index) : virtualGenerator.wordUnit(axis, index);
    decodeStatePixel160(pixel); // Validate every lane; neither source bits nor state bits are masked.
    return [...pixel] as Pixel160;
  };
  const generator = Object.freeze({
    parameters: virtualGenerator.parameters,
    wordUnit,
    stateAt: (index: bigint): PhaseState => {
      const coordinates = unpackCoordinates(index, dimensions);
      let q = 0n,
        p = 0n;
      for (let axis = 0; axis < 5; axis++) {
        const unit = decodeStatePixel160(wordUnit(axis, coordinates[axis]));
        q ^= gfMul(unit.q, BigInt(axis + 1), "gf80");
        p ^= gfMul(unit.p, BigInt(3 * (axis + 1)), "gf80");
      }
      return { q, p };
    },
  });
  const observe = (index: bigint): CellObservation => {
    const coords = unpackCoordinates(index, dimensions),
      initial = generator.stateAt(index),
      wordUnits = coords.map((c, axis) => generator.wordUnit(axis, c));
    const partnerCoords = [...coords];
    partnerCoords[config.couplingAxis] ^= 1n;
    const paired =
      config.mode === "pair" &&
      partnerCoords[config.couplingAxis] < dimensions[config.couplingAxis];
    if (!paired) {
      const state = advanceCell(initial, tick, "gf80", kappa);
      return {
        index,
        coords,
        initial,
        state,
        pixel: encodeStatePixel160(state),
        wordUnits,
        partnerIndex: null,
        partnerInitial: null,
        partnerState: null,
        initialInvariant: cellInvariant(initial, "gf80", kappa),
        currentInvariant: cellInvariant(state, "gf80", kappa),
        cellInvariant: cellInvariant(state, "gf80", kappa),
      };
    }
    const partnerIndex = packCoordinates(partnerCoords, dimensions),
      low = index < partnerIndex ? index : partnerIndex,
      high = index < partnerIndex ? partnerIndex : index,
      slot = index === low ? 0 : 1;
    const initialPair: PairState = [generator.stateAt(low), generator.stateAt(high)];
    const key = low.toString();
    let pair = cache.get(key);
    if (!pair) {
      pair = advancePair(initialPair, tick, "gf80", kappa, coupling);
      cache.set(key, pair);
    }
    const state = { ...pair[slot] },
      partnerState = { ...pair[1 - slot] };
    return {
      index,
      coords,
      initial,
      state,
      pixel: encodeStatePixel160(state),
      wordUnits,
      partnerIndex,
      partnerInitial: initialPair[1 - slot],
      partnerState,
      initialInvariant: pairInvariant(initialPair, "gf80", kappa, coupling),
      currentInvariant: pairInvariant(pair, "gf80", kappa, coupling),
      cellInvariant: cellInvariant(state, "gf80", kappa),
    };
  };
  return Object.freeze({ config, dimensions, generator, observe, sources: activeSources });
}
export function verifyInverse(
  observation: CellObservation,
  config: SliceConfig,
  sources: WordSources = EMPTY_WORD_SOURCES,
): boolean {
  const normalized = validateConfig(config),
    tick = BigInt(normalized.tick);
  if (tick === 0n) {
    const expected = virtualField(normalized, sources).observe(observation.index);
    return (
      observation.state.q === expected.state.q &&
      observation.state.p === expected.state.p &&
      (observation.partnerState === null
        ? expected.partnerState === null
        : expected.partnerState !== null &&
          observation.partnerState.q === expected.partnerState.q &&
          observation.partnerState.p === expected.partnerState.p)
    );
  }
  const previous = virtualField({ ...normalized, tick: (tick - 1n).toString() }, sources).observe(
      observation.index,
    ),
    kappa = BigInt(config.kappa);
  if (observation.partnerState === null) {
    const recovered = inverseCell(observation.state, "gf80", kappa);
    return recovered.q === previous.state.q && recovered.p === previous.state.p;
  }
  if (!previous.partnerState) throw new Error("Coupled replay requires the partner state.");
  const recovered = inversePair(
    [observation.state, observation.partnerState],
    "gf80",
    kappa,
    BigInt(config.coupling),
  );
  return (
    recovered[0].q === previous.state.q &&
    recovered[0].p === previous.state.p &&
    recovered[1].q === previous.partnerState.q &&
    recovered[1].p === previous.partnerState.p
  );
}
const hex = (value: bigint) => value.toString(16).padStart(20, "0");
export function sampleSlice(input: SliceConfig, sources: WordSources = EMPTY_WORD_SOURCES) {
  const field = virtualField(input, sources),
    config = field.config,
    cells: CellObservation[] = [],
    pixels: Pixel160[] = [];
  const coordinates = config.fixed.map(BigInt),
    origin = config.origin.map(BigInt);
  for (let row = 0; row < config.size; row++)
    for (let column = 0; column < config.size; column++) {
      const coords = [...coordinates];
      coords[config.axes[0]] = origin[0] + BigInt(column);
      coords[config.axes[1]] = origin[1] + BigInt(row);
      const observation = field.observe(packCoordinates(coords, field.dimensions));
      cells.push(observation);
      pixels.push(observation.pixel);
    }
  const pixelBytes = new Uint8Array(cells.length * 20);
  cells.forEach((cell, i) => pixelBytes.set(encodePixel160(cell.pixel), i * 20));
  const dependencies = new Set(
    cells.flatMap((c) =>
      c.partnerIndex === null
        ? [c.index.toString()]
        : [c.index.toString(), c.partnerIndex.toString()],
    ),
  );
  const hasImportedSources = field.sources.some((source) => source !== null);
  const wordWitnesses = field.sources.flatMap((source, axis) => {
    if (!source) return [];
    const indices = new Set(
      [...dependencies].map((index) => unpackCoordinates(BigInt(index), field.dimensions)[axis]),
    );
    return [
      {
        axis,
        name: AXIS_NAMES[axis],
        unitCount: source.unitCount.toString(),
        units: [...indices]
          .sort((left, right) => (left < right ? -1 : left > right ? 1 : 0))
          .map((index) => ({
            index: index.toString(),
            pixelHex: pixelHex(field.generator.wordUnit(axis, index)),
          })),
      },
    ];
  });
  const manifest = {
    schema: hasImportedSources ? "RUSSL-five-word-cube/3" : "RUSSL-five-word-cube/2",
    config,
    domain: {
      axes: field.dimensions.map(String),
      axisNames: AXIS_NAMES,
      cells: domainSize(field.dimensions).toString(),
      packing: "mixed radix, length axis fastest; address=sum(ai*product(Lj,j<i))",
      coordinates: "external to Pixel160; five independent axes",
    },
    words: field.generator.parameters.map(({ aq, ap, bq, bp, ...p }, axis) => {
      const source = field.sources[axis];
      if (source)
        return {
          name: p.name,
          length: source.unitCount.toString(),
          unitBytes: 20,
          wordBytes: (source.unitCount * 20n).toString(),
          id: `word-${axis}-${p.name}`,
          source: "imported" as const,
          originalName: source.name,
          sourceFormat: source.format,
          sourceBits: source.sourceBits,
          sourceByteLength: source.sourceByteLength,
          paddingBits: source.paddingBits,
          sourceSha256: source.sha256,
          canonicalSha256: source.canonicalSha256,
          entry: `words/${axis}-${AXIS_NAMES[axis]}.bin`,
          unitCount: source.unitCount.toString(),
          unitProfile: PIXEL_PROFILE,
        };
      return {
        ...p,
        id: `word-${axis}-${p.name}`,
        unitCount: p.length,
        unitProfile: PIXEL_PROFILE,
        coefficientsHex: { aq: hex(aq), ap: hex(ap), bq: hex(bq), bp: hex(bp) },
        ...(hasImportedSources ? { source: "generated" as const } : {}),
      };
    }),
    field: {
      id: "gf80",
      characteristic: 2,
      degree: 80,
      polynomial: FIELD_INFO.gf80.polynomialLabel,
      basis: "binary polynomial; integer constants denote polynomial bit patterns, addition is XOR",
      purpose:
        "two 80-bit mechanical coordinates fit exactly in Pixel160; unrelated to axis lengths",
    },
    dynamics: {
      model: config.mode === "pair" ? "symmetric paired cells" : "independent cells",
      update: "P'=P+KQ; Q'=Q+P'",
      K:
        config.mode === "pair"
          ? [
              [config.kappa, config.coupling],
              [config.coupling, config.kappa],
            ]
          : [[config.kappa]],
      invariant: "Q^T K Q + Q^T K P + P^T P",
      pairing:
        config.mode === "pair"
          ? `${AXIS_NAMES[config.couplingAxis]} coordinate XOR 1, only when in bounds`
          : null,
      boundary: "last cell of an odd-length coupling word evolves independently",
      tick: config.tick,
      timeUnits: "none assigned",
      fieldInvariantMeaning: "field-valued invariant; no real positive energy asserted",
    },
    generator: {
      id: hasImportedSources ? "five-axis-source-pixel160-units-v1" : GENERATOR_ID,
      seed: config.seed,
      wordUnitRule: hasImportedSources
        ? "imported axes use exact source unit(index); generated axes use fold(i) by big-endian byte Horner in GF80, factor256; q=aq*fold(i)+bq; p=ap*fold(i)+bp"
        : "fold(i) by big-endian byte Horner in GF80, factor256; q=aq*fold(i)+bq; p=ap*fold(i)+bp",
      cellCombiner: "q0=sum((axis+1)*wordUnit.q); p0=sum(3*(axis+1)*wordUnit.p) in GF80",
      information:
        "five axis-unit pixels combine 800 bits into 160; this recipe is not an injective embedding",
      fixedDuringEvolution: true,
      arbitraryIndependentUnitStorage: hasImportedSources,
      indexSemantics: hasImportedSources
        ? "imported words directly index their finite stored Pixel160 units; generated axes fold arbitrary integer indices into finite values and can repeat values"
        : "folding arbitrary integer unit indices into finite values can collide; virtual words can repeat values",
    },
    observation: {
      profile: PIXEL_PROFILE,
      pixelABI: "BE32(L4)||BE32(L5)||BE32(L6)||BE32(L7)||BE32(L8)",
      map: "(q<<80)|p",
      information: "exact full mechanical state",
      middleLane: "L6 high16=q low16, L6 low16=p high16",
      display: "phase = 2*pi*L8/2^32; visualization only",
      fullState: "Pixel160 itself, fullStatesHex and row-major pixel160.bin",
      tiff: "five little-endian uint32 grayscale planes, L4..L8; JSON ImageDescription",
    },
    slice: {
      axes: config.axes,
      fixed: config.fixed,
      origin: config.origin,
      shape: [config.size, config.size],
      rowMajor: true,
      observedSliceCells: cells.length,
      evaluatedCells: dependencies.size,
      evaluationCountMeaning:
        "distinct cell addresses required, including partners outside the slice",
      pixelPayloadBytes: pixelBytes.length,
      partnerPolicy: "partner states are generated even outside this slice",
    },
    fullStatesHex: cells.map((c) => ({ q: hex(c.state.q), p: hex(c.state.p) })),
    checks: { invariantPreserved: cells.every((c) => c.initialInvariant === c.currentInvariant) },
    ...(hasImportedSources ? { wordWitnesses } : {}),
  };
  return { config, cells, pixels, pixelBytes, manifest };
}
export type SliceResult = ReturnType<typeof sampleSlice>;
