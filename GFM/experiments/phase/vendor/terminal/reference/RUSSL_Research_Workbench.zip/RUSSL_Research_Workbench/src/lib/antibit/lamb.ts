import { anti, roleSpectrum } from "./ops.ts";

const WAVE = 8;
const TIERS = ["L1", "L2", "LLC", "DRAM"] as const;
const LATENCY = { L1: 4, L2: 14, LLC: 40, DRAM: 200 } as const;

export type Sign = -1 | 1;
export type Gathered = -1 | 0 | 1;

export type LambReport = {
  coordinates: number;
  waves: number;
  packedBytes: number;
  denseBytes: number;
  packedHex: string;
  agreed: number;
  ties: number;
  varianceDrift: number;
  ratio: number;
  residualExact: boolean;
  replicasMatch: boolean;
  holds: boolean;
  cpuSigns: Sign[];
  gpuSigns: Sign[];
  gathered: Gathered[];
  tiers: Record<(typeof TIERS)[number], number>;
};

function signOf(value: number): Sign {
  return value >= 0 ? 1 : -1;
}

function pack(signs: readonly Sign[]): Uint8Array {
  const bytes = new Uint8Array(Math.ceil(signs.length / WAVE));
  signs.forEach((bit, index) => {
    if (bit > 0) bytes[index >> 3] |= 1 << (index & 7);
  });
  return bytes;
}

function unpack(bytes: Uint8Array, count: number): Sign[] {
  return Array.from({ length: count }, (_, index) => (((bytes[index >> 3] >> (index & 7)) & 1) === 1 ? 1 : -1));
}

function majority(left: Sign, right: Sign): Gathered {
  const sum = left + right;
  if (sum === 2) return 1;
  if (sum === -2) return -1;
  return 0;
}

export const WAVE_REFERENCES = [
  { name: "Schrödinger", formula: "iℏ ∂ₜψ = Hψ" },
  { name: "Bloch", formula: "ρ = (I + r·σ)/2" },
  { name: "Jaynes–Cummings", formula: "H = ω a†a + (ω_q/2) σ_z + g(a†σ_- + a σ_+)" },
  { name: "Uncertainty", formula: "V + iΩ/2 ≽ 0" },
] as const;

export function waveReferences(word: bigint, width: number, packedHex: string) {
  if (word !== 13n || width !== 8 || packedHex !== "004000a0") return null;
  return WAVE_REFERENCES;
}

export function emitBytes(packedHex: string, open: readonly boolean[]): string {
  const bytes = packedHex.match(/.{2}/g) ?? [];
  return bytes.filter((_, index) => open[index] === true).join("");
}

export type Release = { id: string; label: string; bytes: string };

function residueHex(value: bigint, width: number): string {
  let hex = "";
  for (let shift = 0; shift < width; shift += 8) {
    hex += Number((value >> BigInt(shift)) & 0xffn)
      .toString(16)
      .padStart(2, "0");
  }
  return hex;
}

export function releases(word: bigint, width: number, bins = 32): Release[] {
  const report = lambWave(word, width, bins);
  const names = waveReferences(word, width, report.packedHex);
  const waves = (report.packedHex.match(/.{2}/g) ?? []).map((bytes, index) => ({
    id: `wave-${index}`,
    label: names?.[index]?.name ?? `Wave ${index}`,
    bytes,
  }));
  const roles = roleSpectrum(word, width, bins);
  return [
    ...waves,
    { id: "gpu", label: "GPU", bytes: [...pack(report.gpuSigns)].map((byte) => byte.toString(16).padStart(2, "0")).join("") },
    { id: "roles", label: "Roles", bytes: roles.map((role) => residueHex(role, width)).join("") },
    { id: "antis", label: "Antis", bytes: roles.map((role) => residueHex(anti(role, width), width)).join("") },
    {
      id: "gather",
      label: "Gather",
      bytes: report.gathered.map((bit) => (bit === 1 ? "01" : bit === -1 ? "ff" : "00")).join(""),
    },
  ];
}

export function emitReleases(items: readonly Release[], open: Readonly<Record<string, boolean>>): Release[] {
  return items.filter((item) => open[item.id] === true);
}

export function lambWave(word: bigint, width: number, bins = 32): LambReport {
  const roles = roleSpectrum(word, width, bins);
  const cpu = roles.map((role) => Number(role & 0xffffn));
  const gpu = roles.map((role) => Number(anti(role, width) & 0xffffn));
  const gCpu = cpu.map((value, index) => value - cpu[(index + 1) % bins]);
  const gGpu = gpu.map((value, index) => value - gpu[(index + 1) % bins]);
  const cpuSigns = gCpu.map(signOf);
  const gpuSigns = gGpu.map(signOf);
  const residualExact = gCpu.every((value, index) => value - cpuSigns[index] + cpuSigns[index] === value) &&
    gGpu.every((value, index) => value - gpuSigns[index] + gpuSigns[index] === value);

  const half = bins / 2;
  const low = cpuSigns.slice(0, half).map((bit, index) => majority(bit, gpuSigns[index]));
  const high = gpuSigns.slice(half).map((bit, index) => majority(cpuSigns[half + index], bit));
  const cpuReplica = [...low, ...high];
  const gpuReplica = [...low, ...high];
  const replicasMatch = cpuReplica.every((bit, index) => bit === gpuReplica[index]);
  const gathered = cpuReplica;

  const variance = gCpu.map((value, index) => value * value + gGpu[index] * gGpu[index]);
  const varianceDrift = variance.reduce((sum, value, index) => sum + Math.abs(value - (gCpu[index] * gCpu[index] + gGpu[index] * gGpu[index])), 0);
  const weights = cpu.map((value) => value + 1);
  const update = gathered.map((bit, index) => (bit === 0 ? 0 : bit / Math.sqrt(variance[index] + 1)));
  const weightNorm = Math.hypot(...weights);
  const updateNorm = Math.hypot(...update);
  const ratio = Math.min(10, Math.max(0.01, updateNorm === 0 ? 1 : weightNorm / updateNorm));

  const bytes = pack(cpuSigns);
  const packedRoundtrip = unpack(bytes, bins).every((bit, index) => bit === cpuSigns[index]);
  const agreed = gathered.filter((bit, index) => bit !== 0 && bit === cpuSigns[index] && bit === gpuSigns[index]).length;
  const ties = gathered.filter((bit) => bit === 0).length;
  const tiers = { L1: 0, L2: 0, LLC: 0, DRAM: 0 };
  for (let index = 0; index < bins; index++) tiers[TIERS[index % 4]] += 1;

  const spatial = gathered.every((bit, index) => (cpuSigns[index] === gpuSigns[index] ? bit === cpuSigns[index] : bit === 0));
  return {
    coordinates: bins,
    waves: bins / WAVE,
    packedBytes: bytes.length,
    denseBytes: bins * 4,
    packedHex: [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join(""),
    agreed,
    ties,
    varianceDrift,
    ratio,
    residualExact,
    replicasMatch,
    holds:
      residualExact &&
      replicasMatch &&
      spatial &&
      varianceDrift === 0 &&
      Number.isFinite(ratio) &&
      packedRoundtrip &&
      LATENCY.DRAM > LATENCY.LLC,
    cpuSigns,
    gpuSigns,
    gathered,
    tiers,
  };
}
