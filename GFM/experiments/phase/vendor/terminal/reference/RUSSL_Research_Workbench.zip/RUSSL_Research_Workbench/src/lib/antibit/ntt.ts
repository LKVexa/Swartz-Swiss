const P = 97n;
const ORDER = 32;
const ROOT = 19n;
const INV_N = 94n;

function modPow(base: bigint, exponent: bigint): bigint {
  let result = 1n;
  let factor = base % P;
  let power = exponent;
  while (power) {
    if (power & 1n) result = (result * factor) % P;
    factor = (factor * factor) % P;
    power >>= 1n;
  }
  return result;
}

export function ntt(input: readonly number[], inverse = false): number[] {
  const n = input.length;
  if (n !== ORDER) throw new Error("ntt length must be 32");
  const out = input.map((value) => {
    const reduced = BigInt(value) % P;
    return reduced < 0n ? reduced + P : reduced;
  });
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      const tmp = out[i];
      out[i] = out[j];
      out[j] = tmp;
    }
  }
  const root = inverse ? modPow(ROOT, BigInt(ORDER - 1)) : ROOT;
  for (let len = 2; len <= n; len <<= 1) {
    const wlen = modPow(root, BigInt(ORDER / len));
    for (let i = 0; i < n; i += len) {
      let w = 1n;
      for (let j = 0; j < len / 2; j++) {
        const u = out[i + j];
        const v = (out[i + j + len / 2] * w) % P;
        out[i + j] = (u + v) % P;
        out[i + j + len / 2] = (u - v + P) % P;
        w = (w * wlen) % P;
      }
    }
  }
  if (inverse) {
    for (let i = 0; i < n; i++) out[i] = (out[i] * INV_N) % P;
  }
  return out.map(Number);
}

export type ExactTransform = {
  prime: string;
  length: number;
  root: string;
  roundtrip: boolean;
  unbound: boolean;
  holds: boolean;
};

export function exactTransform(exponents: readonly bigint[]): ExactTransform {
  const used = Array.from({ length: ORDER }, (_, index) => exponents[index] ?? 0n);
  const signal = used.map((value, index) => Number(((value + BigInt(index)) % P + P) % P));
  const spectrum = ntt(signal, false);
  const roundtrip = ntt(spectrum, true).every((value, index) => value === signal[index]);
  const turned = spectrum.map((bin, index) => Number((BigInt(bin) * modPow(ROOT, used[index] % BigInt(ORDER))) % P));
  const cleared = turned.map(
    (bin, index) =>
      Number((BigInt(bin) * modPow(ROOT, (BigInt(ORDER) - (used[index] % BigInt(ORDER))) % BigInt(ORDER))) % P),
  );
  const unbound = ntt(cleared, true).every((value, index) => value === signal[index]);
  return {
    prime: P.toString(),
    length: ORDER,
    root: ROOT.toString(),
    roundtrip,
    unbound,
    holds: roundtrip && unbound,
  };
}
