import assert from "node:assert/strict";
import test from "node:test";
import {
  FIELD_INFO,
  fieldMask,
  gfAdd,
  gfMul,
  gfPow,
  irreducibilityWitness80,
  irreducibilityWitness100,
  validateElement,
} from "./field.ts";
import {
  MAX_TICK,
  advanceCell,
  advancePair,
  cellInvariant,
  inverseCell,
  inversePair,
  pairInvariant,
  stepCell,
  stepPair,
} from "./dynamics.ts";
import type { FieldId } from "./field.ts";
import type { PairState, PhaseState } from "./dynamics.ts";

const cells = Array.from({ length: 64 }, (_, label): PhaseState => ({
  q: BigInt(label >> 3),
  p: BigInt(label & 7),
}));
const pairs = Array.from({ length: 4096 }, (_, label): PairState => [
  { q: BigInt((label >> 9) & 7), p: BigInt((label >> 3) & 7) },
  { q: BigInt((label >> 6) & 7), p: BigInt(label & 7) },
]);

function cellBracket(left: PhaseState, right: PhaseState, field: FieldId) {
  return gfMul(left.q, right.p, field) ^ gfMul(left.p, right.q, field);
}

function pairBracket(left: PairState, right: PairState, field: FieldId) {
  return cellBracket(left[0], right[0], field) ^ cellBracket(left[1], right[1], field);
}

function independentPolynomialMultiply(left: bigint, right: bigint, field: FieldId) {
  let product = 0n;
  for (let bit = 0; bit < FIELD_INFO[field].bits; bit++) {
    if ((right >> BigInt(bit)) & 1n) product ^= left << BigInt(bit);
  }
  const modulus = FIELD_INFO[field].polynomial;
  for (let bit = 2 * FIELD_INFO[field].bits - 2; bit >= FIELD_INFO[field].bits; bit--) {
    if ((product >> BigInt(bit)) & 1n) product ^= modulus << BigInt(bit - FIELD_INFO[field].bits);
  }
  return product;
}

test("finite fields use irreducible polynomials and agree with independent polynomial division", () => {
  const witness = irreducibilityWitness100();
  assert.equal(witness.irreducible, true);
  assert.deepEqual(witness.gcdChecks, [
    { exponent: 20, gcdHex: "1" },
    { exponent: 50, gcdHex: "1" },
  ]);
  assert.equal(witness.finalFrobeniusHolds, true);
  for (let a = 0n; a < 8n; a++)
    for (let b = 0n; b < 8n; b++) {
      assert.equal(gfMul(a, b, "gf8"), independentPolynomialMultiply(a, b, "gf8"));
      if (a !== 0n) assert.equal(gfMul(a, gfPow(a, 6n, "gf8"), "gf8"), 1n);
      for (let c = 0n; c < 8n; c++) {
        assert.equal(gfMul(a, b ^ c, "gf8"), gfMul(a, b, "gf8") ^ gfMul(a, c, "gf8"));
      }
    }
  let seed = 0x123456789abcdef123456789an;
  for (let sample = 0; sample < 32; sample++) {
    seed = (seed * 0x9e3779b97f4a7c15n + 0x1d1b54a32d192ed03n) & fieldMask("gf100");
    const a = seed;
    seed = (seed * 0x9e3779b97f4a7c15n + 0x1d1b54a32d192ed03n) & fieldMask("gf100");
    const b = seed;
    assert.equal(gfMul(a, b, "gf100"), independentPolynomialMultiply(a, b, "gf100"));
    assert.equal(gfMul(a, gfPow(a, FIELD_INFO.gf100.cardinality - 2n, "gf100"), "gf100"), 1n);
  }
});

test("every GF8 cell preserves its invariant, inverse and symplectic pairing", () => {
  const next = cells.map((state) => stepCell(state, "gf8"));
  for (let index = 0; index < cells.length; index++) {
    assert.deepEqual(inverseCell(next[index], "gf8"), cells[index]);
    assert.deepEqual(stepCell(inverseCell(cells[index], "gf8"), "gf8"), cells[index]);
    assert.equal(cellInvariant(next[index], "gf8"), cellInvariant(cells[index], "gf8"));
    assert.deepEqual(advanceCell(cells[index], 9n, "gf8"), cells[index]);
    for (let other = 0; other < cells.length; other++) {
      assert.equal(
        cellBracket(next[index], next[other], "gf8"),
        cellBracket(cells[index], cells[other], "gf8"),
      );
    }
  }
});

test("all4096 GF8 coupled states preserve global H, inverse and pairing with a spanning basis", () => {
  const basis: PairState[] = [
    [
      { q: 1n, p: 0n },
      { q: 0n, p: 0n },
    ],
    [
      { q: 0n, p: 0n },
      { q: 1n, p: 0n },
    ],
    [
      { q: 0n, p: 1n },
      { q: 0n, p: 0n },
    ],
    [
      { q: 0n, p: 0n },
      { q: 0n, p: 1n },
    ],
  ];
  const nextBasis = basis.map((state) => stepPair(state, "gf8"));
  for (const pair of pairs) {
    const next = stepPair(pair, "gf8");
    assert.deepEqual(inversePair(next, "gf8"), pair);
    assert.deepEqual(stepPair(inversePair(pair, "gf8"), "gf8"), pair);
    assert.equal(pairInvariant(next, "gf8"), pairInvariant(pair, "gf8"));
    for (let index = 0; index < basis.length; index++) {
      assert.equal(
        pairBracket(next, nextBasis[index], "gf8"),
        pairBracket(pair, basis[index], "gf8"),
      );
    }
  }
  const start: PairState = [
    { q: 1n, p: 0n },
    { q: 0n, p: 0n },
  ];
  const evolved = advancePair(start, 2n, "gf8");
  assert.equal(pairInvariant(evolved, "gf8"), pairInvariant(start, "gf8"));
  assert.notEqual(cellInvariant(evolved[0], "gf8"), cellInvariant(start[0], "gf8"));
});

test("fast GF8 advancement matches repeated steps for configurable coefficients and leaves inputs intact", () => {
  for (const [kappa, coupling] of [
    [0n, 0n],
    [0n, 3n],
    [2n, 1n],
    [5n, 7n],
  ]) {
    for (const initial of cells.filter((_, index) => index % 7 === 0)) {
      const original = { ...initial };
      let current = { ...initial };
      for (let tick = 0n; tick <= 40n; tick++) {
        assert.deepEqual(advanceCell(initial, tick, "gf8", kappa), current);
        assert.equal(cellInvariant(current, "gf8", kappa), cellInvariant(initial, "gf8", kappa));
        current = stepCell(current, "gf8", kappa);
      }
      assert.deepEqual(initial, original);
    }
    for (const initial of pairs.filter((_, index) => index % 601 === 0)) {
      const original: PairState = [{ ...initial[0] }, { ...initial[1] }];
      let current: PairState = [{ ...initial[0] }, { ...initial[1] }];
      for (let tick = 0n; tick <= 40n; tick++) {
        assert.deepEqual(advancePair(initial, tick, "gf8", kappa, coupling), current);
        assert.equal(
          pairInvariant(current, "gf8", kappa, coupling),
          pairInvariant(initial, "gf8", kappa, coupling),
        );
        current = stepPair(current, "gf8", kappa, coupling);
      }
      assert.deepEqual(initial, original);
    }
  }
});

test("GF100 boundary-valued states preserve mechanics and fast advancement composes", () => {
  const mask = fieldMask("gf100");
  const initial: PairState = [
    { q: mask, p: 1n << 99n },
    { q: 0x123456789abcdef0123456789n, p: mask ^ 31n },
  ];
  const invariant = pairInvariant(initial, "gf100");
  let current: PairState = initial;
  for (let tick = 0n; tick <= 32n; tick++) {
    assert.deepEqual(advancePair(initial, tick, "gf100"), current);
    assert.equal(pairInvariant(current, "gf100"), invariant);
    assert.deepEqual(inversePair(stepPair(current, "gf100"), "gf100"), current);
    current = stepPair(current, "gf100");
  }
  const firstTick = 1048576n,
    secondTick = 233n;
  assert.deepEqual(
    advancePair(advancePair(initial, firstTick, "gf100"), secondTick, "gf100"),
    advancePair(initial, firstTick + secondTick, "gf100"),
  );
  assert.equal(pairInvariant(advancePair(initial, MAX_TICK, "gf100"), "gf100"), invariant);
  const state = initial[0];
  let cell = state;
  for (let tick = 0n; tick <= 32n; tick++) {
    assert.deepEqual(advanceCell(state, tick, "gf100"), cell);
    assert.equal(cellInvariant(cell, "gf100"), cellInvariant(state, "gf100"));
    cell = stepCell(cell, "gf100");
  }
  assert.deepEqual(
    advanceCell(advanceCell(state, firstTick, "gf100"), secondTick, "gf100"),
    advanceCell(state, firstTick + secondTick, "gf100"),
  );
  assert.equal(
    cellInvariant(advanceCell(state, MAX_TICK, "gf100"), "gf100"),
    cellInvariant(state, "gf100"),
  );
});

test("GF80 irreducibility, high-bit multiplication and inverses use all80 bits", () => {
  const witness = irreducibilityWitness80();
  assert.equal(witness.degree, 80);
  assert.equal(witness.polynomialHex, "100000000000000000215");
  assert.deepEqual(witness.gcdChecks, [
    { exponent: 16, gcdHex: "1" },
    { exponent: 40, gcdHex: "1" },
  ]);
  assert.equal(witness.finalFrobeniusHolds, true);
  assert.equal(witness.irreducible, true);
  const mask = fieldMask("gf80");
  assert.equal(mask, (1n << 80n) - 1n);
  const samples = [1n, 2n, 1n << 79n, mask, mask ^ (1n << 79n), 0x123456789abcdef01234n];
  let seed = 0x123456789abcdef01234n;
  for (let sample = 0; sample < 24; sample++) {
    seed = (seed * 0x9e3779b97f4a7c15n + 0xd1b54a32d192ed03n) & mask;
    samples.push(seed);
  }
  for (const a of samples) {
    assert.equal(validateElement(a, "gf80"), a);
    assert.equal(gfMul(a, gfPow(a, mask - 1n, "gf80"), "gf80"), 1n);
    for (const b of samples.slice(0, 6)) {
      assert.equal(gfMul(a, b, "gf80"), independentPolynomialMultiply(a, b, "gf80"));
    }
  }
  assert.equal(gfMul(1n << 79n, 2n, "gf80"), 0x215n);
  assert.throws(() => validateElement(1n << 80n, "gf80"), RangeError);
  assert.throws(() => gfMul(mask + 1n, 1n, "gf80"), RangeError);
});

test("GF80 q,p cells and coupled pairs preserve exact160-bit mechanics and fast advancement", () => {
  const mask = fieldMask("gf80");
  const initial: PairState = [
    { q: mask, p: 1n << 79n },
    { q: 0x123456789abcdef01234n, p: mask ^ 31n },
  ];
  for (const [kappa, coupling] of [
    [2n, 1n],
    [(1n << 79n) ^ 2n, (1n << 65n) ^ 3n],
  ]) {
    const globalInvariant = pairInvariant(initial, "gf80", kappa, coupling);
    const localInvariant = cellInvariant(initial[0], "gf80", kappa);
    let current: PairState = initial;
    let cell = initial[0];
    for (let tick = 0n; tick <= 24n; tick++) {
      assert.deepEqual(advancePair(initial, tick, "gf80", kappa, coupling), current);
      assert.deepEqual(advanceCell(initial[0], tick, "gf80", kappa), cell);
      assert.equal(pairInvariant(current, "gf80", kappa, coupling), globalInvariant);
      assert.equal(cellInvariant(cell, "gf80", kappa), localInvariant);
      assert.deepEqual(
        inversePair(stepPair(current, "gf80", kappa, coupling), "gf80", kappa, coupling),
        current,
      );
      assert.deepEqual(inverseCell(stepCell(cell, "gf80", kappa), "gf80", kappa), cell);
      current = stepPair(current, "gf80", kappa, coupling);
      cell = stepCell(cell, "gf80", kappa);
    }
    const firstTick = 1048576n,
      secondTick = 233n;
    assert.deepEqual(
      advancePair(
        advancePair(initial, firstTick, "gf80", kappa, coupling),
        secondTick,
        "gf80",
        kappa,
        coupling,
      ),
      advancePair(initial, firstTick + secondTick, "gf80", kappa, coupling),
    );
    assert.deepEqual(
      advanceCell(advanceCell(initial[0], firstTick, "gf80", kappa), secondTick, "gf80", kappa),
      advanceCell(initial[0], firstTick + secondTick, "gf80", kappa),
    );
    assert.equal(
      pairInvariant(
        advancePair(initial, MAX_TICK, "gf80", kappa, coupling),
        "gf80",
        kappa,
        coupling,
      ),
      globalInvariant,
    );
    assert.equal(
      cellInvariant(advanceCell(initial[0], MAX_TICK, "gf80", kappa), "gf80", kappa),
      localInvariant,
    );
  }
});

test("zero coupling agrees with independent cells, and huge GF8 ticks use exact recurrence", () => {
  for (const field of ["gf8", "gf80", "gf100"] as const) {
    const pair: PairState = [
      { q: 3n, p: 5n },
      { q: 7n, p: 1n },
    ];
    for (const tick of [0n, 1n, 17n, MAX_TICK]) {
      assert.deepEqual(advancePair(pair, tick, field, 2n, 0n), [
        advanceCell(pair[0], tick, field),
        advanceCell(pair[1], tick, field),
      ]);
    }
  }
  const pair: PairState = [
    { q: 1n, p: 0n },
    { q: 0n, p: 0n },
  ];
  assert.deepEqual(advancePair(pair, MAX_TICK, "gf8"), advancePair(pair, MAX_TICK % 14n, "gf8"));
  assert.deepEqual(
    advanceCell(pair[0], MAX_TICK, "gf8"),
    advanceCell(pair[0], MAX_TICK % 9n, "gf8"),
  );
});

test("invalid elements, coefficients and ticks are rejected instead of masked or rounded", () => {
  const state = { q: 1n, p: 2n };
  const pair: PairState = [state, state];
  assert.throws(() => validateElement(8n, "gf8"), RangeError);
  assert.throws(() => gfMul(1n << 100n, 1n, "gf100"), RangeError);
  assert.throws(() => gfPow(1n, -1n, "gf8"), RangeError);
  assert.throws(() => gfAdd(-1n, 0n), RangeError);
  assert.throws(() => stepCell({ q: -1n, p: 0n }, "gf8"), RangeError);
  assert.throws(() => stepCell(state, "gf8", 8n), RangeError);
  assert.throws(() => stepPair(pair, "gf8", 2n, 8n), RangeError);
  assert.throws(() => advanceCell(state, -1n, "gf8"), RangeError);
  assert.throws(() => advancePair(pair, MAX_TICK + 1n, "gf8"), RangeError);
  assert.throws(() => advanceCell(state, 1 as unknown as bigint, "gf8"), TypeError);
  assert.throws(
    () => validateElement(Number.MAX_SAFE_INTEGER as unknown as bigint, "gf100"),
    TypeError,
  );
  assert.throws(() => fieldMask("gf16" as FieldId), RangeError);
  assert.throws(() => stepPair([state] as unknown as PairState, "gf8"), TypeError);
});

test("sparse pairs cannot bypass state validation, including zero-tick advancement", () => {
  const empty = new Array<PhaseState>(2);
  const firstMissing = new Array<PhaseState>(2);
  firstMissing[1] = { q: 1n, p: 2n };
  const secondMissing = new Array<PhaseState>(2);
  secondMissing[0] = { q: 1n, p: 2n };
  for (const sparse of [empty, firstMissing, secondMissing]) {
    const pair = sparse as PairState;
    assert.throws(() => advancePair(pair, 0n, "gf80"), TypeError);
    assert.throws(() => advancePair(pair, 1n, "gf80"), TypeError);
    assert.throws(() => stepPair(pair, "gf80"), TypeError);
    assert.throws(() => inversePair(pair, "gf80"), TypeError);
    assert.throws(() => pairInvariant(pair, "gf80"), TypeError);
  }
});
