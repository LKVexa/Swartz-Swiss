RUSSL RESEARCH WORKBENCH

Open standalone.html in a current desktop browser. It includes the complete
word experiment, styles and code, and needs no server or network connection.
The full original application, with the experiment above the Anti-word deck,
is also included as editable source and a production build.

Research integration
--------------------
Word dynamics keeps the five raw axis words, reversible GF80 cells and TIFF
exports. Research terminal adds the supplied ten laboratories/registries and
an eleventh RUSSL word dynamics view. Open that view to refresh the active slice
or record it in the research ledger. Replay & compare reconstructs a saved
slice from its own bounded source-unit witnesses, even after the workbench
changes. The selected cell includes an exact inverse witness.

The terminal's existing fixed 64-bit-site penteract is a separate synthetic
representation. Its small-field and circuit models retain their declared
domains. Source text is evidence, not executable instructions. All 366 embedded
source downloads were checked against their original bytes and hashes.

The embedded terminal is isolated from parent DOM/storage. Its session stays
in memory; export JSON records to preserve it. Import verifies supplied record
hashes and keeps requests inert until explicit replay. Word files remain in
the parent workbench, and complete originals remain in TIFF replay ZIPs.
Bounded research records verify their unit witnesses and evolved states;
original source-file hashes remain identifiers unless full files are checked.

The patched vendor engine is 1.1.0-russl. Original terminal source and notices
are preserved in vendor/gfm-research-terminal. Root integration notice and
GPL companions identify the derivative and retained third-party scope.
See GFM_Research_Integration_Audit.txt and validation/research-* evidence.
Use npm run test:research for the vendor numerical, circuit, integration,
boundary and ledger/adapter suites. Both workbench build commands rebuild the
embedded terminal from its editable vendor sources automatically.

Five words and actual data
--------------------------
Length, width, depth, height and ceiling are five independent axes. Each word
unit is one RUSSL Pixel160: 160 bits, or 20 bytes. The position count is the
product of the five unit counts. Equal counts form a five-dimensional cube;
unequal counts form a five-dimensional rectangular box. There is no fixed
2^100 address domain. A word's integer value is its contents, not an axis length.

Use Import appliance words, choose the file format, and select one actual file
for each axis. Its unit count sets that axis length. Import or replacement
restarts evolution at step zero and fits the slice to the new dimensions.
Imported counts cannot be edited independently of their data. Use generated
[axis] word returns that axis to the original recipe. Generated counts use
Apply words and restart. Axes may mix imported and generated words; the
interface identifies each source.

File reads and simulation stay on this device. Imported words are held in
memory for the current session; reloading clears them from the workbench.
Replay exports retain complete original files and the configuration.

Input byte formats
------------------
Ultra-wide appliance word (appliance-le) accepts one unsigned, fixed-width
little-endian operand produced by Word.to_bytes(). Unit zero contains its
least-significant 160 bits. Every native chunk is converted to canonical
big-endian Pixel160. A short final chunk is extended with high zero bits;
the original bytes and declared width remain available independently.

A standard 1,048,576-bit word has 131,072 source bytes and becomes 6,554 units.
The final 96 source bits occupy the low 96 bits of its last unit, with 64 added
high zero bits. No source bits are discarded. Native import is bounded at one
131,072-byte operand; separate .brw chains into individual operands first.
Packed program bytes, register operands, source programs and receipt JSON are
different things. Import reads bytes as data and executes no program.
Receipt hashes and summaries alone cannot reconstruct word contents.

RUSSL Pixel160 stream (russl-be) accepts consecutive canonical units in file
order: BE32(L4)||BE32(L5)||BE32(L6)||BE32(L7)||BE32(L8). The file must be a positive
multiple of 20 bytes and at most 8 MiB. No padding is added. This is the
workbench's named Pixel160 profile, not an existing appliance or language ABI.

The browser assumes sourceBits=sourceByteLength*8 for native file imports.
importRawWord also accepts a declared native sourceBits width from 8 through
1,048,576, requiring ceil(sourceBits/8) to match the file length and unused high
storage bits to be zero. Narrower non-byte-aligned widths therefore require
the API or retained replay metadata. Original and canonical SHA-256 hashes
distinguish source bytes from their Pixel160 conversion. Buffers and returned
units use private copies.

Each selected cell shows its five source units. Their declared finite-field
combiner determines its initial mechanical state. Five source units contain
800 bits; their 160-bit combination is not an injective encoding. Imported
units remain available exactly from their source files. Generated axes use the
preserved seed recipe, whose folded indices can produce repeated values.
Coordinates remain external to the Pixel160 payload.

Reversible mechanics
--------------------
Each evolving cell has q and p in GF(2^80). The binary polynomial basis uses
x^80+x^9+x^4+x^2+1; exact irreducibility checks pass. Integer constants mean
binary polynomial bit patterns. Addition is XOR; multiplication is polynomial
multiplication reduced by the field polynomial.

For independent cells K=[kappa]. For a coupled pair,
K=[[kappa,lambda],[lambda,kappa]]. The update is
  P'=P+KQ; Q'=Q+P'.
Its inverse is Q=Q'+P'; P=P'+KQ. The conserved field value is
  H=Q^T K Q+Q^T K P+P^T P.
This is a field-valued invariant; no physical units or positive real energy
are assigned. The workbench is a computational model for theory experiments.

Coupling joins disjoint adjacent pairs along the selected word axis:
(0,1), (2,3), etc. An odd-length word's final cell evolves independently.
Partners outside the selected slice are evaluated. Source words stay fixed
during cell evolution. Forward, Back, Advance 10, Return to start and Go to
step replay the same imported data or generated recipe under a fixed law.
New word/model setups restart at zero. Steps range from 0 through 4,294,967,295;
exact matrix powers permit direct jumps.

Pixel160, TIFF and replay
------------------------
Pixel160=(q<<80)|p retains every mechanical-state bit in five uint32 lanes,
L4 through L8, in big-endian canonical order. L6's high 16 bits finish q;
its low 16 bits begin p. The display uses L8 as a wrapped color phase only.

Choose two displayed axes and three fixed coordinates. Slices range from 1x1
through 32x32. Only the bounded slice and necessary partner states are evaluated;
the whole five-dimensional domain is not allocated as a dense array.

Export TIFF slice creates five unsigned 32-bit grayscale pages, L4..L8, with
configuration, coordinates, field, dynamics, full states, source identities
and selected inverse witness embedded as JSON ImageDescription. Imported
wordWitnesses preserve every exact source unit needed by the slice and its
coupled neighbors, including partners outside the plane. They are bounded
witnesses; the TIFF does not contain every byte of all source files. The
export is a 2D slice with five data planes, not a native 5D TIFF raster.

Export replay bundle includes the TIFF, manifest.json, pixel160.bin and
README.txt. Each imported original is also retained byte-for-byte at
words/0-length.bin, words/1-width.bin, words/2-depth.bin, words/3-height.bin
and words/4-ceiling.bin. Only imported axes add files; an all-imported bundle
retains all five originals. Fixed axis paths preserve distinct files even
when original filenames match. The manifest retains names, formats, widths,
padding and both hashes. pixel160.bin stores full evolved states, row-major,
20 bytes per cell. Virtual-only manifests retain version 2; imported-source
manifests use version 3.

After reading manifest.json and ZIP members into a map of names to Uint8Array
bytes, call src/lib/gfm/replay.ts and src/lib/gfm/penteract.ts:
  const sources = await restoreWordSources(manifest, name => files.get(name));
  const slice = sampleSlice(manifest.config, sources);
The restore API reimports and verifies every original's width and hashes.
Missing or changed originals are rejected and never replaced with recipes.
The browser imports raw axis files; replay-ZIP loading uses the restore API,
not a browser replay-loader control.

Export actual appliance registers
--------------------------------
scripts/export-appliance-words.py uses the user's existing UltraWide Appliance
checkout. It reads a .brimg image or LCTL-BRIM/1 .lctlb source, executes it in
the appliance's Python BRIM VM, and exports five complete final registers
through the actual Word.to_bytes(). Every operand hash is checked against
the appliance register hash before writing. The checkout is not modified.

Replace these paths with your checkout, program and a new output directory.
Run from the workbench folder with Python 3.12 or newer:
  python scripts/export-appliance-words.py --appliance-root "D:\path\UltraWide-Appliance-main" --program "D:\path\program.lctlb" --output "D:\path\five-axis-words" --registers 0,1,2,3,4

Registers are selected in length,width,depth,height,ceiling order, defaulting
to R0,R1,R2,R3,R4. Outputs are length.bin, width.bin, depth.bin, height.bin and
ceiling.bin, plus appliance-export.json with program, trace, input and register
hashes. Existing files are preserved; choose a new output directory.
Optional --initial-register "5:D:\path\input.bin" supplies a complete native
operand to R5; repeat for other distinct initial registers. This helper uses
the pure BRIM execution profile, not SHS programs or .brw chain execution.
Import its resulting files with the appliance-le format.

Source and reproducibility
--------------------------
The original attached ZIP and appliance sources remain unchanged. This is a
separate derivative. Imported App Builder instructions remain in
attachments/Imported_App_Builder_AGENTS.md as source history; local AGENTS.md
describes this derivative. Original platform scripts and the Anti-word deck
remain available.

With Node.js 24 and npm available:
  npm ci
  npm run test:gfm
  npm run test:antibit
  npm run typecheck
  npm run build:offline
  npm run build:workbench
  npm run start:workbench
The full application's local address is http://127.0.0.1:8081/.
The included built server also runs with node scripts/serve-built.mjs without
installing dependencies. The workbench build does not run the original database
migration step. Both browser views share the same component and kernels.

Examples and validation
-----------------------
examples/appliance-words/ contains five demonstration operands produced from
actual final registers of a test program in the appliance's Python BRIM VM:
length.bin, width.bin, depth.bin, height.bin and ceiling.bin, plus
appliance-export.json. These are demo data, not an export of the user's private
appliance state. Each native file has 131,072 bytes and 6,554 units.

examples/raw-step7.tiff and examples/raw-step7-replay.zip show their connected
cell dynamics at step 7. The raw replay retains all five source files.
Original generated examples/step7.tiff and examples/step7-replay.zip are
preserved for comparison.

To reproduce the independent raw export check with Python and Pillow:
  python scripts/verify-gfm-export.py --zip examples/raw-step7-replay.zip --tiff examples/raw-step7.tiff --report validation/raw-export-check.json

The four-record research demonstration adds GF9 CHSH, a Bell circuit, the
synthetic packed penteract and the actual step7 word slice. Reproduce its
independent envelope, model and TIFF comparisons with Node.js and Python/Pillow:
  node scripts/verify-research-session.cjs examples/research-step7-session.json validation/research-session-independent.json
  python scripts/verify-research-export.py --session examples/research-step7-session.json --zip examples/research-step7-replay.zip --tiff examples/research-step7.tiff --node-report validation/research-session-independent.json --report validation/research-export-independent-check.json --ledger-report validation/research-ledger-independent-check.json --original-words examples/appliance-words

These two research checkers validate this declared demonstration, including its
selected cell at [19,11,2,3,6553]. Replace input/output paths for another export
of the same experiment. All four record envelope digests are independently
recomputed; GF9, Bell sampling and synthetic packed bytes use separate reference
calculations. The Python comparison uses the independent GF80 polynomial reader.
Full original source hashes are checked from the replay ZIP; the bounded ledger
correctly leaves those original hashes unverified. --original-words additionally
compares replay members with separately retained source files and may be omitted.
These byte checks do not validate native download transport or physical theory.

validation/ retains test output, browser results, screenshots and independent
export evidence. Verification covers source/canonical hashes, byte order,
padding, imported dimensions, reversible states, odd boundaries and replay.
Latest raw-import evidence is recorded in raw-summary.json, tests-raw.txt,
build-raw.txt, browser-raw-production-check.json and browser-raw-offline-check.json.
Earlier generated-word reports remain preserved independently.
The independent Python reader checks ZIP CRCs, exact original words, all five
TIFF planes, source-unit witnesses, full q80/p80 values and mixed-radix addresses.
Its separate polynomial implementation reproduces evolved cells and required
partners from source units, checking the invariant at each step.

Production and standalone views are exercised in real headless Chromium on
desktop and mobile viewports, including raw imports and state-preserving failure
cases. The sandbox blocks loopback requests, so production requests are fulfilled
from the built SSR handler and asset files; standalone loads by file URL. This
environment cancels native download transport, so actual export Blob bytes are
captured through the page API and independently verified. Normal browser
file-save behavior remains to be confirmed outside this sandbox. The retained
reports specify the completed checks and their scope.

The GF100/Phase200 helpers are historical comparison utilities. The active
five-word experiment uses GF80 and exact full-state Pixel160 throughout.
