import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import test from "node:test";
import { EMPTY_WORD_SOURCES, importRawWord } from "./raw-words.ts";
import type { RawWordFormat } from "./raw-words.ts";
import { decodeStatePixel160, encodePixel160, pixelHex } from "./pixel.ts";

const fromHex = (hex: string): Uint8Array => new Uint8Array(Buffer.from(hex, "hex"));
const hash = (bytes: Uint8Array): string => createHash("sha256").update(bytes).digest("hex");
const nativeOptions = { name: "length.bin", format: "appliance-le" as const };
const russlOptions = { name: "width.pixel160", format: "russl-be" as const };

test("canonical Pixel160 words retain exact lanes, order, full phase, and hashes", async () => {
  const raw = fromHex(
    "80000000ffffffff123456788765432100000001" + "0000000100000002000000030000000400000005",
  );
  const word = await importRawWord(raw, russlOptions);
  assert.equal(word.kind, "imported");
  assert.equal(word.unitCount, 2n);
  assert.equal(word.sourceByteLength, 40);
  assert.equal(word.sourceBits, 320);
  assert.equal(word.paddingBits, 0);
  assert.deepEqual(word.unit(0n), [0x80000000, 0xffffffff, 0x12345678, 0x87654321, 1]);
  assert.deepEqual(word.unit(1n), [1, 2, 3, 4, 5]);
  const phase = decodeStatePixel160(word.unit(0n));
  const independentlyDecoded = BigInt("0x80000000ffffffff123456788765432100000001");
  assert.equal(phase.q, independentlyDecoded >> 80n);
  assert.equal(phase.p, independentlyDecoded & ((1n << 80n) - 1n));
  assert.deepEqual(word.canonicalBytes(), raw);
  assert.deepEqual(word.bytes(), raw);
  assert.equal(word.sha256, hash(raw));
  assert.equal(word.canonicalSha256, hash(raw));
});

test("native appliance units reverse bytes inside each unit without reversing unit order", async () => {
  const raw = Uint8Array.from({ length: 40 }, (_, index) => index);
  const word = await importRawWord(raw, nativeOptions);
  assert.equal(pixelHex(word.unit(0n)), "131211100f0e0d0c0b0a09080706050403020100");
  assert.equal(pixelHex(word.unit(1n)), "27262524232221201f1e1d1c1b1a191817161514");
  const expected = new Uint8Array(
    [...raw.subarray(0, 20)].reverse().concat([...raw.subarray(20)].reverse()),
  );
  assert.deepEqual(word.canonicalBytes(), expected);
  assert.equal(word.canonicalSha256, hash(expected));
  assert.equal(word.sha256, hash(raw));
  assert.notEqual(word.sha256, word.canonicalSha256);
});

test("native short final unit is high-zero-extended and retains exact source bytes", async () => {
  const raw = Uint8Array.from({ length: 21 }, (_, index) => index + 1);
  const word = await importRawWord(raw, nativeOptions);
  assert.equal(word.unitCount, 2n);
  assert.equal(word.sourceBits, 168);
  assert.equal(word.paddingBits, 152);
  assert.equal(pixelHex(word.unit(1n)), "0000000000000000000000000000000000000015");
  assert.deepEqual(word.bytes(), raw);
  assert.equal(word.canonicalBytes().byteLength, 40);
  // Independent inverse removes the declared extension after byte reversal.
  const canonical = word.canonicalBytes();
  const restored = new Uint8Array(21);
  for (let index = 0; index < restored.length; index++) {
    restored[index] = canonical[20 * Math.floor(index / 20) + 19 - (index % 20)];
  }
  assert.deepEqual(restored, raw);
});

test("default appliance highest bit remains bit 95 of the 96-bit final unit", async () => {
  const raw = new Uint8Array(131_072);
  raw[raw.length - 1] = 0x80;
  const word = await importRawWord(raw, nativeOptions);
  assert.equal(word.unitCount, 6554n);
  assert.equal(word.sourceBits, 1_048_576);
  assert.equal(word.paddingBits, 64);
  assert.deepEqual(word.unit(0n), [0, 0, 0, 0, 0]);
  assert.equal(pixelHex(word.unit(6553n)), "0000000000000000800000000000000000000000");
  const last = decodeStatePixel160(word.unit(6553n));
  assert.equal(last.q, 1n << 15n);
  assert.equal(last.p, 0n);
  assert.equal(word.sha256, hash(raw));
});

test("native non-byte-aligned widths preserve declared width and validate high storage padding", async () => {
  const nine = await importRawWord(fromHex("ff01"), { ...nativeOptions, sourceBits: 9 });
  assert.equal(nine.sourceBits, 9);
  assert.equal(nine.paddingBits, 151);
  assert.equal(pixelHex(nine.unit(0n)), "00000000000000000000000000000000000001ff");
  const oneAfter160 = new Uint8Array(21);
  oneAfter160[20] = 1;
  const narrow = await importRawWord(oneAfter160, { ...nativeOptions, sourceBits: 161 });
  assert.equal(narrow.unitCount, 2n);
  assert.equal(narrow.paddingBits, 159);
  assert.equal(pixelHex(narrow.unit(1n)), "0000000000000000000000000000000000000001");
  oneAfter160[20] = 2;
  await assert.rejects(
    importRawWord(oneAfter160, { ...nativeOptions, sourceBits: 161 }),
    /Unused high/,
  );
  await assert.rejects(
    importRawWord(fromHex("ff81"), { ...nativeOptions, sourceBits: 9 }),
    /Unused high/,
  );
});

test("one-byte minimum native words and an aligned explicit canonical width are accepted", async () => {
  const word = await importRawWord(fromHex("ff"), nativeOptions);
  assert.equal(word.sourceBits, 8);
  assert.equal(word.paddingBits, 152);
  assert.equal(word.unitCount, 1n);
  assert.equal(word.unit(0n)[4], 255);
  const canonical = await importRawWord(new Uint8Array(20), { ...russlOptions, sourceBits: 160 });
  assert.equal(canonical.paddingBits, 0);
});

test("import captures subarray data before hashing and every returned buffer and tuple is independent", async () => {
  const backing = Uint8Array.from({ length: 24 }, (_, index) => index);
  const source = backing.subarray(2, 22);
  const original = source.slice();
  const pending = importRawWord(source, russlOptions);
  backing.fill(0xff);
  const word = await pending;
  assert.deepEqual(word.bytes(), original);
  word.bytes().fill(0);
  word.canonicalBytes().fill(0);
  const pixel = word.unit(0n);
  pixel.fill(0);
  assert.deepEqual(word.bytes(), original);
  assert.deepEqual(word.canonicalBytes(), original);
  assert.deepEqual(encodePixel160(word.unit(0n)), original);
  assert.equal(word.sha256, hash(original));
  assert(Object.isFrozen(word));
  assert.throws(() => Object.assign(word, { name: "changed" }), TypeError);
});

test("native BRWWORD header sample bytes produce independently recorded appliance vectors", async () => {
  // Public format-header bytes only, not a copied program or licensed image fixture.
  const raw = fromHex(
    "425257574f524400010000010000100000000000" + "01000000e0000000d60000005d01000010270000",
  );
  const word = await importRawWord(raw, { ...nativeOptions, name: "header-vector.bin" });
  assert.equal(pixelHex(word.unit(0n)), "0000000000100000010000010044524f57575242");
  assert.equal(pixelHex(word.unit(1n)), "000027100000015d000000d6000000e000000001");
});

test("unit indices require bounded exact bigint values", async () => {
  const word = await importRawWord(new Uint8Array(20), russlOptions);
  for (const index of [-1n, 1n, 1n << 200n, 0, "0", null, undefined]) {
    assert.throws(() => word.unit(index as bigint), /exact bigint/);
  }
});

test("unsupported buffers, sparse arrays, missing options, and unknown formats are rejected", async () => {
  for (const bytes of [
    null,
    undefined,
    new Array(20),
    new Uint16Array(20),
    new ArrayBuffer(20),
    {},
  ]) {
    await assert.rejects(importRawWord(bytes as Uint8Array, nativeOptions), /Uint8Array/);
  }
  for (const options of [null, undefined, [], true, "native"]) {
    await assert.rejects(
      importRawWord(new Uint8Array(20), options as unknown as typeof nativeOptions),
      /required/,
    );
  }
  for (const format of ["little", "big", "", null, true]) {
    await assert.rejects(
      importRawWord(new Uint8Array(20), { name: "word.bin", format: format as RawWordFormat }),
      /appliance-le or russl-be/,
    );
  }
});

test("word names reject blank, oversized, control, and path names while retaining user text", async () => {
  for (const name of [
    "",
    " ",
    ".",
    "..",
    "a/b",
    "a\\b",
    "a\0b",
    "a\nb",
    "a\x7fb",
    "x".repeat(256),
    null,
    1,
  ]) {
    await assert.rejects(
      importRawWord(new Uint8Array(20), { ...russlOptions, name: name as string }),
      /filename/,
    );
  }
  const name = "Ceiling actual word α.bin";
  const word = await importRawWord(new Uint8Array(20), { ...russlOptions, name });
  assert.equal(word.name, name);
});

test("native storage and width bounds reject chains and mismatched or invalid declarations", async () => {
  await assert.rejects(importRawWord(new Uint8Array(), nativeOptions), /at least one/);
  await assert.rejects(importRawWord(new Uint8Array(131_073), nativeOptions), /split word chains/);
  for (const sourceBits of [0, 7, 8.5, NaN, Infinity, -1, 1_048_577, true, "160", 152, 161]) {
    await assert.rejects(
      importRawWord(new Uint8Array(20), { ...nativeOptions, sourceBits: sourceBits as number }),
      /width|Width/,
    );
  }
});

test("canonical Pixel160 storage rejects partial units, excessive bytes, and altered declared width", async () => {
  for (const length of [0, 1, 19, 21]) {
    await assert.rejects(
      importRawWord(new Uint8Array(length), russlOptions),
      /at least one|complete 20-byte/,
    );
  }
  await assert.rejects(
    importRawWord(new Uint8Array(8 * 1024 * 1024 + 12), russlOptions),
    /at most 8 MiB/,
  );
  for (const sourceBits of [8, 159, 161, 320, false]) {
    await assert.rejects(
      importRawWord(new Uint8Array(20), { ...russlOptions, sourceBits: sourceBits as number }),
      /width|Width/,
    );
  }
});

test("empty five-axis sources are immutable and dense", () => {
  assert(Object.isFrozen(EMPTY_WORD_SOURCES));
  assert.equal(EMPTY_WORD_SOURCES.length, 5);
  assert.deepEqual(Array.from(EMPTY_WORD_SOURCES), [null, null, null, null, null]);
  assert.throws(() => Object.assign(EMPTY_WORD_SOURCES, { 0: "changed" }), TypeError);
});
