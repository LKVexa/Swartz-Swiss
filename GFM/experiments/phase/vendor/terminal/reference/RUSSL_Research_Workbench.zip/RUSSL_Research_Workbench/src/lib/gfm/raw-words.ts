import { decodePixel160 } from "./pixel.ts";
import type { Pixel160 } from "./pixel.ts";

export type RawWordFormat = "appliance-le" | "russl-be";

export type ImportedWord = Readonly<{
  kind: "imported";
  name: string;
  format: RawWordFormat;
  unitCount: bigint;
  sourceByteLength: number;
  sourceBits: number;
  paddingBits: number;
  sha256: string;
  canonicalSha256: string;
  unit(index: bigint): Pixel160;
  bytes(): Uint8Array;
  canonicalBytes(): Uint8Array;
}>;

export type WordSources = readonly [
  ImportedWord | null,
  ImportedWord | null,
  ImportedWord | null,
  ImportedWord | null,
  ImportedWord | null,
];

export const EMPTY_WORD_SOURCES: WordSources = Object.freeze([null, null, null, null, null]);

const PIXEL_BYTES = 20;
const APPLIANCE_MAX_BITS = 1_048_576;
const APPLIANCE_MAX_BYTES = APPLIANCE_MAX_BITS / 8;
const RUSSL_MAX_BYTES = 8 * 1024 * 1024;

function validateName(name: string): void {
  if (
    typeof name !== "string" ||
    name.length === 0 ||
    name.length > 255 ||
    name.trim().length === 0 ||
    name === "." ||
    name === ".." ||
    Array.from(name).some((character) => {
      const code = character.charCodeAt(0);
      return code < 32 || code === 127 || character === "/" || character === "\\";
    })
  ) {
    throw new TypeError("Word name must be a nonblank filename of at most 255 characters");
  }
}

async function sha256(bytes: Uint8Array<ArrayBuffer>): Promise<string> {
  if (!globalThis.crypto?.subtle) {
    throw new Error("Raw word import requires a browser with SHA-256 support");
  }
  const digest = new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", bytes));
  return Array.from(digest, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

/**
 * Import a snapshot of actual word bytes. Appliance unit zero contains the
 * least-significant 160 bits of its little-endian unsigned operand. A short
 * final unit is extended with high zero bits, with its source width retained.
 * RUSSL input is the existing BE32(L4)..BE32(L8) Pixel160 stream, in file order.
 * Files are data; this function never dispatches appliance programs.
 */
export async function importRawWord(
  bytes: Uint8Array,
  options: { name: string; format: RawWordFormat; sourceBits?: number },
): Promise<ImportedWord> {
  if (!(bytes instanceof Uint8Array)) {
    throw new TypeError("Raw word bytes must be a Uint8Array");
  }
  if (!options || typeof options !== "object" || Array.isArray(options)) {
    throw new TypeError("Word name and byte format are required");
  }
  const { name, format, sourceBits: declaredBits } = options;
  validateName(name);
  if (format !== "appliance-le" && format !== "russl-be") {
    throw new TypeError("Choose appliance-le or russl-be as the raw word format");
  }
  const byteLength = bytes.byteLength;
  if (byteLength === 0) throw new RangeError("A raw word must contain at least one byte");
  if (format === "appliance-le" && byteLength > APPLIANCE_MAX_BYTES) {
    throw new RangeError(
      "One appliance operand is at most 131,072 bytes; split word chains into separate operands",
    );
  }
  if (format === "russl-be" && byteLength > RUSSL_MAX_BYTES) {
    throw new RangeError("A RUSSL Pixel160 word must be at most 8 MiB");
  }
  if (format === "russl-be" && byteLength % PIXEL_BYTES !== 0) {
    throw new RangeError("A RUSSL Pixel160 word requires complete 20-byte units");
  }
  const sourceBits = declaredBits === undefined ? byteLength * 8 : declaredBits;
  if (typeof sourceBits !== "number" || !Number.isSafeInteger(sourceBits) || sourceBits < 8) {
    throw new RangeError("Source width must be an exact integer of at least 8 bits");
  }
  if (format === "appliance-le") {
    if (sourceBits > APPLIANCE_MAX_BITS || Math.ceil(sourceBits / 8) !== byteLength) {
      throw new RangeError(
        "Appliance width must be 8..1,048,576 bits and match its fixed storage size",
      );
    }
  } else if (sourceBits !== byteLength * 8) {
    throw new RangeError("RUSSL width must equal the complete Pixel160 storage width");
  }

  // Capture caller data before the first await, including subarray offsets.
  const original = new Uint8Array(byteLength);
  original.set(bytes);
  if (format === "appliance-le" && sourceBits % 8 !== 0) {
    const usedHighBits = sourceBits % 8;
    const highPaddingMask = 255 ^ ((1 << usedHighBits) - 1);
    if ((original[original.length - 1] & highPaddingMask) !== 0) {
      throw new RangeError("Unused high storage bits of an appliance word must be zero");
    }
  }
  const unitCountNumber = Math.ceil(sourceBits / 160);
  const canonical = new Uint8Array(unitCountNumber * PIXEL_BYTES);
  if (format === "russl-be") {
    canonical.set(original);
  } else {
    for (let unit = 0; unit < unitCountNumber; unit++) {
      const start = unit * PIXEL_BYTES;
      const available = Math.min(PIXEL_BYTES, byteLength - start);
      for (let offset = 0; offset < available; offset++) {
        canonical[start + PIXEL_BYTES - 1 - offset] = original[start + offset];
      }
    }
  }
  const [sourceDigest, canonicalDigest] = await Promise.all([sha256(original), sha256(canonical)]);
  const unitCount = BigInt(unitCountNumber);
  return Object.freeze({
    kind: "imported" as const,
    name,
    format,
    unitCount,
    sourceByteLength: byteLength,
    sourceBits,
    paddingBits: unitCountNumber * 160 - sourceBits,
    sha256: sourceDigest,
    canonicalSha256: canonicalDigest,
    unit(index: bigint): Pixel160 {
      if (typeof index !== "bigint" || index < 0n || index >= unitCount) {
        throw new RangeError("Word unit index must be an exact bigint within the imported word");
      }
      const start = Number(index) * PIXEL_BYTES;
      return decodePixel160(canonical.subarray(start, start + PIXEL_BYTES));
    },
    bytes(): Uint8Array {
      return original.slice();
    },
    canonicalBytes(): Uint8Array {
      return canonical.slice();
    },
  });
}
