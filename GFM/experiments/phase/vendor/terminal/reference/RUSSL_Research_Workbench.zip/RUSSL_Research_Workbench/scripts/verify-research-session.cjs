'use strict';
// Independent session verification: no application modules are imported.
const fs = require('node:fs');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const [input, output] = process.argv.slice(2);
assert(input && output, 'Usage: verify-research-session.cjs INPUT OUTPUT');
const bytes = fs.readFileSync(input), session = JSON.parse(bytes.toString('utf8'));
assert.equal(session.schema, 'GFM-SESSION/1'); assert(Array.isArray(session.records));
function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value !== null && typeof value === 'object') {
    const fields = Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + canonical(value[key]));
    return '{' + fields.join(',') + '}';
  }
  assert(value === null || ['string', 'number', 'boolean'].includes(typeof value));
  if (typeof value === 'number') assert(Number.isFinite(value));
  return JSON.stringify(value);
}
const digest = data => crypto.createHash('sha256').update(data).digest('hex');
const records = session.records.map(row => {
  assert.equal(row.schema, 'GFM-RUN/1');
  const text = canonical({schema: row.schema, engineVersion: row.engineVersion, request: row.request, result: row.result});
  const actual = digest(Buffer.from(text, 'utf8')); assert.equal(actual, row.digest);
  assert.match(row.engineVersion, /^1\.1\.0-russl\b/);
  return {id: row.id, type: row.request.type, sha256: actual, canonicalUTF8Bytes: Buffer.byteLength(text), status: 'PASS'};
});
const types = session.records.map(row => row.request.type).sort();
assert.deepEqual(types, ['circuit', 'gf9-chsh', 'penteract', 'russl-slice']);
const record = type => session.records.find(row => row.request.type === type);

// Polynomial basis 1,w of GF(9), w^2=1+2w (reduction polynomial w^2+w+2).
const mod3 = value => ((value % 3) + 3) % 3;
function add9(a, b) {return mod3(a % 3 + b % 3) + 3 * mod3(Math.floor(a / 3) + Math.floor(b / 3));}
function mul9(a, b) {
  const a0 = a % 3, a1 = Math.floor(a / 3), b0 = b % 3, b1 = Math.floor(b / 3);
  return mod3(a0 * b0 + a1 * b1) + 3 * mod3(a0 * b1 + a1 * b0 + 2 * a1 * b1);
}
const neg9 = a => mod3(-(a % 3)) + 3 * mod3(-Math.floor(a / 3));
const cube9 = a => mul9(mul9(a, a), a);
function inv9(a) {for (let b = 1; b < 9; b++) if (mul9(a, b) === 1) return b; throw Error('Zero norm');}
const gf9 = record('gf9-chsh'), psi = gf9.request.state;
assert.deepEqual(psi, [1, 0, 1, 3]); assert.deepEqual(gf9.request.settings, ['X', 'Z', 'Z', 'X']);
const ops = {X: [[0, 1], [1, 0]], Y: [[0, neg9(5)], [5, 0]], Z: [[1, 0], [0, 2]]};
const parseOp = name => name[0] === '-' ? ops[name[1]].map(row => row.map(neg9)) : ops[name];
function tensor(left, right) {return Array.from({length: 4}, (_, i) => Array.from({length: 4}, (_, j) => mul9(left[i >> 1][j >> 1], right[i & 1][j & 1])));}
const conjugate = psi.map(cube9), norm = psi.reduce((sum, value, i) => add9(sum, mul9(conjugate[i], value)), 0);
const dual = conjugate.map(value => mul9(value, inv9(norm)));
const [a, ap, b, bp] = gf9.request.settings.map(parseOp);
const rawTerms = [[a, b], [a, bp], [ap, b], [ap, bp]].map(([left, right]) => {
  const operator = tensor(left, right);
  const applied = operator.map(row => row.reduce((sum, value, i) => add9(sum, mul9(value, psi[i])), 0));
  return applied.reduce((sum, value, i) => add9(sum, mul9(dual[i], value)), 0);
});
const terms = rawTerms.map(value => value === 2 ? -1 : value);
const signedCHSH = terms[0] + terms[1] + terms[2] - terms[3];
assert.equal(gf9.result.norm, norm); assert.deepEqual(gf9.result.dual, dual);
assert.deepEqual(gf9.result.rawTerms, rawTerms); assert.deepEqual(gf9.result.terms, terms);
assert.equal(gf9.result.S, signedCHSH); assert.equal(gf9.result.absolute, Math.abs(signedCHSH));
assert.match(gf9.result.interpretation, /Joint probabilities remain indeterminate/);

// Exact Bell support; independent bigint implementation of the declared sampling PRNG.
const bell = record('circuit');
assert.equal(bell.request.program, 'q.circuit new bell 2\nq.circuit add h 0\nq.circuit add cx 0 1\nq.circuit run shots 2048 basis z');
assert.equal(bell.result.qubits, 2); assert.equal(bell.result.shots, 2048);
for (let i = 0; i < 4; i++) assert(Math.abs(bell.result.probabilities[i] - (i === 0 || i === 3 ? .5 : 0)) < 1e-12);
assert(Math.abs(bell.result.norm - 1) < 1e-12);
const mask32 = (1n << 32n) - 1n;
let state = 2166136261n;
for (const character of String(bell.request.seed)) state = ((state ^ BigInt(character.charCodeAt(0))) * 16777619n) & mask32;
assert.equal(bell.result.seedHash, Number(state)); if (state === 0n) state = 0x6d2b79f5n;
const counts = {'00': 0, '11': 0};
for (let shot = 0; shot < bell.result.shots; shot++) {
  state = (state ^ ((state << 13n) & mask32)) & mask32;
  state = (state ^ (state >> 17n)) & mask32;
  state = (state ^ ((state << 5n) & mask32)) & mask32;
  counts[state < (1n << 31n) ? '00' : '11']++;
}
assert.deepEqual(bell.result.counts, counts);
bell.result.marginalEntropyBits.forEach(value => assert(Math.abs(value - 1) < 1e-12));

// Independently regenerate all synthetic 64-bit sites, including zero-filled high bytes.
const synthetic = record('penteract');
assert.equal(synthetic.request.spec, 'gf9'); assert.equal(synthetic.request.mode, 'gradient');
const packed = Buffer.alloc(131072), histogram = {}, residues = [];
for (let index = 0; index < 16384; index++) {
  const coordinates = [Math.floor(index / 4096), Math.floor(index / 1024) % 4, Math.floor(index / 256) % 4, Math.floor(index / 16) % 16, index % 16];
  const value = coordinates.reduce((sum, coordinate) => sum + coordinate, 0) % 9;
  packed.writeUInt16LE(value, index * 8); histogram[value] = (histogram[value] ?? 0) + 1; residues.push(value);
}
assert.equal(synthetic.result.packedSha256, digest(packed)); assert.deepEqual(synthetic.result.histogram, histogram);
assert.equal(synthetic.result.packedBytes, packed.length); assert.equal(synthetic.result.siteCount, residues.length);

const russl = record('russl-slice');
assert.equal(russl.request.snapshot.schema, 'RUSSL-research-slice/1');
assert.equal(russl.result.sourceHashScope.verifiedFromOriginalBytes, false);
assert.equal(russl.result.sourceHashScope.importedWords.length, 5);
assert(russl.result.sourceHashScope.importedWords.every(word => word.originalHashesVerified === false));
assert.equal(russl.result.pixelCount, 1024); assert.equal(russl.result.selected.rowMajorIndex, 371);
assert.deepEqual(russl.result.selected.coordinates, ['19', '11', '2', '3', '6553']);
assert.equal(russl.result.selected.inverseVerified, true);
assert.deepEqual(russl.result.selected, russl.request.snapshot.selected);
assert.equal(russl.result.pixelPayloadSHA256, digest(Buffer.from(russl.request.snapshot.pixelPayloadHex, 'hex')));
const report = {schema: 'RUSSL-RESEARCH-INDEPENDENT-SESSION/1', status: 'PASS',
  input, inputSHA256: digest(bytes), recordCount: records.length, records,
  gf9: {status: 'PASS', arithmetic: 'Independent characteristic-3 polynomial reduction', rawTerms, terms, signedCHSH, norm, dual},
  circuit: {status: 'PASS', model: 'Independent Bell support and bigint FNV-1a/xorshift32 sampling reference', shots: bell.result.shots, counts},
  syntheticPenteract: {status: 'PASS', packedSHA256: digest(packed), sites: residues.length, byteLength: packed.length},
  russl: {status: 'PASS', selectedIndex: russl.result.selected.rowMajorIndex, coordinates: russl.result.selected.coordinates,
    pixelPayloadSHA256: russl.result.pixelPayloadSHA256, originalHashesClaimedVerified: false},
  scope: 'Independent Node builtins and explicit reference arithmetic; no terminal/workbench JavaScript imports. SHA-256 verifies envelope consistency, not authorship or physical theory.'};
fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({status: report.status, recordCount: records.length, types, gf9CHSH: signedCHSH, bellCounts: counts, syntheticSHA256: digest(packed)}, null, 2));
