import { spawnSync } from "node:child_process";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const source = path.join(root, "vendor/gfm-research-terminal");
for (const name of [
  "test-engine.cjs",
  "test-quantum.cjs",
  "test-integration.cjs",
  "test-boundaries.cjs",
  "test-hardening.cjs",
]) {
  const result = spawnSync(process.execPath, [path.join(source, "tests", name)], {
    cwd: source,
    stdio: "inherit",
  });
  if (result.error) {
    console.error(result.error.message);
    process.exit(1);
  }
  if (result.status !== 0) process.exit(result.status ?? 1);
}
