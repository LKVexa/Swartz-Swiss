export type FieldId = "gf8" | "gf80" | "gf100";

export const FIELD_INFO = Object.freeze({
  gf8: Object.freeze({
    label: "GF(8)",
    bits: 3,
    cardinality: 8n,
    polynomial: 0b1011n,
    polynomialLabel: "x^3 + x + 1",
  }),
  gf80: Object.freeze({
    label: "GF(2^80)",
    bits: 80,
    cardinality: 1n << 80n,
    polynomial: (1n << 80n) | (1n << 9n) | (1n << 4n) | (1n << 2n) | 1n,
    polynomialLabel: "x^80 + x^9 + x^4 + x^2 + 1",
  }),
  gf100: Object.freeze({
    label: "GF(2^100)",
    bits: 100,
    cardinality: 1n << 100n,
    polynomial: (1n << 100n) | (1n << 15n) | 1n,
    polynomialLabel: "x^100 + x^15 + 1",
  }),
});

function infoFor(field: FieldId) {
  if (field !== "gf8" && field !== "gf80" && field !== "gf100") {
    throw new RangeError("Select gf8, gf80 or gf100");
  }
  return FIELD_INFO[field];
}

export function fieldMask(field: FieldId): bigint {
  return infoFor(field).cardinality - 1n;
}

export function validateElement(value: bigint, field: FieldId): bigint {
  const mask = fieldMask(field);
  if (typeof value !== "bigint") {
    throw new TypeError("Field elements must be exact BigInt values");
  }
  if (value < 0n || value > mask) {
    throw new RangeError(`Field element must be in [0, ${infoFor(field).cardinality})`);
  }
  return value;
}

export function gfAdd(left: bigint, right: bigint): bigint {
  if (typeof left !== "bigint" || typeof right !== "bigint") {
    throw new TypeError("Field addition requires exact BigInt values");
  }
  if (left < 0n || right < 0n) {
    throw new RangeError("Field elements must be nonnegative");
  }
  return left ^ right;
}

export function gfMul(left: bigint, right: bigint, field: FieldId): bigint {
  let factor = validateElement(left, field);
  let other = validateElement(right, field);
  const info = infoFor(field);
  const top = 1n << BigInt(info.bits - 1);
  const mask = info.cardinality - 1n;
  const reduction = info.polynomial ^ info.cardinality;
  let result = 0n;
  while (other !== 0n) {
    if (other & 1n) result ^= factor;
    other >>= 1n;
    const carry = factor & top;
    factor = (factor << 1n) & mask;
    if (carry) factor ^= reduction;
  }
  return result;
}

export function gfPow(base: bigint, exponent: bigint, field: FieldId): bigint {
  let factor = validateElement(base, field);
  if (typeof exponent !== "bigint") {
    throw new TypeError("Exponent must be an exact BigInt value");
  }
  if (exponent < 0n) throw new RangeError("Exponent must be nonnegative");
  let power = exponent;
  let result = 1n;
  while (power !== 0n) {
    if (power & 1n) result = gfMul(result, factor, field);
    power >>= 1n;
    if (power !== 0n) factor = gfMul(factor, factor, field);
  }
  return result;
}

function polynomialDegree(value: bigint): number {
  return value === 0n ? -1 : value.toString(2).length - 1;
}

function polynomialRemainder(value: bigint, divisor: bigint): bigint {
  if (divisor === 0n) throw new RangeError("Polynomial divisor is zero");
  const divisorDegree = polynomialDegree(divisor);
  let remainder = value;
  while (polynomialDegree(remainder) >= divisorDegree) {
    remainder ^= divisor << BigInt(polynomialDegree(remainder) - divisorDegree);
  }
  return remainder;
}

function polynomialGcd(left: bigint, right: bigint): bigint {
  let a = left;
  let b = right;
  while (b !== 0n) [a, b] = [b, polynomialRemainder(a, b)];
  return a;
}

function polynomialSquare(value: bigint, modulus: bigint): bigint {
  let square = 0n;
  for (let bit = 0; bit <= polynomialDegree(value); bit++) {
    if ((value >> BigInt(bit)) & 1n) square |= 1n << BigInt(bit * 2);
  }
  return polynomialRemainder(square, modulus);
}

function irreducibilityWitness(field: "gf80" | "gf100") {
  // Degrees80 and100 both have prime divisors2,5 in Rabin's criterion.
  const info = FIELD_INFO[field];
  const degree = info.bits;
  const modulus = info.polynomial;
  let power = 2n;
  const gcdChecks: { exponent: number; gcdHex: string }[] = [];
  for (let exponent = 1; exponent <= degree; exponent++) {
    power = polynomialSquare(power, modulus);
    if (exponent === degree / 5 || exponent === degree / 2) {
      gcdChecks.push({ exponent, gcdHex: polynomialGcd(power ^ 2n, modulus).toString(16) });
    }
  }
  const finalFrobeniusHolds = power === 2n;
  return {
    degree,
    polynomial: info.polynomialLabel,
    polynomialHex: modulus.toString(16),
    criterion: "Rabin over GF(2), degree prime divisors 2 and 5",
    gcdChecks,
    finalFrobeniusHolds,
    irreducible: finalFrobeniusHolds && gcdChecks.every((check) => check.gcdHex === "1"),
  };
}

export function irreducibilityWitness80() {
  return irreducibilityWitness("gf80");
}

export function irreducibilityWitness100() {
  return irreducibilityWitness("gf100");
}
