import assert from "node:assert/strict";
import test from "node:test";
import { STACK } from "./spec.ts";
import {
  V0_PROSE,
  auditProse,
  parseNumberedProse,
  validateSpec,
} from "./audit.ts";

test("v0 prose parses into nine clauses", () => {
  const items = parseNumberedProse(V0_PROSE);
  assert.equal(items.length, 9);
  assert.deepEqual(
    items.map((item) => item.n),
    [1, 2, 3, 4, 5, 6, 7, 8, 9],
  );
  assert.match(items[2].body, /vvv/);
  assert.match(items[7].body, /^GIF /);
});

test("audit findings are the twelve v1 deltas", () => {
  const findings = auditProse(parseNumberedProse(V0_PROSE));
  assert.deepEqual(
    findings.map((finding) => finding.id),
    ["F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12"],
  );
  const kinds = findings.reduce<Record<string, number>>((acc, finding) => {
    acc[finding.kind] = (acc[finding.kind] ?? 0) + 1;
    return acc;
  }, {});
  assert.equal(kinds.fix, 2);
  assert.equal(kinds.upgrade, 4);
  assert.equal(kinds.harden, 6);
});

test("v1 spec validates and bumps the version", () => {
  assert.deepEqual(validateSpec(STACK), []);
  assert.equal(STACK.version, "1.0.0");
  assert.equal(STACK.previous, "0.9.0-chat");
  assert.equal(STACK.layers.length, 10);
  assert.equal(
    STACK.layers.filter((layer) => layer.status === "normative").length,
    6,
  );
});

test("a majority-vote LAMB contract is rejected", () => {
  const broken = structuredClone(STACK);
  const lamb = broken.layers.find((layer) => layer.id === "train.one-bit-lamb");
  assert.ok(lamb);
  lamb.invariants.push("Reduce by majority vote of the signs.");
  assert.ok(validateSpec(broken).some((line) => /majority vote/.test(line)));
});
