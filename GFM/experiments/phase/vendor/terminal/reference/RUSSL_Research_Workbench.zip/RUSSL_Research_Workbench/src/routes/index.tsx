import { createFileRoute } from "@tanstack/react-router";
import { AntibitBench } from "@/components/antibit-bench";

export const Route = createFileRoute("/")({ component: AntibitBench });
