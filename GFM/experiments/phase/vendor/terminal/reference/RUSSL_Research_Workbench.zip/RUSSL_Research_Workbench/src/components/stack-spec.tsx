import {
  V0_VERSION,
  V1_VERSION,
  auditProse,
  parseNumberedProse,
  validateSpec,
  V0_PROSE,
  type FindingKind,
} from "@/lib/stack/audit";
import { STACK } from "@/lib/stack/spec";

const parsed = parseNumberedProse(V0_PROSE);
const findings = auditProse(parsed);
const violations = validateSpec(STACK);

const KIND_LABEL: Record<FindingKind, string> = {
  fix: "Fix",
  upgrade: "Upgrade",
  harden: "Harden",
};

function countKind(kind: FindingKind): number {
  return findings.filter((finding) => finding.kind === kind).length;
}

const bytes = STACK.llama70bFp16KvBytes;
const gigabytes = bytes / 1_000_000_000;
const gibibytes = bytes / 1024 ** 3;

export function StackSpecView() {
  const normative = STACK.layers.filter((layer) => layer.status === "normative").length;
  const allowed = STACK.edges.filter((edge) => edge.allow).length;
  const denied = STACK.edges.length - allowed;

  return (
    <main className="mx-auto w-full max-w-3xl px-4 py-8 sm:px-6 sm:py-12">
      <header className="border-b border-rule pb-6">
        <p className="font-mono text-xs tracking-wide text-muted uppercase">
          Spec {V1_VERSION}
          <span className="px-2 text-rule">/</span>
          was {V0_VERSION}
        </p>
        <h1 className="mt-2 font-serif text-4xl leading-tight font-medium text-ink sm:text-5xl">
          Audited stack
        </h1>
        <p className="mt-3 max-w-xl text-lg text-ink">
          Parsed the nine-line list, corrected the numbers, split what had been taped together, and
          froze the result as {V1_VERSION}. {violations.length === 0 ? "The spec validates." : "The spec failed validation."}
        </p>
      </header>

      {violations.length > 0 ? (
        <p className="mt-6 border border-oxide px-3 py-2 font-mono text-sm text-oxide" role="alert">
          {violations.join(" · ")}
        </p>
      ) : null}

      <dl className="mt-6 grid grid-cols-2 gap-px overflow-hidden border border-rule bg-rule sm:grid-cols-4">
        <Stat label="Clauses parsed" value={String(parsed.length)} />
        <Stat label="Normative layers" value={String(normative)} />
        <Stat label="Edges denied" value={String(denied)} />
        <Stat label="Validation" value={violations.length === 0 ? "Clean" : "Failed"} />
      </dl>

      <section className="mt-10">
        <h2 className="font-serif text-2xl text-ink">What changed</h2>
        <p className="mt-1 text-muted">
          {countKind("fix")} fixes, {countKind("upgrade")} upgrades, {countKind("harden")} hardenings.
          Fixes correct a false or missing number. Upgrades add a rule v0 only implied. Hardenings
          close a reading that would let a rejected essay back in.
        </p>
        <ol className="mt-4 divide-y divide-rule border-y border-rule">
          {findings.map((finding) => (
            <li key={finding.id} className="grid gap-1 py-3 sm:grid-cols-[7.5rem_1fr] sm:gap-4">
              <p className="font-mono text-xs text-oxide">
                {finding.id}
                <span className="mt-1 block text-muted">{KIND_LABEL[finding.kind]}</span>
              </p>
              <div>
                <p className="text-ink">{finding.title}</p>
                <p className="text-sm text-muted">{finding.detail}</p>
                <p className="mt-1 font-mono text-xs text-muted">{finding.layer}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-10">
        <h2 className="font-serif text-2xl text-ink">Reserved words</h2>
        <p className="mt-1 text-muted">
          A claim that uses one of these without naming the sense is not a statement in this spec.
        </p>
        <div className="mt-4 flex flex-col gap-4">
          {STACK.homonyms.map((hom) => (
            <div key={hom.token} className="border border-rule">
              <p className="border-b border-rule px-3 py-2 font-mono text-sm text-ink">{hom.token}</p>
              <ul>
                {hom.senses.map((sense) => (
                  <li
                    key={sense.name}
                    className="grid gap-1 border-b border-rule px-3 py-2 last:border-b-0 sm:grid-cols-[1fr_auto] sm:items-baseline"
                  >
                    <span>{sense.name}</span>
                    <span className="font-mono text-xs text-muted">{sense.livesIn}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="font-serif text-2xl text-ink">Layers</h2>
        <p className="mt-1 text-muted">
          Six normative layers, one closed analysis, three references. The old ninth line is now two
          of those references, so the count is ten.
        </p>
        <div className="mt-4 flex flex-col gap-3">
          {STACK.layers.map((layer) => (
            <details key={layer.id} className="group border border-rule">
              <summary className="flex min-h-11 cursor-pointer list-none items-baseline gap-3 px-3 py-3">
                <span className="font-mono text-xs text-muted">{layer.n}</span>
                <span className="flex-1 text-ink">{layer.title}</span>
                <span className="font-mono text-xs text-oxide">{layer.status}</span>
              </summary>
              <div className="border-t border-rule px-3 py-3">
                <p className="font-mono text-xs text-muted">{layer.id}</p>
                <p className="mt-2">{layer.summary}</p>
                <h3 className="mt-4 font-mono text-xs tracking-wide text-muted uppercase">Holds</h3>
                <ul className="mt-2 list-disc pl-5 text-sm">
                  {layer.invariants.map((line) => (
                    <li key={line} className="mt-1">
                      {line}
                    </li>
                  ))}
                </ul>
                <h3 className="mt-4 font-mono text-xs tracking-wide text-oxide uppercase">Refuses</h3>
                <ul className="mt-2 list-disc pl-5 text-sm">
                  {layer.rejects.map((line) => (
                    <li key={line} className="mt-1">
                      {line}
                    </li>
                  ))}
                </ul>
              </div>
            </details>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="font-serif text-2xl text-ink">Edges</h2>
        <p className="mt-1 text-muted">
          {allowed} allowed, {denied} denied. A missing edge is not an invitation.
        </p>
        <ul className="mt-4 divide-y divide-rule border-y border-rule">
          {STACK.edges.map((edge) => (
            <li key={`${edge.from}-${edge.to}`} className="py-3">
              <p className="font-mono text-xs text-ink">
                <span className={edge.allow ? "text-ink" : "text-oxide"}>
                  {edge.allow ? "allow" : "deny"}
                </span>
                <span className="text-muted">
                  {" "}
                  {edge.from} → {edge.to}
                </span>
              </p>
              <p className="mt-1 text-sm">{edge.relation}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-10 border-t border-rule pt-6">
        <h2 className="font-serif text-2xl text-ink">Worked number</h2>
        <p className="mt-2">
          Llama-70B key-value cache, FP16, one million tokens. Eighty layers, eight key-value heads,
          head size 128, two bytes, keys and values.
        </p>
        <p className="mt-3 font-mono text-sm text-ink">
          2 × 80 × 8 × 128 × 10^6 × 2 = {bytes.toLocaleString("en-US")} bytes
        </p>
        <p className="mt-1 font-mono text-sm text-muted">
          {gigabytes.toLocaleString("en-US")} GB decimal · {gibibytes.toFixed(1)} GiB
        </p>
        <p className="mt-3 text-sm text-muted">
          The source essay’s 135 GB is withdrawn. FP8 halves the byte count. It does not change the
          formula.
        </p>
      </section>

      <section className="mt-10 border-t border-rule pt-6">
        <h2 className="font-serif text-2xl text-ink">Version policy</h2>
        <ul className="mt-3 list-disc pl-5 text-sm">
          <li>Major — a layer changes status, or a denied edge becomes allowed.</li>
          <li>Minor — an invariant is added and none is removed.</li>
          <li>Patch — a citation or a worked number is corrected.</li>
        </ul>
        <p className="mt-4 font-mono text-xs text-muted">
          {V0_VERSION} → {V1_VERSION}
        </p>
      </section>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-paper px-3 py-3">
      <dt className="font-mono text-xs text-muted">{label}</dt>
      <dd className="mt-1 font-serif text-2xl text-ink">{value}</dd>
    </div>
  );
}
