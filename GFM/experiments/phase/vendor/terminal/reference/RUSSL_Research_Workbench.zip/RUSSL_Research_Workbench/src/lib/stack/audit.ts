/** v0.9.0-chat — the prose stack, verbatim, before this audit. */
export const V0_PROSE = `Stack now
1. Bit/anti-bit toy model, written up. Separate from every “bit” below.
2. p-adic geometry that is actually mathematics. The 2-adic NPU plan for LAMB stays rejected.
3. 1-bit LAMB: training compression only. Execution path, if any, is packed signs, frozen vvv, ReduceScatter then average then AllGather. Unikernel is optional and painful. Not ternary weights.
4. Inference compression: GPTQ, AWQ, SmoothQuant, MX, KV FP8, BitNet. Different layer of the stack.
5. Optics to treat as buildable: ASM, double phase or GS, LUT, TIFF float in, 8-bit frame out, temporal focusing if the spots must be 3D. D2NN as a trained linear (or weakly nonlinear) map.
6. HRR as algebra: convolution, cleanup, permutation for order, SSP for continuous variables. Optical only at the convolution step, and only if a directive says so.
7. Storage: BigTIFF / COG / OME-TIFF / OME-Zarr, with the chunk-axis tradeoff explicit. Not the hybrid format with private tags.
8. GIF the quantum frame: a bookkeeping trick for pump depletion and Wigner negativity in pulsed squeezing. No role in the file path.
9. IdeaPad note and the neurophotonics survey: reference material, not subsystems of the hologram pipeline.`;

export const V0_VERSION = "0.9.0-chat";
export const V1_VERSION = "1.0.0";

export type FindingKind = "fix" | "upgrade" | "harden";

export type Finding = {
  id: string;
  kind: FindingKind;
  layer: string;
  title: string;
  detail: string;
};

export type ParsedClause = { n: number; body: string };

export function parseNumberedProse(text: string): ParsedClause[] {
  const body = text.replace(/^\s*Stack now\s*/i, "").trim();
  if (!body) return [];
  const parts = body.split(/\n(?=\d+\.\s)/);
  const clauses: ParsedClause[] = [];
  for (const part of parts) {
    const match = part.match(/^(\d+)\.\s+([\s\S]*)$/);
    if (!match) {
      throw new Error(`Unparsed clause: ${part.slice(0, 48)}`);
    }
    clauses.push({
      n: Number(match[1]),
      body: match[2].replace(/\s+/g, " ").trim(),
    });
  }
  return clauses;
}

function clause(items: ParsedClause[], n: number): string {
  return items.find((item) => item.n === n)?.body ?? "";
}

/** What v0.9.0-chat still left loose, mistyped, or easy to misuse. */
export function auditProse(items: ParsedClause[]): Finding[] {
  const findings: Finding[] = [];
  const c3 = clause(items, 3);
  const c5 = clause(items, 5);
  const c6 = clause(items, 6);
  const c8 = clause(items, 8);
  const c9 = clause(items, 9);

  if (/vvv/.test(c3)) {
    findings.push({
      id: "F1",
      kind: "fix",
      layer: "train.one-bit-lamb",
      title: "Second moment is v, not vvv",
      detail:
        "The v0 line froze “vvv”. That is a typesetting collision, not a tensor. The frozen object is the second-moment vector v.",
    });
  }

  findings.push({
    id: "F2",
    kind: "harden",
    layer: "math.padic",
    title: "Name the rejection, keep the mathematics",
    detail:
      "v0 already refuses the 2-adic NPU. v1 files that refusal as rej.2adic-npu so the number theory can be cited without importing sign-as-unit-sphere, majority-vote reduction, or the essay’s energy figures.",
  });

  if (/Unikernel/.test(c3)) {
    findings.push({
      id: "F3",
      kind: "harden",
      layer: "train.one-bit-lamb",
      title: "Unikernel leaves the numerical contract",
      detail:
        "v0 put the unikernel on the execution path and then called it optional. v1 deletes it from the contract. Any host may run the same tensors. The contract is the warmup, the freeze, the mask, the error buffer, and ReduceScatter → average → AllGather.",
    });
  }

  findings.push({
    id: "F4",
    kind: "fix",
    layer: "infer.quant",
    title: "Pin the KV worked example",
    detail:
      "v0 named “KV FP8” and did not pin a size. The quantization essay’s 135 GB for Llama-70B at one million tokens, FP16, does not match the formula. v1 uses 2·80·8·128·10⁶·2 = 327,680,000,000 bytes.",
  });

  findings.push({
    id: "F5",
    kind: "upgrade",
    layer: "infer.quant",
    title: "Forbid the cross-layer substitution",
    detail:
      "v0 said the inference layer is different and that 1-bit LAMB is not ternary weights. v1 states the denied edge: a momentum sign stream is not a weight format, and BitNet b1.58 is not 1-bit LAMB.",
  });

  if (/weakly nonlinear/.test(c5)) {
    findings.push({
      id: "F6",
      kind: "harden",
      layer: "optics.field",
      title: "A linear stack is one map",
      detail:
        "“Trained linear (or weakly nonlinear)” reads as permission to stack masks and call it depth. Cascaded linear diffraction is exactly one linear transform. Depth counts only with a real nonlinearity. A four-pattern sorter is not an ALU.",
    });
  }

  if (/cleanup/.test(c6) && !/mandatory|required/.test(c6)) {
    findings.push({
      id: "F7",
      kind: "harden",
      layer: "algebra.hrr",
      title: "Cleanup is fail-closed",
      detail:
        "v0 listed cleanup. v1 makes the layer invalid without it. Circular correlation returns a noisy vector. The symbol is the nearest codeword, or there is no symbol.",
    });
  }

  findings.push({
    id: "F8",
    kind: "upgrade",
    layer: "storage.containers",
    title: "The four containers are not substitutes",
    detail:
      "v0 named BigTIFF, COG, OME-TIFF, and OME-Zarr and the chunk-axis tradeoff. v1 adds the selection rule: they answer different queries. A float hologram is not a GeoTIFF and not a Zarr until someone writes that conversion.",
  });

  if (/^GIF\b/.test(c8)) {
    findings.push({
      id: "F9",
      kind: "harden",
      layer: "ref.gaussian-interaction-frame",
      title: "Retire the bare token GIF",
      detail:
        "v0’s layer title is “GIF the quantum frame”. That token already means GIF89a. v1’s layer id is ref.gaussian-interaction-frame. GIF89a stays in the homonym ledger and is not a compute layer.",
    });
  }

  if (/IdeaPad/.test(c9) && /neurophotonics/.test(c9)) {
    findings.push({
      id: "F10",
      kind: "upgrade",
      layer: "ref.neurophotonics",
      title: "Split the reference bin",
      detail:
        "v0 taped the IdeaPad note to the neurophotonics survey. v1 splits them. The only sentence that may inform optics is the 3D-SHOT axial constraint. Nothing else in either note is a subsystem.",
    });
  }

  findings.push({
    id: "F11",
    kind: "harden",
    layer: "lexicon",
    title: "Homonym ledger is normative",
    detail:
      "The failure mode across the source essays was shared words: bit, holographic, GIF, RAM sampling. v0 handled this in prose. v1 fails validation if a layer id or a normative claim uses one of those words without a qualifier.",
  });

  findings.push({
    id: "F12",
    kind: "upgrade",
    layer: "spec",
    title: "Semver, starting at 1.0.0",
    detail:
      "0.9.0-chat was an unparsed list. 1.0.0 is the first document with a schema, invariants, denied edges, and a version policy. Major: a status change or a newly allowed edge. Minor: an added invariant. Patch: a citation or a worked number.",
  });

  return findings;
}

export type LayerStatus = "closed" | "normative" | "reference";

export type StackLayer = {
  id: string;
  n: string;
  title: string;
  status: LayerStatus;
  summary: string;
  invariants: string[];
  rejects: string[];
};

export type StackEdge = {
  from: string;
  to: string;
  allow: boolean;
  relation: string;
};

export type Homonym = {
  token: string;
  senses: { name: string; livesIn: string }[];
};

export type StackSpec = {
  version: string;
  previous: string;
  layers: StackLayer[];
  edges: StackEdge[];
  homonyms: Homonym[];
  /** Llama-70B, FP16, 10^6 tokens. 2·80·8·128·1e6·2. */
  llama70bFp16KvBytes: number;
};

const BARE_GIF = /\bGIF\b/;

export function validateSpec(spec: StackSpec): string[] {
  const violations: string[] = [];
  const ids = new Set<string>();

  if (spec.version !== V1_VERSION) {
    violations.push(`version ${spec.version} is not ${V1_VERSION}`);
  }
  if (spec.previous !== V0_VERSION) {
    violations.push(`previous ${spec.previous} is not ${V0_VERSION}`);
  }
  if (spec.llama70bFp16KvBytes !== 327_680_000_000) {
    violations.push("KV worked example is not 327680000000 bytes");
  }

  for (const layer of spec.layers) {
    if (ids.has(layer.id)) violations.push(`duplicate id ${layer.id}`);
    ids.add(layer.id);
    if (layer.id === "gif" || /(^|\.)gif($|\.)/.test(layer.id)) {
      violations.push(`bare GIF id: ${layer.id}`);
    }
    const blob = `${layer.title}\n${layer.summary}\n${layer.invariants.join("\n")}`;
    if (BARE_GIF.test(blob)) {
      violations.push(`${layer.id} uses the bare token GIF`);
    }
    if (/\bholographic\b/i.test(blob)) {
      const namedHrr =
        layer.id === "algebra.hrr" && /reduced representation/i.test(layer.title);
      const opticalHome = layer.id === "optics.field";
      if (!namedHrr && !opticalHome) {
        violations.push(`${layer.id} uses “holographic” outside its two named homes`);
      }
    }
    if (layer.id === "train.one-bit-lamb") {
      const contract = layer.invariants.join(" ");
      if (!/ReduceScatter/.test(contract)) {
        violations.push("1-bit LAMB contract dropped ReduceScatter");
      }
      if (/majority vote/i.test(contract)) {
        violations.push("1-bit LAMB contract contains majority vote");
      }
      if (/unikernel/i.test(contract)) {
        violations.push("unikernel leaked back into the LAMB contract");
      }
      if (/vvv/.test(contract)) violations.push("vvv survived in the LAMB contract");
    }
    if (layer.id === "optics.field") {
      const contract = layer.invariants.join(" ");
      if (!/one linear/.test(contract)) {
        violations.push("optics contract lost the linear-collapse rule");
      }
      if (/zero energy|speed of light/i.test(contract)) {
        violations.push("optics contract repeats a zero-energy claim");
      }
    }
    if (layer.id === "algebra.hrr") {
      if (!layer.invariants.some((line) => /mandatory/i.test(line))) {
        violations.push("HRR cleanup is not mandatory");
      }
    }
  }

  for (const edge of spec.edges) {
    if (!ids.has(edge.from) || !ids.has(edge.to)) {
      violations.push(`edge ${edge.from} → ${edge.to} names an unknown layer`);
    }
  }

  for (const hom of spec.homonyms) {
    if (hom.senses.length < 2) {
      violations.push(`homonym ${hom.token} has fewer than two senses`);
    }
  }

  const allowed = spec.edges.filter((edge) => edge.allow);
  const denied = spec.edges.filter((edge) => !edge.allow);
  if (allowed.length < 2) violations.push("allowed-edge list collapsed");
  if (!denied.some((edge) => edge.from === "math.padic" && edge.to === "train.one-bit-lamb")) {
    violations.push("p-adic → LAMB denial missing");
  }
  if (
    !denied.some(
      (edge) => edge.from === "ref.gaussian-interaction-frame" && edge.to === "storage.containers",
    )
  ) {
    violations.push("interaction-frame → storage denial missing");
  }

  return violations;
}
