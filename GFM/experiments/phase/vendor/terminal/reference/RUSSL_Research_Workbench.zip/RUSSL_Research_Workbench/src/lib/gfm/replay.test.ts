import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import test from "node:test";
import { AXIS_NAMES, DEFAULT_CONFIG, sampleSlice } from "./penteract.ts";
import type { SliceConfig } from "./penteract.ts";
import { createReplayBundle, restoreWordSources } from "./replay.ts";
import { EMPTY_WORD_SOURCES, importRawWord } from "./raw-words.ts";
import type { ImportedWord, WordSources, RawWordFormat } from "./raw-words.ts";

const sha = (bytes: Uint8Array) => createHash("sha256").update(bytes).digest("hex");
const encoder = new TextEncoder();
const config: SliceConfig = {
  ...DEFAULT_CONFIG,
  words: ["3", "3", "3", "3", "3"],
  fixed: ["0", "0", "0", "0", "0"],
  origin: ["0", "0"],
  axes: [0, 1],
  size: 2,
  tick: "7",
  couplingAxis: 4,
};

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

// Byte readers deliberately use no application export or pixel reader.
function readZip(bytes: Uint8Array): Map<string, Uint8Array> {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const end = bytes.length - 22;
  assert.equal(view.getUint32(end, true), 0x06054b50);
  const count = view.getUint16(end + 10, true);
  assert.equal(view.getUint16(end + 8, true), count);
  let central = view.getUint32(end + 16, true);
  assert.equal(central + view.getUint32(end + 12, true), end);
  const result = new Map<string, Uint8Array>();
  for (let index = 0; index < count; index++) {
    assert.equal(view.getUint32(central, true), 0x02014b50);
    assert.equal(view.getUint16(central + 10, true), 0);
    const length = view.getUint16(central + 28, true);
    const name = new TextDecoder().decode(bytes.subarray(central + 46, central + 46 + length));
    const local = view.getUint32(central + 42, true);
    assert.equal(view.getUint32(local, true), 0x04034b50);
    assert.equal(view.getUint16(local + 8, true), 0);
    assert.equal(view.getUint16(local + 26, true), length);
    const size = view.getUint32(central + 24, true);
    assert.equal(view.getUint32(central + 20, true), size);
    assert.equal(view.getUint32(local + 18, true), size);
    assert.equal(view.getUint32(local + 22, true), size);
    const body = bytes.slice(local + 30 + length, local + 30 + length + size);
    assert.equal(body.length, size);
    assert.equal(crc32(body), view.getUint32(central + 16, true));
    assert.equal(crc32(body), view.getUint32(local + 14, true));
    assert(!result.has(name));
    result.set(name, body);
    central +=
      46 + length + view.getUint16(central + 30, true) + view.getUint16(central + 32, true);
  }
  assert.equal(central, end);
  return result;
}

function readTiff(bytes: Uint8Array) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  assert.equal(view.getUint16(0, true), 0x4949);
  assert.equal(view.getUint16(2, true), 42);
  let offset = view.getUint32(4, true);
  const planes: number[][] = [];
  let manifest: unknown;
  while (offset) {
    const count = view.getUint16(offset, true);
    const tags = new Map<number, { type: number; count: number; value: number; offset: number }>();
    for (let index = 0; index < count; index++) {
      const entry = offset + 2 + 12 * index;
      tags.set(view.getUint16(entry, true), {
        type: view.getUint16(entry + 2, true),
        count: view.getUint32(entry + 4, true),
        value: view.getUint32(entry + 8, true),
        offset: entry,
      });
    }
    assert.equal(tags.get(258)!.value, 32);
    assert.equal(tags.get(339)!.value, 1);
    const strip = tags.get(273)!.value,
      size = tags.get(279)!.value;
    planes.push(
      Array.from({ length: size / 4 }, (_, index) => view.getUint32(strip + index * 4, true)),
    );
    const description = tags.get(270);
    if (description) {
      const start = description.count <= 4 ? description.offset + 8 : description.value;
      manifest = JSON.parse(
        new TextDecoder().decode(bytes.subarray(start, start + description.count - 1)),
      );
    }
    offset = view.getUint32(offset + 2 + count * 12, true);
  }
  assert.equal(planes.length, 5);
  const payload = new Uint8Array(planes[0].length * 20);
  const output = new DataView(payload.buffer);
  planes.forEach((plane, lane) =>
    plane.forEach((value, index) => output.setUint32(index * 20 + lane * 4, value, false)),
  );
  return { manifest, payload };
}

async function sourcesWith(formats: readonly (RawWordFormat | null)[]): Promise<WordSources> {
  assert.equal(formats.length, 5);
  const slots: [
    ImportedWord | null,
    ImportedWord | null,
    ImportedWord | null,
    ImportedWord | null,
    ImportedWord | null,
  ] = [null, null, null, null, null];
  for (let axis = 0; axis < 5; axis++) {
    const format = formats[axis];
    if (!format) continue;
    const bytes = Uint8Array.from(
      { length: format === "appliance-le" ? 41 : 60 },
      (_, index) => (index * 37 + axis * 31 + 128) & 255,
    );
    slots[axis] = await importRawWord(bytes, { name: `original-${axis}-π.bin`, format });
  }
  return slots;
}

async function exercise(formats: readonly (RawWordFormat | null)[]) {
  const sources = await sourcesWith(formats);
  const slice = sampleSlice(config, sources);
  const manifest = { ...slice.manifest, sha256: { pixelPayloadBE: sha(slice.pixelBytes) } };
  const files = readZip(createReplayBundle(slice, manifest, sources, "slice-test"));
  assert.equal(files.size, 4 + formats.filter(Boolean).length);
  assert.deepEqual(JSON.parse(new TextDecoder().decode(files.get("manifest.json"))), manifest);
  assert.deepEqual(files.get("pixel160.bin"), slice.pixelBytes);
  const tiff = readTiff(files.get("slice-test.tiff")!);
  assert.deepEqual(tiff.manifest, manifest);
  assert.deepEqual(tiff.payload, slice.pixelBytes);
  for (let index = 0; index < slice.cells.length; index++) {
    const word = Array.from(tiff.payload.subarray(20 * index, 20 * index + 20)).reduce(
      (value, byte) => (value << 8n) | BigInt(byte),
      0n,
    );
    assert.equal(word >> 80n, slice.cells[index].state.q);
    assert.equal(word & ((1n << 80n) - 1n), slice.cells[index].state.p);
  }
  const restored = await restoreWordSources(manifest, (name) => files.get(name));
  for (let axis = 0; axis < 5; axis++) {
    const before = sources[axis],
      after = restored[axis];
    if (!before) {
      assert.equal(after, null);
      continue;
    }
    assert(after);
    const original = files.get(`words/${axis}-${AXIS_NAMES[axis]}.bin`)!;
    assert.deepEqual(original, before.bytes());
    assert.deepEqual(after.bytes(), before.bytes());
    assert.equal(after.sha256, sha(original));
    assert.equal(after.canonicalSha256, sha(before.canonicalBytes()));
    assert.equal(after.paddingBits, before.format === "appliance-le" ? 152 : 0);
    for (let unit = 0n; unit < before.unitCount; unit++)
      assert.deepEqual(after.unit(unit), before.unit(unit));
  }
  assert.deepEqual(sampleSlice(config, restored).pixelBytes, slice.pixelBytes);
  return { sources, manifest, slice, files };
}

test("Virtual replay preserves four entries and restores five explicit generated slots", async () => {
  const { sources, manifest, slice, files } = await exercise([null, null, null, null, null]);
  assert.equal(manifest.schema, "RUSSL-five-word-cube/2");
  assert.deepEqual(
    createReplayBundle(slice, manifest, null, "slice-test"),
    createReplayBundle(slice, manifest, sources, "slice-test"),
  );
  let reads = 0;
  assert.equal(
    await restoreWordSources(manifest, () => {
      reads++;
      return undefined;
    }),
    EMPTY_WORD_SOURCES,
  );
  assert.equal(reads, 0);
  assert(![...files.keys()].some((name) => name.startsWith("words/")));
});

test("Five native appliance originals survive padding, ZIP, TIFF and exact replay", async () => {
  const { manifest } = await exercise(Array(5).fill("appliance-le"));
  assert.equal(manifest.schema, "RUSSL-five-word-cube/3");
});

test("Five canonical BE words preserve original unit order and full states", async () => {
  await exercise(Array(5).fill("russl-be"));
});

test("Declared native widths survive replay with non-byte-aligned padding", async () => {
  const original = Uint8Array.from({ length: 41 }, (_, index) => (index * 17) & 255);
  original[40] = 1;
  const source = await importRawWord(original, {
    name: "321-bit.bin",
    format: "appliance-le",
    sourceBits: 321,
  });
  const sources: WordSources = [source, null, null, null, null];
  const slice = sampleSlice(config, sources);
  const files = readZip(createReplayBundle(slice, slice.manifest, sources, "width-321"));
  const restored = await restoreWordSources(slice.manifest, (name) => files.get(name));
  assert.equal(restored[0]!.sourceBits, 321);
  assert.equal(restored[0]!.paddingBits, 159);
  assert.deepEqual(restored[0]!.bytes(), original);
  assert.equal(restored[0]!.sha256, source.sha256);
  assert.equal(restored[0]!.canonicalSha256, source.canonicalSha256);
  assert.deepEqual(sampleSlice(config, restored).pixelBytes, slice.pixelBytes);
});

test("Mixed native, canonical and generated words replay from exact original bytes", async () => {
  await exercise(["appliance-le", null, "russl-be", null, "appliance-le"]);
});

test("Replay restoration rejects missing/altered files and dishonest source metadata", async () => {
  const { manifest, files } = await exercise(["appliance-le", null, "russl-be", null, null]);
  await assert.rejects(
    restoreWordSources(manifest, () => undefined),
    /Missing original/,
  );
  const entry = "words/0-length.bin";
  const changed = files.get(entry)!.slice();
  changed[0] ^= 1;
  await assert.rejects(
    restoreWordSources(manifest, (name) => (name === entry ? changed : files.get(name))),
    /differs/,
  );
  await assert.rejects(
    restoreWordSources(manifest, (name) =>
      name === entry ? changed.subarray(1) : files.get(name),
    ),
    /byte count/,
  );
  for (const delta of [
    { entry: "words/../source.bin" },
    { sourceFormat: "mystery" },
    { originalName: "../source" },
    { sourceBits: 327 },
    { paddingBits: 151 },
    { unitCount: "2" },
    { sourceSha256: "0".repeat(64) },
    { canonicalSha256: "0".repeat(64) },
    { unitProfile: "lossy" },
    { sourceByteLength: 40 },
  ]) {
    const altered = structuredClone(manifest);
    Object.assign(altered.words[0], delta);
    await assert.rejects(restoreWordSources(altered, (name) => files.get(name)));
  }
  const altered = structuredClone(manifest);
  altered.config.words[0] = "4";
  await assert.rejects(
    restoreWordSources(altered, (name) => files.get(name)),
    /differs/,
  );
});

test("Replay export rejects omitted sources, sparse slots, sparse metadata and unsafe names", async () => {
  const { sources, manifest, slice } = await exercise(["appliance-le", null, null, null, null]);
  assert.throws(
    () => createReplayBundle(slice, manifest, EMPTY_WORD_SOURCES, "sample"),
    /Missing original/,
  );
  assert.throws(
    () => createReplayBundle(slice, manifest, new Array(5) as unknown as WordSources, "sample"),
    /sparse/,
  );
  const virtual = sampleSlice(config);
  assert.throws(
    () => createReplayBundle(virtual, virtual.manifest, sources, "sample"),
    /cannot be exported/,
  );
  for (const name of ["", "../escape", "a/b", "C:drive", ".", "..", "null\0stem"])
    assert.throws(() => createReplayBundle(slice, manifest, sources, name));
  const words = structuredClone(manifest);
  delete words.words[1];
  await assert.rejects(
    restoreWordSources(words, () => encoder.encode("unused")),
    /Word descriptor/,
  );
  const lengths = structuredClone(manifest);
  Reflect.deleteProperty(lengths.config.words, "1");
  await assert.rejects(
    restoreWordSources(lengths, () => undefined),
    /lengths/,
  );
});
