DEMONSTRATION APPLIANCE WORDS

These five complete operands were exported from the actual UltraWide Appliance Python BRIM VM using our included seven-instruction demo and initial register5. They are demonstration data, not the user's appliance state.
Choose Ultra-wide appliance word in the workbench and load length.bin, width.bin, depth.bin, height.bin and ceiling.bin into their matching axes.
Each word is 131072 little-endian bytes and becomes6554 Pixel160 units. Its final96 source bits receive64 high zero padding bits.
To reproduce using an existing appliance checkout, see README-WORKBENCH.txt and scripts/export-appliance-words.py. The appliance code is not bundled.
