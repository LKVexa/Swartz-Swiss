import type { PhaseState } from "./dynamics";

export const LANE_NAMES = ["L4", "L5", "L6", "L7", "L8"] as const;
export type Pixel160 = [number, number, number, number, number];

const FIELD_MAX = (1n << 100n) - 1n;
const STATE80_MAX = (1n << 80n) - 1n;
const U32_MASK = 0xffffffffn;
const PIXEL_MASK = (1n << 160n) - 1n;

function phaseWord(state: PhaseState): bigint {
  if (
    !state ||
    typeof state.q !== "bigint" ||
    typeof state.p !== "bigint" ||
    state.q < 0n ||
    state.p < 0n ||
    state.q > FIELD_MAX ||
    state.p > FIELD_MAX
  ) {
    throw new RangeError("q and p must be exact GF(2^100) values in [0, 2^100)");
  }
  return (state.q << 100n) | state.p;
}

function validatePixel(lanes: Pixel160): void {
  if (
    !Array.isArray(lanes) ||
    lanes.length !== 5 ||
    Array.from(lanes).some((lane) => !Number.isInteger(lane) || lane < 0 || lane > 0xffffffff)
  ) {
    throw new RangeError("Pixel160 requires exactly five unsigned 32-bit lanes");
  }
}

/** Full-state ABI for the active GF(2^80) model: BE160(q||p), 80 bits each. */
export function encodeStatePixel160(state: PhaseState): Pixel160 {
  if (
    !state ||
    typeof state.q !== "bigint" ||
    typeof state.p !== "bigint" ||
    state.q < 0n ||
    state.p < 0n ||
    state.q > STATE80_MAX ||
    state.p > STATE80_MAX
  ) {
    throw new RangeError("q and p must be exact GF(2^80) values in [0, 2^80)");
  }
  const word = (state.q << 80n) | state.p;
  return [
    Number((word >> 128n) & U32_MASK),
    Number((word >> 96n) & U32_MASK),
    Number((word >> 64n) & U32_MASK),
    Number((word >> 32n) & U32_MASK),
    Number(word & U32_MASK),
  ];
}

export function decodeStatePixel160(pixel: Pixel160): PhaseState {
  validatePixel(pixel);
  const word = pixel.reduce((result, lane) => (result << 32n) | BigInt(lane), 0n);
  return { q: word >> 80n, p: word & STATE80_MAX };
}

/** An observation: all 100 p bits and the low 60 q bits. Forty q bits are omitted. */
export function projectPixel160(state: PhaseState): Pixel160 {
  const word = phaseWord(state) & PIXEL_MASK;
  return [
    Number((word >> 128n) & U32_MASK),
    Number((word >> 96n) & U32_MASK),
    Number((word >> 64n) & U32_MASK),
    Number((word >> 32n) & U32_MASK),
    Number(word & U32_MASK),
  ];
}

/** Pixel ABI: BE32(L4)||BE32(L5)||BE32(L6)||BE32(L7)||BE32(L8). */
export function encodePixel160(lanes: Pixel160): Uint8Array {
  validatePixel(lanes);
  const bytes = new Uint8Array(20);
  const view = new DataView(bytes.buffer);
  lanes.forEach((lane, index) => view.setUint32(index * 4, lane, false));
  return bytes;
}

export function decodePixel160(bytes: Uint8Array): Pixel160 {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength !== 20) {
    throw new TypeError("Pixel160 is exactly 20 bytes");
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  return [0, 4, 8, 12, 16].map((offset) => view.getUint32(offset, false)) as Pixel160;
}

/** Full-state ABI: BE200(q||p), q in bits 199..100, p in bits 99..0. */
export function encodePhase200(state: PhaseState): Uint8Array {
  let word = phaseWord(state);
  const bytes = new Uint8Array(25);
  for (let index = 24; index >= 0; index--) {
    bytes[index] = Number(word & 255n);
    word >>= 8n;
  }
  return bytes;
}

export function decodePhase200(bytes: Uint8Array): PhaseState {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength !== 25) {
    throw new TypeError("A full Phase200 state is exactly 25 bytes");
  }
  const word = bytes.reduce((result, byte) => (result << 8n) | BigInt(byte), 0n);
  return { q: word >> 100n, p: word & FIELD_MAX };
}

export function pixelHex(lanes: Pixel160): string {
  return Array.from(encodePixel160(lanes), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
