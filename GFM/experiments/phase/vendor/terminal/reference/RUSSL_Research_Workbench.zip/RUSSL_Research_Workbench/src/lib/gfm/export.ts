import { encodePixel160, LANE_NAMES } from "./pixel.ts";
import type { Pixel160 } from "./pixel.ts";

const MAX_MANIFEST_BYTES = 1024 * 1024;
const MAX_ZIP_BYTES = 64 * 1024 * 1024;
const encoder = new TextEncoder();
const align4 = (value: number): number => Math.ceil(value / 4) * 4;

function asciiJson(manifest: unknown): Uint8Array {
  const json = JSON.stringify(manifest);
  if (typeof json !== "string") throw new TypeError("The TIFF manifest must be JSON serializable");
  // TIFF ASCII is 7-bit. Escaped UTF-16 code units preserve arbitrary JSON strings.
  const ascii = json.replace(
    /[^\x20-\x7e]/g,
    (character) => `\\u${character.charCodeAt(0).toString(16).padStart(4, "0")}`,
  );
  const bytes = encoder.encode(`${ascii}\0`);
  if (bytes.length > MAX_MANIFEST_BYTES) throw new RangeError("The TIFF manifest exceeds 1 MiB");
  return bytes;
}

function inlineAscii(bytes: Uint8Array): number {
  return bytes.reduce((value, byte, index) => value + byte * 2 ** (8 * index), 0);
}

/** Five uncompressed little-endian TIFF pages, one uint32 grayscale page per lane. */
export function encodeTiff(
  pixels: readonly Pixel160[],
  width: number,
  height: number,
  manifest: unknown,
): Uint8Array {
  if (
    !Number.isInteger(width) ||
    !Number.isInteger(height) ||
    width < 1 ||
    height < 1 ||
    width > 32 ||
    height > 32
  ) {
    throw new RangeError("TIFF width and height must be integers in [1, 32]");
  }
  if (!Array.isArray(pixels) || pixels.length !== width * height) {
    throw new RangeError("TIFF pixel count must equal width times height");
  }
  for (let index = 0; index < pixels.length; index++) encodePixel160(pixels[index]);
  const description = asciiJson(manifest);
  const ifdOffsets: number[] = [];
  let position = 8;
  for (let page = 0; page < 5; page++) {
    ifdOffsets.push(position);
    position += 2 + 12 * (page === 0 ? 15 : 14) + 4;
  }
  const descriptionOffset = position;
  const dataOffset = align4(descriptionOffset + description.length);
  const stripBytes = pixels.length * 4;
  const bytes = new Uint8Array(dataOffset + 5 * stripBytes);
  const view = new DataView(bytes.buffer);
  view.setUint16(0, 0x4949, true);
  view.setUint16(2, 42, true);
  view.setUint32(4, ifdOffsets[0], true);
  bytes.set(description, descriptionOffset);

  for (let page = 0; page < 5; page++) {
    const pageName = encoder.encode(`${LANE_NAMES[page]}\0`);
    const tags: [number, number, number, number][] = [
      [254, 4, 1, 2], // NewSubfileType: a page of a multipage image.
      [256, 4, 1, width],
      [257, 4, 1, height],
      [258, 3, 1, 32],
      [259, 3, 1, 1], // Uncompressed.
      [262, 3, 1, 1], // BlackIsZero grayscale.
      ...(page === 0
        ? [
            [
              270,
              2,
              description.length,
              description.length <= 4 ? inlineAscii(description) : descriptionOffset,
            ] as [number, number, number, number],
          ]
        : []),
      [273, 4, 1, dataOffset + page * stripBytes],
      [277, 3, 1, 1],
      [278, 4, 1, height],
      [279, 4, 1, stripBytes],
      [284, 3, 1, 1],
      [285, 2, pageName.length, inlineAscii(pageName)],
      [297, 3, 2, page + (5 << 16)],
      [339, 3, 1, 1], // SampleFormat: unsigned integer, including the high bit.
    ];
    const offset = ifdOffsets[page];
    view.setUint16(offset, tags.length, true);
    tags.forEach(([tag, type, count, value], index) => {
      const entry = offset + 2 + index * 12;
      view.setUint16(entry, tag, true);
      view.setUint16(entry + 2, type, true);
      view.setUint32(entry + 4, count, true);
      view.setUint32(entry + 8, value, true);
    });
    view.setUint32(offset + 2 + tags.length * 12, ifdOffsets[page + 1] ?? 0, true);
    pixels.forEach((pixel, index) =>
      view.setUint32(dataOffset + page * stripBytes + index * 4, pixel[page], true),
    );
  }
  return bytes;
}

const crcTable = Uint32Array.from({ length: 256 }, (_, value) => {
  let crc = value;
  for (let bit = 0; bit < 8; bit++) crc = (crc & 1) !== 0 ? 0xedb88320 ^ (crc >>> 1) : crc >>> 1;
  return crc >>> 0;
});
function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

/** Browser-portable stored ZIP, UTF-8 filenames, CRC32, deterministic 1980-01-01 date. */
export function encodeZip(files: readonly { name: string; bytes: Uint8Array }[]): Uint8Array {
  if (!Array.isArray(files) || files.length > 0xffff)
    throw new RangeError("Stored ZIP supports at most 65535 files");
  const names = new Set<string>();
  let budget = 22;
  const entries = files.map((file) => {
    if (
      !file ||
      typeof file.name !== "string" ||
      !file.name ||
      file.name.includes("\\") ||
      file.name.includes("\0") ||
      file.name.includes(":") ||
      file.name.startsWith("/") ||
      file.name.endsWith("/") ||
      file.name.split("/").some((part: string) => !part || part === "." || part === "..")
    ) {
      throw new TypeError("ZIP filenames must be safe relative file paths");
    }
    if (names.has(file.name)) throw new TypeError("ZIP filenames must be unique");
    names.add(file.name);
    const name = encoder.encode(file.name);
    if (name.length > 0xffff) throw new RangeError("ZIP filename is too long");
    if (!(file.bytes instanceof Uint8Array))
      throw new TypeError("ZIP file bytes must be Uint8Array");
    if (file.bytes.length > MAX_ZIP_BYTES)
      throw new RangeError("ZIP payload exceeds the 64 MiB browser export limit");
    budget += 76 + 2 * name.length + file.bytes.length;
    if (budget > MAX_ZIP_BYTES) throw new RangeError("ZIP exceeds the 64 MiB browser export limit");
    return { name, bytes: file.bytes, crc: crc32(file.bytes), offset: 0 };
  });
  const localSize = entries.reduce(
    (sum, entry) => sum + 30 + entry.name.length + entry.bytes.length,
    0,
  );
  const centralSize = entries.reduce((sum, entry) => sum + 46 + entry.name.length, 0);
  const totalSize = localSize + centralSize + 22;
  if (totalSize > MAX_ZIP_BYTES)
    throw new RangeError("ZIP exceeds the 64 MiB browser export limit");
  const bytes = new Uint8Array(totalSize);
  const view = new DataView(bytes.buffer);
  let cursor = 0;
  for (const entry of entries) {
    entry.offset = cursor;
    view.setUint32(cursor, 0x04034b50, true);
    view.setUint16(cursor + 4, 20, true);
    view.setUint16(cursor + 6, 0x0800, true); // UTF-8 filenames.
    view.setUint16(cursor + 8, 0, true); // Stored.
    view.setUint16(cursor + 10, 0, true);
    view.setUint16(cursor + 12, 33, true);
    view.setUint32(cursor + 14, entry.crc, true);
    view.setUint32(cursor + 18, entry.bytes.length, true);
    view.setUint32(cursor + 22, entry.bytes.length, true);
    view.setUint16(cursor + 26, entry.name.length, true);
    view.setUint16(cursor + 28, 0, true);
    bytes.set(entry.name, cursor + 30);
    bytes.set(entry.bytes, cursor + 30 + entry.name.length);
    cursor += 30 + entry.name.length + entry.bytes.length;
  }
  const centralOffset = cursor;
  for (const entry of entries) {
    view.setUint32(cursor, 0x02014b50, true);
    view.setUint16(cursor + 4, 20, true);
    view.setUint16(cursor + 6, 20, true);
    view.setUint16(cursor + 8, 0x0800, true);
    view.setUint16(cursor + 10, 0, true);
    view.setUint16(cursor + 12, 0, true);
    view.setUint16(cursor + 14, 33, true);
    view.setUint32(cursor + 16, entry.crc, true);
    view.setUint32(cursor + 20, entry.bytes.length, true);
    view.setUint32(cursor + 24, entry.bytes.length, true);
    view.setUint16(cursor + 28, entry.name.length, true);
    view.setUint16(cursor + 30, 0, true);
    view.setUint16(cursor + 32, 0, true);
    view.setUint16(cursor + 34, 0, true);
    view.setUint16(cursor + 36, 0, true);
    view.setUint32(cursor + 38, 0, true);
    view.setUint32(cursor + 42, entry.offset, true);
    bytes.set(entry.name, cursor + 46);
    cursor += 46 + entry.name.length;
  }
  view.setUint32(cursor, 0x06054b50, true);
  view.setUint16(cursor + 4, 0, true);
  view.setUint16(cursor + 6, 0, true);
  view.setUint16(cursor + 8, entries.length, true);
  view.setUint16(cursor + 10, entries.length, true);
  view.setUint32(cursor + 12, centralSize, true);
  view.setUint32(cursor + 16, centralOffset, true);
  view.setUint16(cursor + 20, 0, true);
  return bytes;
}
