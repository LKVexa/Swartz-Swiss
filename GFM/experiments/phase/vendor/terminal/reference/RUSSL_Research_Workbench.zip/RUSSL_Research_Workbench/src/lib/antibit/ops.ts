import { exactTransform, type ExactTransform } from "./ntt.ts";

export const ACCEPT = {
  phase: 1e-9,
  unit: 1e-9,
  recovery: 1e-8,
  displayFloor: 1e-12,
} as const;

export const PROTOCOL = {
  id: "AWB-1",
  revision: "2.9",
  bins: 32,
  field: "U_t = sin(2π t/N) + 0.3 cos(4π t/N) + i 0.5 sin(6π t/N + 0.4)",
  role: "r_k ≡ x + 17k + 3 (mod 2^n)",
  dft: "radix-2 DFT; inverse scaled by 1/N",
  bind: "Ĥ_k = Û_k E_n(r_k),   Ũ̂_k = Ĥ_k E_n(A_n(r_k))",
  partner: "F(x) = 3x + 5,   F^A(a) = 3a − 5",
  lift: "x_16 = x_8 + 0xAB·2^8,   x_32 = x_16 + 0xC3D4·2^16",
  fault: "ã_3 = A_n(r_3) XOR 2^b",
  quadrature: "U_0 = 0.6 + 0.2i,   R = 0.8 + 0.3i,   U_1 = −U_0",
  encode: "E_n(x) = exp(2πi x / 2^n)",
} as const;

export type Cx = { re: number; im: number };

export type Width = 8 | 16 | 32;

export type BenchConfig = {
  width: Width;
  word: bigint;
  bins: number;
  faultOn: boolean;
  faultBin: number;
  faultBit: number;
  secondFault?: boolean;
};

export type Check = { name: string; hold: boolean; detail: string };

export type Frame = {
  id: string;
  title: string;
  lines: { k: string; v: string }[];
};

export type BenchReport = {
  width: Width;
  modulus: string;
  word: string;
  complement: string;
  anti: string;
  sumComplement: string;
  sumAnti: string;
  oneBitArithmeticCollapses: boolean;
  checks: Check[];
  phaseMax: number;
  unitMax: number;
  complementPhaseMax: number;
  oppositePhaseMax: number;
  fftRoundtrip: number;
  recovery: { rms: number; max: number };
  cleanRecovery: { rms: number; max: number };
  faultSyndrome: string;
  roles: { k: number; role: string; anti: string; phaseErr: number }[];
  fieldRe: number[];
  recoveredRe: number[];
  correctedRe: number[];
  paired: { step: number; x: string; a: string; sum: string }[];
  ladder: { width: number; value: string; low8: string; agrees: boolean }[];
  interference: { intensityMatch: boolean; quadErr: number };
  frames: Frame[];
  phaseScope: { exhaustive: boolean; samples: number };
  registers: { name: string; dec: string; hex: string; bits: string }[];
  fault: { bin: number; bit: number; role: string; anti: string; observed: string; syndrome: string };
  decode: {
    status: "clean" | "corrected" | "uncorrectable";
    bit: string;
    correctedMax: number;
  };
  decode2: {
    status: "clean" | "corrected" | "uncorrectable" | "ambiguous";
    bits: string;
    correctedMax: number;
  };
  complementMax: number;
  byte: { samples: number; worst: number };
  exact: ExactTransform;
  superposition: { linearMax: number; crossMax: number };
};

const TAU = Math.PI * 2;

function stable(x: number): string {
  if (!Number.isFinite(x) || Math.abs(x) < 1e-12) return "< 1e-12";
  return x.toExponential(2);
}

export function modPow2(x: bigint, n: number): bigint {
  const m = 1n << BigInt(n);
  const r = x % m;
  return r < 0n ? r + m : r;
}

export function complement(x: bigint, n: number): bigint {
  const masked = modPow2(x, n);
  return (1n << BigInt(n)) - 1n - masked;
}

export function anti(x: bigint, n: number): bigint {
  return modPow2(-modPow2(x, n), n);
}

export function mul(a: Cx, b: Cx): Cx {
  return { re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re };
}

export function conj(a: Cx): Cx {
  return { re: a.re, im: -a.im };
}

export function neg(a: Cx): Cx {
  return { re: -a.re, im: -a.im };
}

export function encode(x: bigint, n: number): Cx {
  const turn = Number(modPow2(x, n)) / 2 ** n;
  const ang = TAU * turn;
  return { re: Math.cos(ang), im: Math.sin(ang) };
}

function dist(a: Cx, b: Cx): number {
  return Math.hypot(a.re - b.re, a.im - b.im);
}

export function fft(input: Cx[], inverse = false): Cx[] {
  const n = input.length;
  if (n < 2 || (n & (n - 1)) !== 0) {
    throw new Error("fft length must be a power of two");
  }
  const out = input.map((c) => ({ re: c.re, im: c.im }));
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      const tmp = out[i];
      out[i] = out[j];
      out[j] = tmp;
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = ((inverse ? 2 : -2) * Math.PI) / len;
    const wlen = { re: Math.cos(ang), im: Math.sin(ang) };
    for (let i = 0; i < n; i += len) {
      let w = { re: 1, im: 0 };
      for (let j = 0; j < len / 2; j++) {
        const u = out[i + j];
        const v = mul(out[i + j + len / 2], w);
        out[i + j] = { re: u.re + v.re, im: u.im + v.im };
        out[i + j + len / 2] = { re: u.re - v.re, im: u.im - v.im };
        w = mul(w, wlen);
      }
    }
  }
  if (inverse) {
    for (const c of out) {
      c.re /= n;
      c.im /= n;
    }
  }
  return out;
}

export function makeField(bins: number): Cx[] {
  const out: Cx[] = [];
  for (let t = 0; t < bins; t++) {
    const re = Math.sin(TAU * (t / bins)) + 0.3 * Math.cos(TAU * (2 * t) / bins);
    const im = 0.5 * Math.sin(TAU * (3 * t) / bins + 0.4);
    out.push({ re, im });
  }
  return out;
}

export function roleSpectrum(word: bigint, n: number, bins: number): bigint[] {
  const roles: bigint[] = [];
  for (let k = 0; k < bins; k++) {
    roles.push(modPow2(word + BigInt(k) * 17n + 3n, n));
  }
  return roles;
}

export function fieldError(a: Cx[], b: Cx[]): { rms: number; max: number } {
  let sum = 0;
  let max = 0;
  for (let i = 0; i < a.length; i++) {
    const d = dist(a[i], b[i]);
    sum += d * d;
    if (d > max) max = d;
  }
  return { rms: Math.sqrt(sum / a.length), max };
}

function phaseSweepMax(width: number, word: bigint): {
  anti: number;
  unit: number;
  complement: number;
  opposite: number;
  samples: number;
  exhaustive: boolean;
} {
  const exhaustive = width <= 16;
  const seen = new Set<number>();
  let antiMax = 0;
  let unitMax = 0;
  let compMax = 0;
  let oppMax = 0;
  const consider = (sample: number) => {
    if (seen.has(sample)) return;
    seen.add(sample);
    const x = BigInt(sample);
    const e = encode(x, width);
    const viaAnti = encode(anti(x, width), width);
    const viaConj = conj(e);
    antiMax = Math.max(antiMax, dist(viaAnti, viaConj));
    unitMax = Math.max(unitMax, Math.abs(Math.hypot(e.re, e.im) - 1));
    const twist = conj(encode(1n, width));
    compMax = Math.max(compMax, dist(encode(complement(x, width), width), mul(twist, viaConj)));
    const half = x + (1n << BigInt(width - 1));
    oppMax = Math.max(oppMax, dist(encode(half, width), neg(e)));
  };
  if (exhaustive) {
    const m = 2 ** width;
    for (let i = 0; i < m; i++) consider(i);
  } else {
    for (let i = 0; i < 2048; i++) consider(i);
    consider(Number(modPow2(word, width)));
    const stride = 2 ** (width - 10);
    for (let i = 0; i < 1024; i++) consider(i * stride);
  }
  return { anti: antiMax, unit: unitMax, complement: compMax, opposite: oppMax, samples: seen.size, exhaustive };
}

function pairedTrace(word: bigint, width: number) {
  const rows: { step: number; x: string; a: string; sum: string }[] = [];
  let x = modPow2(word, width);
  let a = anti(x, width);
  for (let step = 0; step <= 3; step++) {
    rows.push({
      step,
      x: x.toString(),
      a: a.toString(),
      sum: modPow2(x + a, width).toString(),
    });
    x = modPow2(3n * x + 5n, width);
    a = modPow2(3n * a - 5n, width);
  }
  return rows;
}

function liftLadder(word: bigint) {
  const low = modPow2(word, 8);
  const w16 = low + 0xabn * (1n << 8n);
  const w32 = w16 + 0xc3d4n * (1n << 16n);
  return [
    { width: 8, value: low, agrees: true },
    { width: 16, value: w16, agrees: modPow2(w16, 8) === low },
    { width: 32, value: w32, agrees: modPow2(w32, 8) === low && modPow2(w32, 16) === w16 },
  ].map((rung) => ({
    width: rung.width,
    value: rung.value.toString(),
    low8: modPow2(rung.value, 8).toString(),
    agrees: rung.agrees,
  }));
}

function interference(): { intensityMatch: boolean; quadErr: number } {
  const u0: Cx = { re: 0.6, im: 0.2 };
  const ub = neg(u0);
  const ref: Cx = { re: 0.8, im: 0.3 };
  const intensity = (z: Cx) => z.re * z.re + z.im * z.im;
  const quad = (u: Cx) => {
    const plus = { re: ref.re + u.re, im: ref.im + u.im };
    const minus = { re: ref.re - u.re, im: ref.im - u.im };
    const left = intensity(plus) - intensity(minus);
    const right = 4 * (ref.re * u.re + ref.im * u.im);
    return Math.abs(left - right);
  };
  return {
    intensityMatch: Math.abs(intensity(u0) - intensity(ub)) < 1e-15,
    quadErr: Math.max(quad(u0), quad(ub)),
  };
}

export function decodeRadius1(role: bigint, observed: bigint, n: number): {
  status: "clean" | "corrected" | "uncorrectable";
  bit: number | null;
  value: bigint;
} {
  const seen = modPow2(observed, n);
  if (modPow2(role + seen, n) === 0n) return { status: "clean", bit: null, value: seen };
  const hits: number[] = [];
  for (let bit = 0; bit < n; bit++) {
    const candidate = seen ^ (1n << BigInt(bit));
    if (modPow2(role + candidate, n) === 0n) hits.push(bit);
  }
  if (hits.length === 1) {
    return { status: "corrected", bit: hits[0], value: seen ^ (1n << BigInt(hits[0])) };
  }
  return { status: "uncorrectable", bit: null, value: seen };
}

export function decodeRadius2(
  role: bigint,
  observed: bigint,
  n: number,
): { status: "clean" | "corrected" | "uncorrectable" | "ambiguous"; bits: number[]; value: bigint } {
  const target = anti(role, n);
  const seen = modPow2(observed, n);
  if (seen === target) return { status: "clean", bits: [], value: seen };
  const hits: number[][] = [];
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const candidate = seen ^ (1n << BigInt(i)) ^ (1n << BigInt(j));
      if (candidate === target) hits.push([i, j]);
    }
  }
  if (hits.length === 1) {
    const [i, j] = hits[0];
    return { status: "corrected", bits: [i, j], value: seen ^ (1n << BigInt(i)) ^ (1n << BigInt(j)) };
  }
  if (hits.length > 1) return { status: "ambiguous", bits: hits[0], value: seen };
  return { status: "uncorrectable", bits: [], value: seen };
}

function bindUnbind(field: Cx[], roles: bigint[], antis: bigint[], width: number): Cx[] {
  const spectrum = fft(field, false);
  const bound = spectrum.map((bin, k) => mul(bin, encode(roles[k], width)));
  const restored = bound.map((bin, k) => mul(bin, encode(antis[k], width)));
  return fft(restored, true);
}

let cachedByteWorst: number | null = null;

export function byteCertificate(): { samples: number; worst: number } {
  if (cachedByteWorst === null) {
    const field = makeField(32);
    let worst = 0;
    for (let residue = 0; residue < 256; residue++) {
      const roles = roleSpectrum(BigInt(residue), 8, 32);
      const antis = roles.map((role) => anti(role, 8));
      worst = Math.max(worst, fieldError(field, bindUnbind(field, roles, antis, 8)).max);
    }
    cachedByteWorst = worst;
  }
  return { samples: 256, worst: cachedByteWorst };
}

function antiReduces(word: bigint, width: number): boolean {
  const value = modPow2(word, width);
  const wide = anti(value, 32);
  return modPow2(wide, 8) === anti(modPow2(value, 8), 8) && modPow2(wide, 16) === anti(modPow2(value, 16), 16);
}

function makeAltField(bins: number): Cx[] {
  const out: Cx[] = [];
  for (let t = 0; t < bins; t++) {
    out.push({
      re: Math.cos(TAU * (t / bins)),
      im: 0.25 * Math.sin(TAU * (5 * t) / bins),
    });
  }
  return out;
}

function twoRecords(word: bigint, width: number, bins: number): { linearMax: number; crossMax: number } {
  const field = makeField(bins);
  const other = makeAltField(bins);
  const roles = roleSpectrum(word, width, bins);
  const antis = roles.map((role) => anti(role, width));
  const otherRoles = roleSpectrum(modPow2(word + 1n, width), width, bins);
  const boundU = fft(field, false).map((bin, k) => mul(bin, encode(roles[k], width)));
  const boundV = fft(other, false).map((bin, k) => mul(bin, encode(otherRoles[k], width)));
  const mixed = boundU.map((bin, index) => ({ re: bin.re + boundV[index].re, im: bin.im + boundV[index].im }));
  const returned = fft(
    mixed.map((bin, k) => mul(bin, encode(antis[k], width))),
    true,
  );
  const leak = fft(
    boundV.map((bin, k) => mul(bin, encode(antis[k], width))),
    true,
  );
  const summed = field.map((bin, index) => ({ re: bin.re + leak[index].re, im: bin.im + leak[index].im }));
  return { linearMax: fieldError(returned, summed).max, crossMax: fieldError(returned, field).max };
}

export function runBench(config: BenchConfig): BenchReport {
  const { width, bins } = config;
  const word = modPow2(config.word, width);
  const comp = complement(word, width);
  const partner = anti(word, width);
  const field = makeField(bins);
  const roles = roleSpectrum(word, width, bins);
  const antis = roles.map((role) => anti(role, width));
  const clean = bindUnbind(field, roles, antis, width);
  const cleanRecovery = fieldError(field, clean);

  const faulted = antis.slice();
  const bit = Math.max(0, Math.min(width - 1, config.faultBit));
  const bin = ((config.faultBin % bins) + bins) % bins;
  if (config.faultOn) {
    faulted[bin] = faulted[bin] ^ (1n << BigInt(bit));
    if (config.secondFault) {
      const other = (bit + 1) % width;
      faulted[bin] = faulted[bin] ^ (1n << BigInt(other));
    }
  }
  const recovered = bindUnbind(field, roles, faulted, width);
  const recovery = fieldError(field, recovered);
  const syndrome = modPow2(roles[bin] + faulted[bin], width);
  const decoded = decodeRadius1(roles[bin], faulted[bin], width);
  const decoded2 = decodeRadius2(roles[bin], faulted[bin], width);
  const radius1Antis = faulted.slice();
  radius1Antis[bin] = decoded.value;
  const radius1Recovery = fieldError(field, bindUnbind(field, roles, radius1Antis, width));
  const radius2Antis = faulted.slice();
  radius2Antis[bin] = decoded2.value;
  const radius2Recovery = fieldError(field, bindUnbind(field, roles, radius2Antis, width));
  const usePair = decoded.status === "uncorrectable" && decoded2.status === "corrected";
  const corrected = bindUnbind(field, roles, usePair ? radius2Antis : radius1Antis, width);
  const correctedRecovery = usePair ? radius2Recovery : radius1Recovery;
  const complements = roles.map((role) => complement(role, width));
  const viaComplement = bindUnbind(field, roles, complements, width);
  const complementRecovery = fieldError(field, viaComplement);
  const twist = encode((1n << BigInt(width)) - 1n, width);
  const twistFit = fieldError(
    field.map((bin) => mul(bin, twist)),
    viaComplement,
  ).max;
  const complementSeparates = width < 32 && complementRecovery.max > ACCEPT.recovery;
  const byte = byteCertificate();
  const exact = exactTransform(roles);
  const records = twoRecords(word, width, bins);
  const notInverse = modPow2(3n * (3n * word - 5n) + 5n, width) !== word;
  const decoderHolds = config.faultOn
    ? config.secondFault
      ? decoded.status === "uncorrectable" && decoded2.status === "corrected" && radius2Recovery.max < ACCEPT.recovery
      : decoded.status === "corrected" && radius1Recovery.max < ACCEPT.recovery
    : decoded.status === "clean" && radius1Recovery.max < ACCEPT.recovery;

  const phases = phaseSweepMax(width, word);
  const roundtrip = fieldError(field, fft(fft(field, false), true)).max;
  const oneBit = anti(0n, 1) === 0n && anti(1n, 1) === 1n && complement(1n, 1) === 0n;
  const paired = pairedTrace(word, width);
  const quad = interference();

  const checks: Check[] = [
    {
      name: "Complement plus one is arithmetic negation",
      hold: modPow2(comp + 1n, width) === partner,
      detail: `${comp} + 1 ≡ ${partner} (mod 2^${width})`,
    },
    {
      name: "Arithmetic pair cancels",
      hold: modPow2(word + partner, width) === 0n,
      detail: `${word} + ${partner} ≡ 0 (mod 2^${width})`,
    },
    {
      name: "Complement pair sums to the mask",
      hold: word + comp === (1n << BigInt(width)) - 1n,
      detail: `${word} + ${comp} = ${((1n << BigInt(width)) - 1n).toString()}`,
    },
    {
      name: "Two involutions count forward",
      hold: anti(complement(word, width), width) === modPow2(word + 1n, width),
      detail: `A(C(x)) = ${modPow2(word + 1n, width).toString()}`,
    },
    {
      name: "Two involutions count backward",
      hold: complement(anti(word, width), width) === modPow2(word - 1n, width),
      detail: `C(A(x)) = ${modPow2(word - 1n, width).toString()}`,
    },
    {
      name: "One-bit negation collapses; complement does not",
      hold: oneBit,
      detail: "On one bit, −b = b. The distinct partner is 1 − b.",
    },
    {
      name: "Anti-role matches conjugation",
      hold: phases.anti < ACCEPT.phase && phases.unit < ACCEPT.unit,
      detail: phases.exhaustive
        ? `‖E_n∘A_n − conj∘E_n‖_∞ = ${stable(phases.anti)} on all ${phases.samples} residues`
        : `sampled ‖E_n∘A_n − conj∘E_n‖_∞ = ${stable(phases.anti)} on ${phases.samples} residues; not ∀x`,
    },
    {
      name: "Complement is conjugation times a one-step twist",
      hold: phases.complement < ACCEPT.phase && phases.opposite < ACCEPT.phase,
      detail: `‖E_n∘C_n − e^{−2πi/M} conj∘E_n‖_∞ = ${stable(phases.complement)}; half-turn ${stable(phases.opposite)}`,
    },
    {
      name: "Clean unbinding recovers the field",
      hold: cleanRecovery.max < ACCEPT.recovery,
      detail: `‖Ũ − U‖_∞ = ${stable(cleanRecovery.max)}; criterion < ${ACCEPT.recovery.toExponential(0)}`,
    },
    {
      name: "Affine partner intertwines with the anti-word",
      hold: paired.every((row) => row.sum === "0") && notInverse,
      detail: "A(F(x)) = F^A(A(x)) at each step. F^A does not undo F.",
    },
    {
      name: "Quadrature matches the reference identity",
      hold: quad.intensityMatch && quad.quadErr < 1e-9,
      detail: `‖U‖ = ‖−U‖; quad residual ${stable(quad.quadErr)}`,
    },
    {
      name: "Complement unbind is the one-step twist, not the anti-word",
      hold: twistFit < ACCEPT.recovery && (width === 32 || complementSeparates),
      detail:
        width === 32
          ? `the twist is below the float criterion at this width; fit ${stable(twistFit)}`
          : `misses by ${stable(complementRecovery.max)}; twist fit ${stable(twistFit)}`,
    },
    {
      name: "Decoder matches the armed fault",
      hold: decoderHolds,
      detail: config.secondFault
        ? `radius 2 bits ${decoded2.bits.join(",")}; ∞ ${stable(radius2Recovery.max)}`
        : `radius 1 ${decoded.status}; ∞ ${stable(radius1Recovery.max)}`,
    },
    {
      name: "Anti-word commutes with reduction",
      hold: antiReduces(word, width),
      detail: "A_32(x) mod 2^8 = A_8(x mod 2^8), and the same at 16",
    },
    {
      name: "Every eight-bit residue unbinds",
      hold: byte.worst < ACCEPT.recovery,
      detail: `worst ‖Ũ − U‖_∞ = ${stable(byte.worst)} over ${byte.samples} residues`,
    },
    {
      name: "Prime-field transform is exact",
      hold: exact.holds,
      detail: `NTT mod ${exact.prime}, length ${exact.length}, root ${exact.root}`,
    },
    {
      name: "Two bound records add, and one anti-role does not separate them",
      hold: records.linearMax < ACCEPT.recovery && records.crossMax > 1e-3,
      detail: `linearity ${stable(records.linearMax)}; cross ${stable(records.crossMax)}`,
    },
  ];

  const preview = roles.slice(0, 8).map((role, k) => ({
    k,
    role: role.toString(),
    anti: antis[k].toString(),
    phaseErr: dist(encode(antis[k], width), conj(encode(role, width))),
  }));

  const ladder = liftLadder(word);

  const frames: Frame[] = [
    {
      id: "declare",
      title: "Declare the word",
      lines: [
        { k: "width", v: String(width) },
        { k: "x", v: word.toString() },
        { k: "relation", v: "arithmetic anti-word" },
      ],
    },
    {
      id: "complement",
      title: "Logical complement",
      lines: [
        { k: "C(x)", v: comp.toString() },
        { k: "x + C(x)", v: (word + comp).toString() },
      ],
    },
    {
      id: "anti",
      title: "Arithmetic anti-word",
      lines: [
        { k: "A(x)", v: partner.toString() },
        { k: "x + A(x)", v: modPow2(word + partner, width).toString() },
        { k: "A − C", v: "1, the carry" },
      ],
    },
    {
      id: "phase",
      title: "Phase encoding",
      lines: [
        { k: "E(A) − E*", v: stable(phases.anti) },
        { k: "E(C) offset", v: stable(phases.complement) },
        { k: "half-turn", v: stable(phases.opposite) },
      ],
    },
    {
      id: "bind",
      title: config.faultOn ? "Unbind with a corrupted anti-role" : "Bind and unbind",
      lines: [
        { k: "bins", v: String(bins) },
        { k: "recovery rms", v: stable(recovery.rms) },
        { k: "recovery max", v: stable(recovery.max) },
        { k: "syndrome at bin", v: syndrome.toString() },
      ],
    },
    {
      id: "pair",
      title: "Partner follows the anti-process",
      lines: paired.map((row) => ({
        k: `step ${row.step}`,
        v: `${row.x} + ${row.a} ≡ ${row.sum}`,
      })),
    },
  ];

  return {
    width,
    modulus: (1n << BigInt(width)).toString(),
    word: word.toString(),
    complement: comp.toString(),
    anti: partner.toString(),
    sumComplement: (word + comp).toString(),
    sumAnti: modPow2(word + partner, width).toString(),
    oneBitArithmeticCollapses: oneBit,
    checks,
    phaseMax: phases.anti,
    unitMax: phases.unit,
    complementPhaseMax: phases.complement,
    oppositePhaseMax: phases.opposite,
    fftRoundtrip: roundtrip,
    recovery,
    cleanRecovery,
    faultSyndrome: syndrome.toString(),
    roles: preview,
    fieldRe: field.map((c) => c.re),
    recoveredRe: recovered.map((c) => c.re),
    correctedRe: corrected.map((c) => c.re),
    paired,
    ladder,
    interference: quad,
    frames,
    phaseScope: { exhaustive: phases.exhaustive, samples: phases.samples },
    registers: [
      register("x", word, width),
      register("C_n(x)", comp, width),
      register("A_n(x)", partner, width),
    ],
    fault: {
      bin,
      bit,
      role: roles[bin].toString(),
      anti: antis[bin].toString(),
      observed: faulted[bin].toString(),
      syndrome: syndrome.toString(),
    },
    decode: {
      status: decoded.status,
      bit: decoded.bit === null ? "" : String(decoded.bit),
      correctedMax: radius1Recovery.max,
    },
    decode2: {
      status: decoded2.status,
      bits: decoded2.bits.join(","),
      correctedMax: radius2Recovery.max,
    },
    complementMax: complementRecovery.max,
    byte,
    exact,
    superposition: records,
  };
}

export function witnessOf(report: BenchReport): Record<string, unknown> {
  return {
    id: PROTOCOL.id,
    revision: PROTOCOL.revision,
    width: report.width,
    word: report.word,
    anti: report.anti,
    checks: report.checks,
    cleanMax: report.cleanRecovery.max,
    complementMax: report.complementMax,
    byte: report.byte,
    exact: report.exact,
    superposition: report.superposition,
    decode: report.decode,
    decode2: report.decode2,
  };
}

function register(name: string, value: bigint, width: number) {
  const masked = modPow2(value, width);
  return {
    name,
    dec: masked.toString(),
    hex: masked.toString(16).toUpperCase().padStart(Math.ceil(width / 4), "0"),
    bits: masked.toString(2).padStart(width, "0"),
  };
}
