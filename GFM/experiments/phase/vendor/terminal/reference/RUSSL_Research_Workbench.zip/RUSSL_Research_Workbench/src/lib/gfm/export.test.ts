import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import test from "node:test";
import { encodeTiff, encodeZip } from "./export.ts";
import {
  decodePhase200,
  decodePixel160,
  decodeStatePixel160,
  encodePhase200,
  encodePixel160,
  encodeStatePixel160,
  pixelHex,
  projectPixel160,
} from "./pixel.ts";
import type { Pixel160 } from "./pixel.ts";
import { DEFAULT_CONFIG, sampleSlice } from "./penteract.ts";
import type { SliceConfig } from "./penteract.ts";

const MAX100 = (1n << 100n) - 1n;
const fixtures: Pixel160[] = [
  [0, 0xffffffff, 0x80000000, 0x12345678, 1],
  [0xffffffff, 0, 0x7fffffff, 2, 0x87654321],
  [0x80000000, 42, 0xffffffff, 0, 0xabcdef01],
  [17, 0x80000000, 9, 0xffffffff, 0],
];
const sha = (bytes: Uint8Array): string => createHash("sha256").update(bytes).digest("hex");

// These readers parse bytes from format fields; they do not call the export implementation.
type TiffTag = { type: number; count: number; entryOffset: number; value: number };
function parseTiff(bytes: Uint8Array) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  assert.equal(view.getUint16(0, true), 0x4949);
  assert.equal(view.getUint16(2, true), 42);
  const pages: { tags: Map<number, TiffTag>; samples: number[]; raw: Uint8Array }[] = [];
  const seen = new Set<number>();
  let offset = view.getUint32(4, true);
  while (offset !== 0) {
    assert(!seen.has(offset), "The IFD chain must be acyclic");
    seen.add(offset);
    assert.equal(offset % 2, 0);
    const count = view.getUint16(offset, true);
    assert(offset + 2 + count * 12 + 4 <= bytes.length);
    const tags = new Map<number, TiffTag>();
    let lastTag = -1;
    for (let index = 0; index < count; index++) {
      const entryOffset = offset + 2 + index * 12;
      const tag = view.getUint16(entryOffset, true);
      assert(tag > lastTag, "IFD tags must be unique and ascending");
      lastTag = tag;
      tags.set(tag, {
        type: view.getUint16(entryOffset + 2, true),
        count: view.getUint32(entryOffset + 4, true),
        entryOffset,
        value: view.getUint32(entryOffset + 8, true),
      });
    }
    const strip = tags.get(273)!,
      stripBytes = tags.get(279)!;
    assert.equal(strip.type, 4);
    assert.equal(strip.count, 1);
    assert(strip.value + stripBytes.value <= bytes.length);
    const raw = bytes.slice(strip.value, strip.value + stripBytes.value);
    const samples = Array.from({ length: stripBytes.value / 4 }, (_, index) =>
      view.getUint32(strip.value + index * 4, true),
    );
    pages.push({ tags, samples, raw });
    offset = view.getUint32(offset + 2 + count * 12, true);
  }
  function ascii(tag: TiffTag): string {
    assert.equal(tag.type, 2);
    const start = tag.count <= 4 ? tag.entryOffset + 8 : tag.value;
    assert(start + tag.count <= bytes.length);
    const textBytes = bytes.slice(start, start + tag.count);
    assert.equal(textBytes.at(-1), 0);
    assert(textBytes.every((byte) => byte < 128));
    return new TextDecoder("ascii").decode(textBytes.subarray(0, -1));
  }
  return { pages, ascii };
}

function independentCrc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) {
      const lowBit = crc & 1;
      crc >>>= 1;
      if (lowBit) crc ^= 0xedb88320;
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function parseZip(bytes: Uint8Array): Map<string, Uint8Array> {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const end = bytes.length - 22;
  assert.equal(view.getUint32(end, true), 0x06054b50);
  assert.equal(view.getUint16(end + 4, true), 0);
  assert.equal(view.getUint16(end + 6, true), 0);
  const count = view.getUint16(end + 10, true);
  assert.equal(view.getUint16(end + 8, true), count);
  assert.equal(view.getUint16(end + 20, true), 0);
  let central = view.getUint32(end + 16, true);
  assert.equal(central + view.getUint32(end + 12, true), end);
  const files = new Map<string, Uint8Array>();
  for (let index = 0; index < count; index++) {
    assert.equal(view.getUint32(central, true), 0x02014b50);
    assert.equal(view.getUint16(central + 8, true), 0x0800);
    assert.equal(view.getUint16(central + 10, true), 0);
    const nameLength = view.getUint16(central + 28, true);
    const extra = view.getUint16(central + 30, true),
      comment = view.getUint16(central + 32, true);
    assert.equal(extra, 0);
    assert.equal(comment, 0);
    const name = new TextDecoder().decode(bytes.slice(central + 46, central + 46 + nameLength));
    const local = view.getUint32(central + 42, true);
    assert.equal(view.getUint32(local, true), 0x04034b50);
    assert.equal(view.getUint16(local + 6, true), 0x0800);
    assert.equal(view.getUint16(local + 8, true), 0);
    assert.equal(view.getUint16(local + 26, true), nameLength);
    assert.equal(view.getUint16(local + 28, true), 0);
    assert.equal(new TextDecoder().decode(bytes.slice(local + 30, local + 30 + nameLength)), name);
    const size = view.getUint32(central + 24, true);
    assert.equal(view.getUint32(central + 20, true), size);
    assert.equal(view.getUint32(local + 18, true), size);
    assert.equal(view.getUint32(local + 22, true), size);
    const body = bytes.slice(local + 30 + nameLength, local + 30 + nameLength + size);
    assert.equal(body.length, size);
    assert.equal(view.getUint32(local + 14, true), view.getUint32(central + 16, true));
    assert.equal(independentCrc32(body), view.getUint32(central + 16, true));
    assert(!files.has(name));
    files.set(name, body);
    central += 46 + nameLength + extra + comment;
  }
  assert.equal(central, end);
  return files;
}

test("Pixel160 codecs preserve all unsigned lane bits and exact big-endian layout", () => {
  assert.equal(pixelHex(fixtures[0]), "00000000ffffffff800000001234567800000001");
  for (const lanes of fixtures) assert.deepEqual(decodePixel160(encodePixel160(lanes)), lanes);
  const wrapped = new Uint8Array(24);
  wrapped.set(encodePixel160(fixtures[0]), 2);
  assert.deepEqual(decodePixel160(wrapped.subarray(2, 22)), fixtures[0]);
  for (const invalid of [
    [-1, 0, 0, 0, 0],
    [0x100000000, 0, 0, 0, 0],
    [1.5, 0, 0, 0, 0],
    [NaN, 0, 0, 0, 0],
    new Array(5),
    [0, 0],
  ]) {
    assert.throws(() => encodePixel160(invalid as Pixel160));
  }
  assert.throws(() => decodePixel160(new Uint8Array(19)));
});

test("GF80 phase state occupies one exact Pixel160, including the middle-lane split", () => {
  const max80 = (1n << 80n) - 1n;
  const states = [
    { q: 0n, p: 0n },
    { q: max80, p: max80 },
    { q: max80, p: 0n },
    { q: 0n, p: max80 },
    { q: 1n << 79n, p: 1n << 79n },
    { q: 1n, p: 1n },
    { q: 0x0123456789abcdef0123n, p: 0xfedcba9876543210fedcn },
  ];
  for (const state of states) {
    const pixel = encodeStatePixel160(state);
    assert.deepEqual(decodeStatePixel160(pixel), state);
    const bytes = encodePixel160(pixel);
    assert.equal(bytes.length, 20);
    const word = Array.from(bytes).reduce((result, byte) => result * 256n + BigInt(byte), 0n);
    assert.equal(word, (state.q << 80n) | state.p);
    assert.deepEqual(decodeStatePixel160(decodePixel160(bytes)), state);
  }
  assert.deepEqual(
    encodeStatePixel160({ q: max80, p: 0n }),
    [0xffffffff, 0xffffffff, 0xffff0000, 0, 0],
  );
  assert.deepEqual(
    encodeStatePixel160({ q: 0n, p: max80 }),
    [0, 0, 0xffff, 0xffffffff, 0xffffffff],
  );
  assert.deepEqual(
    encodeStatePixel160({ q: 1n << 79n, p: 1n << 79n }),
    [0x80000000, 0, 0x8000, 0, 0],
  );
  assert.equal(pixelHex(encodeStatePixel160({ q: max80, p: max80 })), "f".repeat(40));
});

test("Full-state Pixel160 rejects GF80 overflow, inexact state values and malformed lane arrays", () => {
  for (const state of [
    { q: 1n << 80n, p: 0n },
    { q: 0n, p: 1n << 80n },
    { q: -1n, p: 0n },
    { q: 0n, p: -1n },
  ]) {
    assert.throws(() => encodeStatePixel160(state), /GF\(2\^80\)/);
  }
  assert.throws(() =>
    encodeStatePixel160({ q: 1, p: 0n } as unknown as Parameters<typeof encodeStatePixel160>[0]),
  );
  assert.throws(() =>
    encodeStatePixel160({ q: 0n } as unknown as Parameters<typeof encodeStatePixel160>[0]),
  );
  for (const pixel of [
    [0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0],
    new Array(5),
    [0, 0, 0, 0, -1],
    [0, 0, 0, 0, 0x100000000],
    [0, NaN, 0, 0, 0],
    [0, 0, 0.5, 0, 0],
  ]) {
    assert.throws(() => decodeStatePixel160(pixel as Pixel160));
  }
});

test("Phase200 is a lossless 25-byte state record; Pixel160 is a declared collision-prone projection", () => {
  const states = [
    { q: 0n, p: 0n },
    { q: MAX100, p: MAX100 },
    { q: 1n << 99n, p: 1n << 99n },
    { q: 0x123456789abcdefn, p: 0xdeadbeef00000000000000001n },
  ];
  for (const state of states) {
    const bytes = encodePhase200(state);
    assert.equal(bytes.length, 25);
    assert.deepEqual(decodePhase200(bytes), state);
    const independentlyParsed = Array.from(bytes).reduce(
      (word, byte) => word * 256n + BigInt(byte),
      0n,
    );
    assert.equal(independentlyParsed, (state.q << 100n) | state.p);
  }
  assert(encodePhase200({ q: MAX100, p: MAX100 }).every((byte) => byte === 255));
  const a = { q: 0n, p: 0n },
    b = { q: 1n << 60n, p: 0n };
  assert.deepEqual(projectPixel160(a), projectPixel160(b));
  assert.notDeepEqual(encodePhase200(a), encodePhase200(b));
  const projected = projectPixel160({ q: MAX100, p: MAX100 });
  assert(projected.every((lane) => lane === 0xffffffff));
  assert.throws(() => encodePhase200({ q: MAX100 + 1n, p: 0n }));
  assert.throws(() => projectPixel160({ q: 0n, p: -1n }));
  assert.throws(() => decodePhase200(new Uint8Array(20)));
});

test("Five-page TIFF has exact uint32 pages, named lanes, JSON description and matching payload hashes", () => {
  const manifest = {
    profile: "RUSSL/GFM",
    shape: [2, 2],
    label: "penteract π 🌌",
    integer: "1267650600228229401496703205376",
  };
  const bytes = encodeTiff(fixtures, 2, 2, manifest);
  const { pages, ascii } = parseTiff(bytes);
  assert.equal(pages.length, 5);
  for (let page = 0; page < 5; page++) {
    const { tags, samples, raw } = pages[page];
    for (const [tag, value] of [
      [254, 2],
      [256, 2],
      [257, 2],
      [258, 32],
      [259, 1],
      [262, 1],
      [277, 1],
      [278, 2],
      [279, 16],
      [284, 1],
      [339, 1],
    ]) {
      assert.equal(tags.get(tag)?.value, value);
    }
    assert.equal(tags.get(258)?.type, 3);
    assert.equal(tags.get(339)?.type, 3);
    assert.equal(tags.get(297)?.type, 3);
    assert.equal(tags.get(297)?.count, 2);
    assert.equal(tags.get(297)?.value, page + (5 << 16));
    assert.equal(ascii(tags.get(285)!), `L${4 + page}`);
    assert.deepEqual(
      samples,
      fixtures.map((pixel) => pixel[page]),
    );
    const expected = Buffer.alloc(16);
    fixtures.forEach((pixel, index) => expected.writeUInt32LE(pixel[page], index * 4));
    assert.equal(sha(raw), sha(expected));
    assert.equal(tags.has(270), page === 0);
  }
  assert.deepEqual(JSON.parse(ascii(pages[0].tags.get(270)!)), manifest);
});

test("Active GF80 slice TIFF reconstructs complete evolved states and the canonical replay payload", () => {
  const config: SliceConfig = {
    ...DEFAULT_CONFIG,
    words: ["3", "5", "2", "2", "2"],
    fixed: ["0", "0", "0", "0", "0"],
    axes: [0, 1],
    origin: ["1", "0"],
    size: 2,
    couplingAxis: 0,
    mode: "pair",
    tick: "7",
  };
  const slice = sampleSlice(config);
  assert.equal(slice.manifest.slice.observedSliceCells, 4);
  assert.equal(slice.manifest.slice.evaluatedCells, 6);
  assert.equal(slice.cells[0].partnerIndex, 0n);
  assert.equal(slice.cells[1].partnerIndex, null);
  const parsed = parseTiff(encodeTiff(slice.pixels, 2, 2, slice.manifest));
  const replayPayload = Buffer.alloc(slice.cells.length * 20);
  for (let index = 0; index < slice.cells.length; index++) {
    const pixel = parsed.pages.map((page) => page.samples[index]) as Pixel160;
    assert.deepEqual(decodeStatePixel160(pixel), slice.cells[index].state);
    pixel.forEach((lane, laneIndex) =>
      replayPayload.writeUInt32BE(lane, index * 20 + laneIndex * 4),
    );
  }
  assert.equal(sha(replayPayload), sha(slice.pixelBytes));
  assert.deepEqual(JSON.parse(parsed.ascii(parsed.pages[0].tags.get(270)!)), slice.manifest);
  const initial = sampleSlice({ ...config, tick: "0" });
  assert(
    slice.cells.some(
      (cell, index) =>
        cell.state.q !== initial.cells[index].state.q ||
        cell.state.p !== initial.cells[index].state.p,
    ),
  );
  assert.notEqual(sha(slice.pixelBytes), sha(initial.pixelBytes));
});

test("TIFF handles inline short JSON, shape bounds, sparse samples and non-serializable manifests", () => {
  for (const manifest of [0, true, null]) {
    const parsed = parseTiff(encodeTiff([fixtures[0]], 1, 1, manifest));
    assert.equal(JSON.parse(parsed.ascii(parsed.pages[0].tags.get(270)!)), manifest);
  }
  assert.equal(
    parseTiff(
      encodeTiff(
        Array.from({ length: 1024 }, () => fixtures[0]),
        32,
        32,
        {},
      ),
    ).pages.length,
    5,
  );
  for (const [width, height] of [
    [0, 1],
    [33, 1],
    [1, 33],
    [1.5, 1],
    [1, Infinity],
  ]) {
    assert.throws(() => encodeTiff(fixtures, width, height, {}));
  }
  assert.throws(() => encodeTiff(fixtures, 1, 1, {}));
  assert.throws(() => encodeTiff(new Array(4), 2, 2, {}));
  assert.throws(() => encodeTiff([fixtures[0]], 1, 1, undefined));
  assert.throws(() => encodeTiff([fixtures[0]], 1, 1, { integer: 1n }));
});

test("Stored ZIP matches independent CRC32 and central/local readers for TIFF, JSON and Phase200", () => {
  const vector = new TextEncoder().encode("123456789");
  assert.equal(independentCrc32(vector), 0xcbf43926);
  const manifest = { profile: "test", seed: "13" };
  const tiff = encodeTiff(fixtures, 2, 2, manifest);
  const phase = encodePhase200({ q: MAX100, p: 0n });
  const files = [
    { name: "slice.tiff", bytes: tiff },
    { name: "manifest.json", bytes: new TextEncoder().encode(JSON.stringify(manifest)) },
    { name: "phase200.bin", bytes: phase },
    { name: "π/CRC32.txt", bytes: vector },
  ];
  const archive = encodeZip(files);
  assert.deepEqual(encodeZip(files), archive, "Exports are deterministic for identical inputs");
  const readback = parseZip(archive);
  assert.deepEqual(
    Array.from(readback.keys()),
    files.map((file) => file.name),
  );
  for (const file of files) {
    assert.deepEqual(readback.get(file.name), file.bytes);
    assert.equal(sha(readback.get(file.name)!), sha(file.bytes));
  }
  assert.equal(parseTiff(readback.get("slice.tiff")!).pages.length, 5);
  assert.deepEqual(decodePhase200(readback.get("phase200.bin")!), { q: MAX100, p: 0n });
  assert.equal(parseZip(encodeZip([])).size, 0);
});

test("Stored ZIP rejects ambiguous names; changed fixture state changes the exported artifact", () => {
  const bytes = new Uint8Array([0, 255]);
  for (const name of [
    "",
    "../escape",
    "/absolute",
    "C:/absolute",
    "sub\\file",
    "a//b",
    "a/./b",
    "directory/",
    "null\0name",
  ]) {
    assert.throws(() => encodeZip([{ name, bytes }]));
  }
  assert.throws(() =>
    encodeZip([
      { name: "same", bytes },
      { name: "same", bytes },
    ]),
  );
  const before = encodeTiff(fixtures, 2, 2, { step: 0 });
  const afterPixels = fixtures.map((pixel) => [...pixel] as Pixel160);
  afterPixels[0][4] = 2;
  const after = encodeTiff(afterPixels, 2, 2, { step: 1 });
  assert.notEqual(sha(before), sha(after));
  assert.equal(parseTiff(after).pages[4].samples[0], 2);
  assert.notEqual(
    sha(encodeZip([{ name: "slice.tiff", bytes: before }])),
    sha(encodeZip([{ name: "slice.tiff", bytes: after }])),
  );
});
