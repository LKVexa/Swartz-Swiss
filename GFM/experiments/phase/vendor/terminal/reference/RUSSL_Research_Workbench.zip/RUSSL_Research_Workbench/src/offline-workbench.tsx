import { createRoot } from "react-dom/client";
import { ResearchWorkbench } from "@/components/research-workbench";
import "./styles.css";

const root = document.getElementById("workbench");
if (!root) throw new Error("The workbench mount is missing.");
createRoot(root).render(
  <main className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 sm:py-10">
    <header>
      <p className="font-mono text-xs tracking-wide text-muted uppercase">
        RUSSL · five independent words
      </p>
      <h1 className="mt-2 font-serif text-4xl leading-none font-medium text-ink sm:text-5xl">
        RUSSL word workbench
      </h1>
      <p className="mt-4 text-ink">
        Five ultra-wide words, reversible cells and virtual five-axis TIFF slices.
      </p>
    </header>
    <ResearchWorkbench />
  </main>,
);
