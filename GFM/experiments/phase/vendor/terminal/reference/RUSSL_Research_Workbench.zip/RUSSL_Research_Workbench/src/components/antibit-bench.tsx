import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  ACCEPT,
  PROTOCOL,
  anti,
  runBench,
  witnessOf,
  type BenchReport,
  type Frame,
  type Width,
} from "@/lib/antibit/ops";
import { isIdentity, matrixProduct, monomialMatrix, quantumProcedure } from "@/lib/antibit/weyl";
import { fieldOf, productTable } from "@/lib/antibit/galois";
import { aesSbox, eraseSymbol } from "@/lib/antibit/apply";
import { WAVE_REFERENCES, emitReleases, lambWave, releases } from "@/lib/antibit/lamb";
import { gpuAverageSigns } from "@/lib/antibit/lamb-gpu";
import { ResearchWorkbench } from "@/components/research-workbench";

const WIDTHS: Width[] = [8, 16, 32];

const OPERATORS = [
  ["b̄", "{0,1}", "1 − b"],
  ["C_n(x)", "ℤ/2ⁿℤ", "2ⁿ − 1 − x"],
  ["A_n(x)", "ℤ/2ⁿℤ", "(−x) mod 2ⁿ"],
  ["−U", "ℂ", "opposition, a factor of −1"],
  ["U*", "ℂ", "complex conjugation"],
] as const;

function sci(value: number): string {
  if (!Number.isFinite(value) || Math.abs(value) < ACCEPT.displayFloor) return "< 1e-12";
  const abs = Math.abs(value);
  if (abs >= 1e-3 && abs < 1e6) return value.toPrecision(4);
  return value.toExponential(2);
}

function parseWord(text: string): bigint | null {
  const trimmed = text.trim();
  if (!/^\d+$/.test(trimmed)) return null;
  try {
    return BigInt(trimmed);
  } catch {
    return null;
  }
}

export function AntibitBench() {
  const [width, setWidth] = useState<Width>(8);
  const [wordText, setWordText] = useState("13");
  const [faultOn, setFaultOn] = useState(false);
  const [faultBit, setFaultBit] = useState(0);
  const [secondFault, setSecondFault] = useState(false);
  const [restored, setRestored] = useState(false);
  const [frame, setFrame] = useState(0);

  const parsed = parseWord(wordText);
  const report = useMemo(
    () =>
      runBench({
        width,
        word: parsed ?? 0n,
        bins: PROTOCOL.bins,
        faultOn,
        faultBin: 3,
        faultBit,
        secondFault,
      }),
    [width, parsed, faultOn, faultBit, secondFault],
  );
  const failed = parsed !== null && report.checks.some((check) => !check.hold);
  const canRestore = report.decode.status === "corrected" || report.decode2.status === "corrected";
  const frameIndex = Math.min(frame, report.frames.length - 1);

  return (
    <main className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 sm:py-10">
      <header className="flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-xs tracking-wide text-muted uppercase">
            {PROTOCOL.id}
            <span className="px-2 text-muted">/</span>
            rev {PROTOCOL.revision}
          </p>
          <h1 className="mt-2 font-serif text-4xl leading-none font-medium text-ink sm:text-5xl">
            RUSSL word workbench
          </h1>
        </div>
        <Lamp armed={faultOn} failed={failed} />
      </header>
      <p className="mt-4 max-w-xl text-ink">
        Five ultra-wide words, reversible cells and virtual five-axis TIFF slices.
      </p>

      <ResearchWorkbench />
      <h2 className="mt-10 border-t border-rule pt-6 font-serif text-3xl">Anti-word deck</h2>

      {parsed === null ? (
        <p className="mt-6 border border-oxide px-3 py-3 font-mono text-sm text-oxide" role="alert">
          x must be an element of ℕ, written in decimal.
        </p>
      ) : (
        <section className="mt-6" aria-label="Live field">
          <div className="deck-well border border-rule p-3 sm:p-4">
            <div className="flex items-baseline justify-between font-mono text-xs text-muted">
              <span>Re U</span>
              <span>N = {PROTOCOL.bins}</span>
            </div>
            <div className="mt-2 grid items-center gap-2 sm:grid-cols-[1fr_6.5rem]">
              <FieldPlot
                original={report.fieldRe}
                recovered={restored && canRestore ? report.correctedRe : report.recoveredRe}
                faulted={faultOn && !(restored && canRestore)}
              />
              <PhaseRing word={report.word} anti={report.anti} modulus={report.modulus} />
            </div>
            <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 font-mono text-xs text-muted">
              <span className="text-signal">solid · original</span>
              <span className="text-oxide">dashed · returned</span>
              <span>ring · E(x), E(A)</span>
            </div>
            {faultOn ? (
              <div className="mt-2">
                <label className="flex min-h-11 items-center gap-3">
                  <span className="font-mono text-xs text-oxide">bit {faultBit}</span>
                  <input
                    type="range"
                    min={0}
                    max={width - 1}
                    value={faultBit}
                    aria-label="Fault bit"
                    className="w-full"
                    onChange={(event) => {
                      setFaultBit(Number(event.target.value));
                      setRestored(false);
                    }}
                  />
                </label>
                <div className="mt-1 flex gap-2">
                  <button
                    type="button"
                    className="min-h-11 flex-1 border border-signal font-mono text-sm text-signal disabled:border-rule disabled:text-muted"
                    disabled={!canRestore}
                    onClick={() => setRestored(true)}
                  >
                    {restored && canRestore ? "Restored" : "Restore"}
                  </button>
                  <button
                    type="button"
                    aria-pressed={secondFault}
                    className={
                      "min-h-11 flex-1 border font-mono text-sm " +
                      (secondFault ? "border-oxide text-oxide" : "border-rule text-ink")
                    }
                    onClick={() => {
                      setSecondFault((on) => !on);
                      setRestored(false);
                    }}
                  >
                    {secondFault ? "Two bits" : "Second bit"}
                  </button>
                </div>
                <p className="mt-2 font-mono text-xs text-muted">
                  {report.decode.status === "corrected"
                    ? `radius 1 found bit ${report.decode.bit}. Restored ∞ ${sci(report.decode.correctedMax)}.`
                    : report.decode2.status === "corrected"
                      ? `radius 1 refuses. Radius 2 found bits ${report.decode2.bits}. Restored ∞ ${sci(report.decode2.correctedMax)}.`
                      : report.decode.status === "uncorrectable"
                        ? "radius 2 refuses. The syndrome is not one bit or one pair."
                        : "syndrome 0. Nothing to restore."}
                </p>
              </div>
            ) : null}
          </div>

          <div className="mt-px grid grid-cols-3 gap-px border border-rule bg-rule">
            <Stat
              label="Predicates"
              value={`${report.checks.filter((check) => check.hold).length}/${report.checks.length}`}
              note="exact or in norm"
              tone={failed ? "oxide" : "signal"}
            />
            <Stat
              label="Clean ∞"
              value={sci(report.cleanRecovery.max)}
              note={`accept < ${ACCEPT.recovery.toExponential(0)}`}
              tone="ink"
            />
            <Stat
              label={faultOn ? "Faulted ∞" : "Live ∞"}
              value={sci(report.recovery.max)}
              note={faultOn ? `syndrome ${report.fault.syndrome}` : "fault disarmed"}
              tone={faultOn ? "oxide" : "ink"}
            />
          </div>
        </section>
      )}

      <section className="mt-4">
        <form
          className="grid gap-2 border border-rule bg-well p-2 sm:grid-cols-[auto_1fr_auto]"
          onSubmit={(event) => event.preventDefault()}
        >
          <fieldset className="flex">
            <legend className="sr-only">Width n</legend>
            {WIDTHS.map((choice) => (
              <button
                key={choice}
                type="button"
                aria-pressed={choice === width}
                className={
                  "min-h-11 min-w-12 border border-rule px-3 font-mono text-sm transition-colors " +
                  (choice === width
                    ? "border-signal bg-signal text-well"
                    : "bg-transparent text-ink hover:border-signal")
                }
                onClick={() => {
                  setWidth(choice);
                  setFaultBit((bit) => Math.min(bit, choice - 1));
                }}
              >
                {choice}
              </button>
            ))}
          </fieldset>
          <label className="flex min-h-11 items-center gap-3 border border-rule px-3">
            <span className="font-mono text-xs text-muted">x</span>
            <input
              inputMode="numeric"
              value={wordText}
              aria-label="Residue x"
              className="w-full bg-transparent font-mono text-lg text-ink caret-signal outline-none"
              onChange={(event) => setWordText(event.target.value)}
            />
          </label>
          <button
            type="button"
            aria-pressed={faultOn}
            className={
              "min-h-11 border px-4 font-mono text-sm transition-colors " +
              (faultOn
                ? "border-oxide bg-oxide text-well"
                : "border-rule text-ink hover:border-oxide hover:text-oxide")
            }
            onClick={() => {
              setFaultOn((on) => !on);
              setRestored(false);
              if (faultOn) setSecondFault(false);
            }}
          >
            {faultOn ? "Fault armed" : "Arm fault"}
          </button>
        </form>
      </section>

      {parsed !== null ? (
        <>
          <WeylPanel word={BigInt(report.word)} width={width} />
          <GaloisPanel word={BigInt(report.word)} width={width} />
          <ApplyPanel word={BigInt(report.word)} width={width} />
          <WitnessPanel report={report} />
          <LambPanel word={BigInt(report.word)} width={width} />
        </>
      ) : null}

      {parsed !== null ? (
        <>
          <ul className="mt-6 divide-y divide-rule border-y border-rule">
            <Spec k="modulus" v={`2^${width} = ${report.modulus}`} />
            <Spec k="encoding" v={PROTOCOL.encode} />
            <Spec k="roles" v={PROTOCOL.role} />
            <Spec k="field" v={`${PROTOCOL.field}, N = ${PROTOCOL.bins}`} />
            <Spec k="transform" v={PROTOCOL.dft} />
            <Spec k="binding" v={PROTOCOL.bind} />
            <Spec
              k="fault model"
              v={
                faultOn
                  ? `${PROTOCOL.fault}${secondFault ? " and the next bit" : ""}, b = ${faultBit}. Decoder: radius 1, then radius 2.`
                  : "disarmed"
              }
            />
          </ul>
          <section className="mt-10">
            <Head n="01" title="Operators" />
            <p className="mt-1 text-sm text-muted">
              Five relations. None is substituted for another.
            </p>
            <ul className="mt-3 divide-y divide-rule border-y border-rule">
              {OPERATORS.map(([symbol, domain, definition]) => (
                <li
                  key={symbol}
                  className="grid grid-cols-[4.5rem_1fr] gap-3 py-2 sm:grid-cols-[5.5rem_7rem_1fr]"
                >
                  <span className="font-mono text-sm text-signal">{symbol}</span>
                  <span className="hidden font-mono text-xs text-muted sm:block">{domain}</span>
                  <span className="font-mono text-xs sm:text-sm">{definition}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 font-mono text-xs text-muted">
              A_n(x) = C_n(x) + 1 (mod 2ⁿ). For n = 1, A_1(b) = b, while b̄ = 1 − b.
            </p>
          </section>
          <BenchBody report={report} frame={frameIndex} setFrame={setFrame} />
        </>
      ) : null}

      <section className="mt-10">
        <Head n="09" title="Exclusions" />
        <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-muted">
          <li>Cropping and coefficient quantization of bound records.</li>
          <li>
            A 2-adic NPU, a unikernel, or a live PEBS capture. The bulk-bit path is packed signs on
            a model sample.
          </li>
          <li>Identification of A_n with the closed sector toy model in Stack 1.0.0.</li>
          <li>Treating the procedure algebra as a physical system, a code, or a threshold.</li>
          <li>
            Treating GF(2^n) as the ring ℤ/2^nℤ. Addition there is XOR, and negation is the
            identity.
          </li>
          <li>Reading the erased Reed–Solomon symbol as a fault-tolerance threshold.</li>
        </ul>
        <p className="mt-4 text-sm">
          <Link to="/spec" className="text-signal underline decoration-rule underline-offset-4">
            Stack 1.0.0
          </Link>
        </p>
      </section>
    </main>
  );
}

function BenchBody({
  report,
  frame,
  setFrame,
}: {
  report: BenchReport;
  frame: number;
  setFrame: (update: (index: number) => number) => void;
}) {
  const current: Frame = report.frames[frame];
  const scope = report.phaseScope.exhaustive
    ? `exhaustive on all ${report.phaseScope.samples} residues`
    : `sample of ${report.phaseScope.samples} residues, not a universal bound`;

  return (
    <>
      <section className="mt-10">
        <Head n="02" title="Registers" />
        <ul className="mt-3 divide-y divide-rule border-y border-rule">
          {report.registers.map((row) => (
            <li key={row.name} className="py-3">
              <p className="font-mono text-xs text-muted">
                <span className="text-signal">{row.name}</span>
                <span className="px-2">dec {row.dec}</span>
                <span>hex {row.hex}</span>
              </p>
              <p className="mt-1 font-mono text-xs break-all tracking-wider text-ink">{row.bits}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-10">
        <Head n="03" title="Error budget" />
        <p className="mt-1 text-sm text-muted">Phase check is {scope}.</p>
        <ul className="mt-3 divide-y divide-rule border-y border-rule">
          <Spec k="DFT round trip" v={`‖F⁻¹ F U − U‖∞ = ${sci(report.fftRoundtrip)}`} />
          <Spec k="clean unbind ∞" v={sci(report.cleanRecovery.max)} />
          <Spec k="clean unbind RMS" v={sci(report.cleanRecovery.rms)} />
          <Spec k="observed ∞" v={sci(report.recovery.max)} />
          <Spec k="observed RMS" v={sci(report.recovery.rms)} />
          <Spec k="‖ |E| − 1 ‖∞" v={sci(report.unitMax)} />
        </ul>
      </section>

      <section className="mt-10">
        <Head n="04" title="Predicates" />
        <ul className="mt-3 divide-y divide-rule border-y border-rule">
          {report.checks.map((check, index) => (
            <li key={check.name} className="grid grid-cols-[1.25rem_1fr] gap-3 py-3">
              <span
                className={
                  "mt-1.5 inline-block size-2 rounded-full " +
                  (check.hold ? "bg-signal" : "bg-oxide")
                }
                aria-hidden
              />
              <div>
                <p>
                  <span className="font-mono text-xs text-muted">P{index + 1} </span>
                  {check.name}
                </p>
                <p className="font-mono text-xs break-all text-muted">{check.detail}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-10">
        <Head n="05" title="Spectral sample" />
        <p className="mt-1 font-mono text-xs text-muted">k, r_k, A_n(r_k), |E(A) − E*|</p>
        <ul className="mt-3 divide-y divide-rule border-y border-rule">
          <li className="grid grid-cols-4 gap-2 py-2 font-mono text-xs text-muted">
            <span>k</span>
            <span>r_k</span>
            <span>A_n</span>
            <span className="text-right">residual</span>
          </li>
          {report.roles.map((role) => (
            <li key={role.k} className="grid grid-cols-4 gap-2 py-2 font-mono text-xs sm:text-sm">
              <span className="text-signal">{role.k}</span>
              <span>{role.role}</span>
              <span>{role.anti}</span>
              <span className="text-right">{sci(role.phaseErr)}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-10 grid gap-8 sm:grid-cols-2">
        <div>
          <Head n="06" title="Conjugate dynamics" />
          <p className="mt-1 font-mono text-xs text-muted">{PROTOCOL.partner}</p>
          <ul className="mt-3 divide-y divide-rule border-y border-rule">
            {report.paired.map((row) => (
              <li key={row.step} className="py-2 font-mono text-xs">
                <span className="text-signal">t = {row.step} </span>
                {row.x} + {row.a} ≡ {row.sum}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <Head n="07" title="Compatible lift" />
          <p className="mt-1 font-mono text-xs text-muted">{PROTOCOL.lift}</p>
          <ul className="mt-3 divide-y divide-rule border-y border-rule">
            {report.ladder.map((rung) => (
              <li key={rung.width} className="py-2 font-mono text-xs break-all">
                <span className="text-signal">n = {rung.width} </span>
                {rung.value}
                <span className="text-muted"> mod 256 = {rung.low8}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mt-10">
        <Head n="08" title="Reference quadrature" />
        <p className="mt-1 font-mono text-xs text-muted">{PROTOCOL.quadrature}</p>
        <ul className="mt-3 divide-y divide-rule border-y border-rule">
          <Spec
            k="|U_0|² − |U_1|²"
            v={report.interference.intensityMatch ? "0, as required" : "nonzero"}
          />
          <Spec
            k="quad residual"
            v={`| |R+U|² − |R−U|² − 4 Re(R* U) | = ${sci(report.interference.quadErr)}`}
          />
        </ul>
      </section>

      <section className="mt-10 border border-rule bg-well p-3 sm:p-4">
        <div className="flex items-baseline justify-between gap-3">
          <Head n="" title="Run record" />
          <p className="font-mono text-xs text-muted">
            {frame + 1}/{report.frames.length}
          </p>
        </div>
        <div className="mt-3 flex">
          {report.frames.map((item, index) => (
            <button
              key={item.id}
              type="button"
              aria-label={item.title}
              aria-current={index === frame}
              className="flex min-h-11 flex-1 items-center justify-center"
              onClick={() => setFrame(() => index)}
            >
              <span className={"h-1 w-full " + (index === frame ? "bg-signal" : "bg-rule")} />
            </button>
          ))}
        </div>
        <h3 className="mt-4 font-serif text-2xl">{current.title}</h3>
        <ul className="mt-2">
          {current.lines.map((line) => (
            <li key={line.k} className="grid grid-cols-[7.5rem_1fr] gap-2 py-1 font-mono text-xs">
              <span className="text-muted">{line.k}</span>
              <span className="break-all">{line.v}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex gap-2">
          <button
            type="button"
            className="min-h-11 flex-1 border border-rule font-mono text-sm hover:border-signal"
            onClick={() =>
              setFrame((index) => (index + report.frames.length - 1) % report.frames.length)
            }
          >
            Previous
          </button>
          <button
            type="button"
            className="min-h-11 flex-1 border border-signal bg-signal font-mono text-sm text-well"
            onClick={() => setFrame((index) => (index + 1) % report.frames.length)}
          >
            Next
          </button>
        </div>
      </section>
    </>
  );
}

const ORDERS = [4, 8, 16] as const;

function WeylPanel({ word, width }: { word: bigint; width: Width }) {
  const [order, setOrder] = useState<(typeof ORDERS)[number]>(8);
  const algebra = useMemo(() => quantumProcedure(word, width), [word, width]);
  const bits = Math.round(Math.log2(order));
  const shown = useMemo(() => quantumProcedure(word, bits), [word, bits]);
  const forwardMatrix = useMemo(() => monomialMatrix(shown.forward, bits), [shown, bits]);
  const inverseMatrix = useMemo(() => monomialMatrix(shown.inverse, bits), [shown, bits]);
  const product = useMemo(
    () => matrixProduct(inverseMatrix, forwardMatrix),
    [inverseMatrix, forwardMatrix],
  );
  const identity = isIdentity(product);
  return (
    <section className="mt-4" aria-label="Quantum matrices">
      <div className="deck-well border border-rule p-3 sm:p-4">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="font-serif text-2xl text-ink">Quantum matrices</h2>
          <p
            className={
              "font-mono text-xs " + (algebra.holds && identity ? "text-signal" : "text-oxide")
            }
          >
            {identity ? "Identity" : "Product miss"}
          </p>
        </div>
        <p className="mt-2 text-sm text-ink">
          A procedure is a matrix. Each column has one entry: the row is the shift, and the numeral
          is the power of ω. At order {order} the residue is reduced modulo that order. The third
          grid is the identity. Not a physical system.
        </p>
        <ul className="mt-3 space-y-1 font-mono text-xs text-muted">
          <li>
            P = ω^{shown.residue} X Z^{shown.residue}
          </li>
          <li>P⁻¹ = X⁻¹ Z^{shown.anti}</li>
        </ul>
        <fieldset className="mt-3 flex gap-2">
          {ORDERS.map((choice) => (
            <button
              key={choice}
              type="button"
              aria-pressed={choice === order}
              className={
                "min-h-11 flex-1 border font-mono text-sm " +
                (choice === order ? "border-signal bg-signal text-well" : "border-rule text-ink")
              }
              onClick={() => setOrder(choice)}
            >
              {choice}
            </button>
          ))}
        </fieldset>
        <div className="mt-3 grid gap-3 lg:grid-cols-3">
          <MatrixGrid name="P" cells={forwardMatrix} />
          <MatrixGrid name="P⁻¹" cells={inverseMatrix} />
          <MatrixGrid name="P⁻¹P" cells={product} />
        </div>
      </div>
    </section>
  );
}

function MatrixGrid({ name, cells }: { name: string; cells: (number | null)[][] }) {
  const order = cells.length;
  return (
    <figure>
      <figcaption className="mb-1 font-mono text-xs text-muted">{name}</figcaption>
      <div
        className="grid gap-px bg-rule"
        style={{ gridTemplateColumns: `repeat(${order}, minmax(0, 1fr))` }}
        role="img"
        aria-label={`${name}, order ${order}`}
      >
        {cells.flat().map((phase, index) => (
          <span
            key={index}
            className={
              "flex aspect-square items-center justify-center bg-well font-mono leading-none " +
              (phase === null ? "text-transparent" : "text-signal")
            }
            style={{ fontSize: order > 8 ? "0.55rem" : "0.7rem" }}
          >
            {phase === null ? "·" : phase}
          </span>
        ))}
      </div>
    </figure>
  );
}

function LambPanel({ word, width }: { word: bigint; width: Width }) {
  const wave = useMemo(() => lambWave(word, width, PROTOCOL.bins), [word, width]);
  const streams = useMemo(() => releases(word, width, PROTOCOL.bins), [word, width]);
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const emitted = emitReleases(streams, open);
  const [gpu, setGpu] = useState<"pending" | "matched" | "differ" | "unavailable">("pending");
  const gpuLabel =
    gpu === "matched"
      ? "GPU rank matched the gather"
      : gpu === "differ"
        ? "GPU rank differed"
        : gpu === "unavailable"
          ? "GPU rank unavailable"
          : "GPU rank running";
  return (
    <section className="mt-4" aria-label="Bulk bits">
      <div className="deck-well border border-rule p-3 sm:p-4">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="font-serif text-2xl text-ink">Bulk bits</h2>
          <p className={"font-mono text-xs " + (wave.holds ? "text-signal" : "text-oxide")}>
            {wave.holds ? "Packed" : "Miss"}
          </p>
        </div>
        <p className="mt-2 text-sm text-ink">
          1-bit LAMB, Li, Awan, Tang, Rajbhandari, and He, arXiv:2104.06069. The CPU rank and the
          GPU rank each hold the sign of the difference with the next address. That sign is the
          spatial predicate. v stays frozen. Signs are packed, reduced by halves, averaged, and
          gathered. A tie means the anti-word reversed the neighbor sign. The formulas gate four CPU
          waves. The same producer also releases the GPU pack, the role bytes, the anti-role bytes,
          and the gather. A faucet only opens a stream. It does not run the formula. Not a 2-adic
          NPU, not a unikernel, and not a live PEBS capture.
        </p>
        <ul className="mt-3 space-y-1 font-mono text-xs text-muted">
          <li>
            {wave.waves} waves, {wave.packedBytes} B packed against {wave.denseBytes} B dense
          </li>
          <li>cpu pack {wave.packedHex}</li>
          <li className="break-all">
            emitted{" "}
            {emitted.length === 0
              ? "none"
              : emitted.map((item) => `${item.label} ${item.bytes}`).join(" · ")}
          </li>
          {streams[0]?.label === "Schrödinger"
            ? WAVE_REFERENCES.map((item) => (
                <li key={item.name}>
                  {item.name}: {item.formula}
                </li>
              ))
            : null}
          <li>
            agreements {wave.agreed}, ties {wave.ties}, ratio {wave.ratio.toFixed(2)}
          </li>
          <li>
            tiers L1 {wave.tiers.L1}, L2 {wave.tiers.L2}, LLC {wave.tiers.LLC}, DRAM{" "}
            {wave.tiers.DRAM}
          </li>
        </ul>
        <div className="mt-3 grid grid-cols-2 gap-2">
          {streams.map((item) => {
            const flowing = open[item.id] === true;
            return (
              <button
                key={item.id}
                type="button"
                aria-pressed={flowing}
                className={
                  "min-h-11 border font-mono text-sm " +
                  (flowing ? "border-signal bg-signal text-well" : "border-rule text-ink")
                }
                onClick={() => setOpen((current) => ({ ...current, [item.id]: !current[item.id] }))}
              >
                {flowing ? item.label : `${item.label} shut`}
              </button>
            );
          })}
        </div>
        <button
          type="button"
          className="mt-3 min-h-11 w-full border border-signal font-mono text-sm text-signal"
          onClick={() => {
            const averaged = gpuAverageSigns(wave.cpuSigns, wave.gpuSigns);
            if (!averaged) {
              setGpu("unavailable");
              return;
            }
            setGpu(
              averaged.every((bit, index) => bit === wave.gathered[index]) ? "matched" : "differ",
            );
          }}
        >
          {gpu === "pending" ? "Run GPU rank" : gpuLabel}
        </button>
      </div>
    </section>
  );
}

function WitnessPanel({ report }: { report: BenchReport }) {
  return (
    <section className="mt-4" aria-label="Witnesses">
      <div className="deck-well border border-rule p-3 sm:p-4">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="font-serif text-2xl text-ink">Witnesses</h2>
          <p className="font-mono text-xs text-signal">
            {report.checks.filter((check) => check.hold).length}/{report.checks.length}
          </p>
        </div>
        <ul className="mt-3 space-y-1 font-mono text-xs text-muted">
          <li>
            NTT mod {report.exact.prime}, length {report.exact.length}
            {report.exact.holds ? ", exact" : ", miss"}
          </li>
          <li>
            eight-bit sweep worst {sci(report.byte.worst)} over {report.byte.samples}
          </li>
          <li>complement unbind {sci(report.complementMax)}</li>
          <li>
            two records, linearity {sci(report.superposition.linearMax)}, cross{" "}
            {sci(report.superposition.crossMax)}
          </li>
        </ul>
        <button
          type="button"
          className="mt-3 min-h-11 w-full border border-signal font-mono text-sm text-signal"
          onClick={() => {
            const blob = new Blob([JSON.stringify(witnessOf(report), null, 2)], {
              type: "application/json",
            });
            const url = URL.createObjectURL(blob);
            const anchor = document.createElement("a");
            anchor.href = url;
            anchor.download = `awb-1-r${PROTOCOL.revision}-w${report.width}-${report.word}.json`;
            anchor.click();
            URL.revokeObjectURL(url);
          }}
        >
          Witness JSON
        </button>
      </div>
    </section>
  );
}

function GaloisPanel({ word, width }: { word: bigint; width: Width }) {
  const [tableBits, setTableBits] = useState<2 | 3 | 4>(3);
  const field = useMemo(() => fieldOf(word, width), [word, width]);
  const table = useMemo(() => productTable(tableBits), [tableBits]);
  return (
    <section className="mt-4" aria-label="Galois field">
      <div className="deck-well border border-rule p-3 sm:p-4">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="font-serif text-2xl text-ink">Galois field</h2>
          <p className={"font-mono text-xs " + (field.holds ? "text-signal" : "text-oxide")}>
            {field.holds ? "Field" : "Check miss"}
          </p>
        </div>
        <p className="mt-2 text-sm text-ink">
          GF(2^{width}) is a field. ℤ/2^{width}ℤ is only a ring. The same bits are not the same
          arithmetic. In the field, addition is XOR, so the negative of an element is itself. The
          ring anti-word is a different bitstring, except at 0 and at 2^(n−1).
        </p>
        <ul className="mt-3 space-y-1 font-mono text-xs text-muted">
          <li>{field.polynomial}</li>
          <li>a = {field.element}</li>
          <li>ring −a = {field.ringNegation}</li>
          <li>field −a = {field.fieldNegation}</li>
          <li>a + A_n(a) = {field.fieldSum} in the field</li>
          <li>
            a⁻¹ = {field.inverse}, a · a⁻¹ = {field.product}
          </li>
        </ul>
        <fieldset className="mt-3 flex gap-2">
          {(
            [
              [2, "GF(4)"],
              [3, "GF(8)"],
              [4, "GF(16)"],
            ] as const
          ).map(([bits, label]) => (
            <button
              key={bits}
              type="button"
              aria-pressed={bits === tableBits}
              className={
                "min-h-11 flex-1 border font-mono text-sm " +
                (bits === tableBits ? "border-signal bg-signal text-well" : "border-rule text-ink")
              }
              onClick={() => setTableBits(bits)}
            >
              {label}
            </button>
          ))}
        </fieldset>
        <div
          className="mt-3 grid gap-px bg-rule"
          style={{ gridTemplateColumns: `repeat(${table.length}, minmax(0, 1fr))` }}
          role="img"
          aria-label={`Multiplication table of GF(${table.length})`}
        >
          {table.flat().map((entry, index) => (
            <span
              key={index}
              className={
                "flex aspect-square items-center justify-center bg-well font-mono leading-none " +
                (entry === 0 ? "text-muted" : "text-signal")
              }
              style={{ fontSize: table.length > 8 ? "0.55rem" : "0.7rem" }}
            >
              {entry}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

function ApplyPanel({ word, width }: { word: bigint; width: Width }) {
  const [erased, setErased] = useState<0 | 1 | 2>(1);
  const sbox = useMemo(() => aesSbox(Number(word & 0xffn)), [word]);
  const code = useMemo(
    () => eraseSymbol(word, anti(word, width), width, erased),
    [word, width, erased],
  );
  const holds = sbox.holds && code.holds;
  return (
    <section className="mt-4" aria-label="Finite-field applications">
      <div className="deck-well border border-rule p-3 sm:p-4">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="font-serif text-2xl text-ink">Applications</h2>
          <p className={"font-mono text-xs " + (holds ? "text-signal" : "text-oxide")}>
            {holds ? "Recovered" : "Check miss"}
          </p>
        </div>
        <p className="mt-2 text-sm text-ink">
          Two uses of a finite field. The S-box is inversion in the AES field, then a fixed affine
          map. The code is one erased symbol of a length-3 Reed–Solomon word, recovered from the
          other two. Not a fault-tolerance threshold.
        </p>
        <ul className="mt-3 space-y-1 font-mono text-xs text-muted">
          <li>AES p(x) = x^8 + x^4 + x^3 + x + 1</li>
          <li>
            S({sbox.byte}) = {sbox.image}, inverse {sbox.inverse}
          </li>
          <li>
            c = ({code.symbols.join(", ")}), erased c_{erased}
          </li>
          <li>recovered {code.recovered}</li>
        </ul>
        <fieldset className="mt-3 flex gap-2">
          {([0, 1, 2] as const).map((index) => (
            <button
              key={index}
              type="button"
              aria-pressed={index === erased}
              className={
                "min-h-11 flex-1 border font-mono text-sm " +
                (index === erased ? "border-signal bg-signal text-well" : "border-rule text-ink")
              }
              onClick={() => setErased(index)}
            >
              Erase {index}
            </button>
          ))}
        </fieldset>
      </div>
    </section>
  );
}

function Lamp({ armed, failed }: { armed: boolean; failed: boolean }) {
  const hot = armed || failed;
  const label = failed ? "Predicate fail" : armed ? "Fault armed" : "Nominal";
  return (
    <p
      className={
        "flex items-center gap-2 font-mono text-xs " + (hot ? "text-oxide" : "text-signal")
      }
    >
      <span
        className={"lamp-live inline-block size-2 rounded-full " + (hot ? "bg-oxide" : "bg-signal")}
      />
      {label}
    </p>
  );
}

function Head({ n, title }: { n: string; title: string }) {
  return (
    <h2 className="border-l-2 border-signal pl-3 font-serif text-2xl text-ink">
      {n ? <span className="mr-3 font-mono text-xs text-muted">{n}</span> : null}
      {title}
    </h2>
  );
}

function Spec({ k, v }: { k: string; v: string }) {
  return (
    <li className="grid gap-1 py-2 sm:grid-cols-[9.5rem_1fr] sm:gap-3">
      <span className="font-mono text-xs text-muted">{k}</span>
      <span className="font-mono text-xs break-all">{v}</span>
    </li>
  );
}

function Stat({
  label,
  value,
  note,
  tone,
}: {
  label: string;
  value: string;
  note: string;
  tone: "ink" | "oxide" | "signal";
}) {
  const color = tone === "oxide" ? "text-oxide" : tone === "signal" ? "text-signal" : "text-ink";
  return (
    <div className="bg-paper px-3 py-3">
      <p className="font-mono text-xs text-muted">{label}</p>
      <p className={"mt-1 font-mono text-xl sm:text-2xl " + color}>{value}</p>
      <p className="mt-1 font-mono text-xs text-muted">{note}</p>
    </div>
  );
}

function FieldPlot({
  original,
  recovered,
  faulted,
}: {
  original: number[];
  recovered: number[];
  faulted: boolean;
}) {
  const width = 320;
  const height = 120;
  const snap = (value: number) => Math.round(value * 1e4) / 1e4;
  const left = original.map(snap);
  const right = recovered.map(snap);
  const all = [...left, ...right];
  const min = Math.min(...all);
  const max = Math.max(...all);
  const span = max - min || 1;
  const path = (series: number[]) =>
    series
      .map((value, index) => {
        const x = (index / (series.length - 1)) * width;
        const y = height - 8 - ((value - min) / span) * (height - 16);
        return `${index === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
      })
      .join(" ");
  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className="h-36 w-full sm:h-44"
      role="img"
      aria-label="Real part of U and of the returned field"
    >
      <path d={path(left)} fill="none" stroke="var(--color-signal)" strokeWidth="1.8" />
      <path
        d={path(right)}
        fill="none"
        stroke="var(--color-oxide)"
        strokeWidth={faulted ? 1.8 : 1.2}
        strokeDasharray="5 3"
        opacity={faulted ? 1 : 0.85}
      />
    </svg>
  );
}

function PhaseRing({ word, anti, modulus }: { word: string; anti: string; modulus: string }) {
  const turn = (value: string) => (Number(value) / Number(modulus)) * Math.PI * 2 - Math.PI / 2;
  const point = (angle: number, radius: number) => ({
    x: 36 + Math.cos(angle) * radius,
    y: 36 + Math.sin(angle) * radius,
  });
  const a = point(turn(word), 22);
  const b = point(turn(anti), 22);
  return (
    <svg
      viewBox="0 0 72 72"
      className="mx-auto h-24 w-24"
      role="img"
      aria-label="Phase of the word and of its anti-word"
    >
      <circle cx="36" cy="36" r="26" fill="none" stroke="var(--color-rule)" strokeWidth="1" />
      <circle cx="36" cy="36" r="2" fill="var(--color-muted)" />
      <line
        x1="36"
        y1="36"
        x2={a.x.toFixed(2)}
        y2={a.y.toFixed(2)}
        stroke="var(--color-signal)"
        strokeWidth="1.6"
      />
      <circle cx={a.x.toFixed(2)} cy={a.y.toFixed(2)} r="3" fill="var(--color-signal)" />
      <line
        x1="36"
        y1="36"
        x2={b.x.toFixed(2)}
        y2={b.y.toFixed(2)}
        stroke="var(--color-oxide)"
        strokeWidth="1.4"
      />
      <circle
        cx={b.x.toFixed(2)}
        cy={b.y.toFixed(2)}
        r="2.5"
        fill="none"
        stroke="var(--color-oxide)"
        strokeWidth="1.4"
      />
    </svg>
  );
}
