"""Verify the four-record research example against its separately exported TIFF/replay.

Requires Pillow and an independent Node report produced by verify-research-session.cjs.
Uses the separate Python GF80 reference verifier; imports no application JavaScript.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--session", required=True, type=Path)
parser.add_argument("--zip", required=True, type=Path, dest="replay_zip")
parser.add_argument("--tiff", required=True, type=Path)
parser.add_argument("--node-report", required=True, type=Path)
parser.add_argument("--report", required=True, type=Path)
parser.add_argument("--ledger-report", type=Path, help="Concise output; defaults beside --report")
parser.add_argument("--original-words", type=Path, help="Optional directory of independently retained length.bin through ceiling.bin")
args = parser.parse_args()
session_path, replay_path, tiff_path = args.session, args.replay_zip, args.tiff
report_path = args.report
ledger_path = args.ledger_report or report_path.with_name("research-ledger-independent-check.json")
spec = importlib.util.spec_from_file_location("independent_gf80_verifier", Path(__file__).resolve().with_name("verify-gfm-export.py"))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
require = module.require
node_report = json.loads(args.node_report.read_text(encoding="utf-8"))
session = json.loads(session_path.read_text(encoding="utf-8"))
require(hashlib.sha256(session_path.read_bytes()).hexdigest() == node_report["inputSHA256"], "Node verification used different session bytes")
require(node_report["status"] == "PASS", "Independent session digest check failed")
export_report = module.verify(replay_path, tiff_path)
with zipfile.ZipFile(replay_path) as archive:
    files = {name: archive.read(name) for name in archive.namelist()}
manifest = json.loads(files["manifest.json"])
payload = files["pixel160.bin"]
record = next(row for row in session["records"] if row["request"]["type"] == "russl-slice")
snapshot, result = record["request"]["snapshot"], record["result"]
require(bytes.fromhex(snapshot["pixelPayloadHex"]) == payload, "Research snapshot pixels differ from actual TIFF/replay bytes")
for key in ("schema", "config", "domain", "words", "field", "dynamics", "generator", "observation", "slice", "fullStatesHex", "wordWitnesses"):
    require(snapshot["manifest"][key] == manifest[key], f"Research {key} metadata differs from the actual export")
require(result["pixelPayloadSHA256"] == hashlib.sha256(payload).hexdigest(), "Research result pixel hash differs from actual replay payload")
require(result["config"] == manifest["config"], "Research result configuration differs from actual export")
require(result["sourceHashScope"]["verifiedFromOriginalBytes"] is False, "Bounded record incorrectly claims complete source verification")
require(all(word["originalHashesVerified"] is False for word in result["sourceHashScope"]["importedWords"]), "Bounded record incorrectly claims an original word hash check")

config = manifest["config"]
dimensions = tuple(map(int, config["words"]))
imported, source_checks = module.restore_imported_words(manifest, files, dimensions)
require(len(source_checks) == 5, "Actual replay must include five original word sources")
for descriptor, claimed in zip(source_checks, result["sourceHashScope"]["importedWords"], strict=True):
    original = files[descriptor["entry"]]
    if args.original_words is not None:
        fixture = args.original_words / (descriptor["name"] + ".bin")
        require(original == fixture.read_bytes(), "Replay does not preserve the independently retained appliance-export bytes")
    require(descriptor["sourceSha256"] == claimed["sourceSha256"], "Bounded source identity differs from full original hash")
    require(descriptor["canonicalSha256"] == claimed["canonicalSha256"], "Bounded canonical identity differs from full word conversion")

selected = snapshot["selected"]
require(selected == result["selected"], "Research result selected witness differs from its input")
coords = tuple(map(int, selected["coordinates"]))
require(coords == (19, 11, 2, 3, 6553), "Selected research example coordinates changed")
require(selected["rowMajorIndex"] == 11 * 32 + 19, "Selected row-major index changed")
require(config["tick"] == "7" and config["couplingAxis"] == 4, "Selected state is not the step7 ceiling-coupled example")
partner_coords = list(coords)
partner_coords[4] ^= 1
require(partner_coords[4] == 6552, "Wrong off-plane partner coordinate")
require(int(selected["address"]) == module.mixed_radix(coords, dimensions), "Selected address is not independently derived")
require(int(selected["partnerAddress"]) == module.mixed_radix(partner_coords, dimensions), "Partner address is not independently derived")
unit = imported[4][6553 * 20:6554 * 20]
require(len(unit) == 20 and unit[:8] == bytes(8), "Final native ceiling unit lost its declared high zero padding")
initial = module.make_initial_state(module.independent_parameters(int(config["seed"])), imported)
pair = (initial(coords), initial(tuple(partner_coords)))
kappa, coupling = int(config["kappa"]), int(config["coupling"])
initial_invariant = module.pair_invariant(pair, kappa, coupling)
for step in range(7):
    previous = pair
    pair = module.step_pair(pair, kappa, coupling)
    require(module.inverse_pair(pair, kappa, coupling) == previous, "Selected inverse fails direct polynomial arithmetic")
require(pair[0] == (int(selected["qHex"], 16), int(selected["pHex"], 16)), "Selected research state differs from independent source evolution")
require(pair[1] == (int(selected["partnerQHex"], 16), int(selected["partnerPHex"], 16)), "Selected partner differs from independent source evolution")
require(initial_invariant == int(selected["initialInvariantHex"], 16), "Initial research invariant differs")
require(module.pair_invariant(pair, kappa, coupling) == int(selected["currentInvariantHex"], 16) == initial_invariant, "Final research invariant differs")
require(module.cell_invariant(pair[0], kappa) == int(selected["cellInvariantHex"], 16), "Selected cell invariant differs")
pixel = payload[selected["rowMajorIndex"] * 20:(selected["rowMajorIndex"] + 1) * 20]
require(pixel.hex() == selected["pixelHex"], "Selected research pixel differs from TIFF payload")
require(selected["inverseVerified"] is True, "Selected research inverse claim is false")

report = {
    "schema": "RUSSL-RESEARCH-INDEPENDENT-EXPORT/1",
    "status": "PASS",
    "scope": ["Verifies supplied four-record reference-session, TIFF and replay bytes. Acquisition and native file-saving transport are separate checks.",
              "Independent Node canonical key sorting/SHA256 and characteristic-3/Bell sampling references, followed by Python/Pillow/zipfile polynomial GF80 verification.",
              "Envelope hashes verify consistency; computational checks cover bounded experiments and source bytes, not authorship or physical theory."],
    "inputs": {"session": str(session_path.resolve()), "replayZip": str(replay_path.resolve()), "tiff": str(tiff_path.resolve()),
               "nodeReport": str(args.node_report.resolve()), "originalWords": str(args.original_words.resolve()) if args.original_words else None},
    "session": node_report,
    "rawSliceExport": export_report,
    "crossChecks": {"sessionPixelBytesMatchActualTIFFReplay": True, "sessionManifestMatchesActualExportModel": True,
                    "completeOriginalSourcesMatchRetainedApplianceExports": 5 if args.original_words is not None else "NOT_CHECKED",
                    "sourceIdentitiesMatchBoundedRecord": True, "boundedRecordCorrectlyDeclaresOriginalHashesUnverified": True,
                    "selectedCoordinates": list(coords), "selectedIndex": selected["rowMajorIndex"],
                    "selectedStateAndPartnerIndependentlyReconstructed": True, "selectedDirectInverseStepsVerified": 7,
                    "ceilingPartialUnitHighPaddingBits": 64, "boundedWitnessUnits": sum(len(w["units"]) for w in snapshot["manifest"]["wordWitnesses"])},
}
report_path.parent.mkdir(parents=True, exist_ok=True)
report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
ledger_report = {
    "schema": "RUSSL-RESEARCH-INDEPENDENT-LEDGER/1", "status": "PASS",
    "inputs": report["inputs"],
    "sha256": {"session": node_report["inputSHA256"], **export_report["sha256"]},
    "canonicalEnvelopeHashes": node_report["records"], "recordCount": node_report["recordCount"],
    "modelChecks": {"gf9BiorthogonalWitness": node_report["gf9"], "bellCircuit": node_report["circuit"],
                    "synthetic64BitPenteract": node_report["syntheticPenteract"],
                    "rawGF80SliceStatesIndependentlyReconstructed": export_report["checks"]["directEvolutionStatesMatch"]},
    "crossChecks": report["crossChecks"],
    "sourceHashScope": {"boundedLedgerRecordClaimsOriginalHashesVerified": False,
                        "independentVerificationOfCompleteZIPWordBytes": "PASS for all five sources",
                        "explanation": "The bounded record identifies source hashes and validates dependent units. Complete original hashes are independently verified here using original files preserved in the separately exported replay ZIP."},
    "scope": report["scope"],
}
ledger_path.parent.mkdir(parents=True, exist_ok=True)
ledger_path.write_text(json.dumps(ledger_report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "PASS", "sessionRecords": len(session["records"]), "allStates": export_report["checks"]["directEvolutionStatesMatch"], "crossChecks": report["crossChecks"]}, indent=2))
