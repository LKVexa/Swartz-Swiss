import test from "node:test";
import assert from "node:assert/strict";
import {
  AXIS_NAMES,
  DEFAULT_CONFIG,
  dimensionsOf,
  domainSize,
  packCoordinates,
  unpackCoordinates,
  sampleSlice,
  virtualField,
  verifyInverse,
  validateConfig,
} from "./penteract.ts";
import type { SliceConfig, FiveStrings } from "./penteract.ts";
import {
  encodePixel160,
  decodePixel160,
  encodeStatePixel160,
  decodeStatePixel160,
} from "./pixel.ts";
import { stepCell, stepPair, advanceCell } from "./dynamics.ts";
import type { PairState } from "./dynamics.ts";
import { gfMul } from "./field.ts";

const MASK80 = (1n << 80n) - 1n;
const config = (patch: Partial<SliceConfig> = {}): SliceConfig => ({
  ...DEFAULT_CONFIG,
  words: [...DEFAULT_CONFIG.words],
  fixed: [...DEFAULT_CONFIG.fixed],
  origin: [...DEFAULT_CONFIG.origin],
  axes: [...DEFAULT_CONFIG.axes],
  ...patch,
});

test("Five independent word lengths define an exact mixed-radix domain", () => {
  assert.deepEqual(AXIS_NAMES, ["length", "width", "depth", "height", "ceiling"]);
  const defaults = dimensionsOf(config());
  assert.deepEqual(defaults, [64n, 64n, 8n, 8n, 8n]);
  assert.equal(domainSize(defaults), 64n * 64n * 8n * 8n * 8n);
  assert.notEqual(domainSize(defaults), 1n << 100n);
  const dimensions = [(1n << 90n) + 11n, 11n, 9n, 7n, 5n];
  const fixtures = [
    [0n, 0n, 0n, 0n, 0n],
    dimensions.map((length) => length - 1n),
    [(1n << 89n) + 3n, 7n, 8n, 6n, 4n],
  ];
  for (const coordinates of fixtures)
    assert.deepEqual(
      unpackCoordinates(packCoordinates(coordinates, dimensions), dimensions),
      coordinates,
    );
  assert.equal(packCoordinates(fixtures[1], dimensions), domainSize(dimensions) - 1n);
  assert(domainSize(dimensions) > 1n << 100n);
  assert.throws(() => packCoordinates([0n, 0n, 0n, 0n, 5n], dimensions));
  assert.throws(() => unpackCoordinates(domainSize(dimensions), dimensions));
  assert.throws(() => packCoordinates(new Array<bigint>(5), dimensions));
});

test("Full q80,p80 state fits Pixel160, including high unsigned lane bits", () => {
  for (const state of [
    { q: 0n, p: 0n },
    { q: MASK80, p: MASK80 },
    { q: (1n << 79n) | 0x0123456789abn, p: (1n << 79n) | 0xfedcba987654n },
  ]) {
    const pixel = encodeStatePixel160(state),
      bytes = encodePixel160(pixel),
      decoded = decodePixel160(bytes);
    assert.equal(bytes.length, 20);
    assert.deepEqual(decoded, pixel);
    assert.deepEqual(decodeStatePixel160(encodeStatePixel160(state)), state);
    const independentWord = decoded.reduce((word, lane) => (word << 32n) | BigInt(lane), 0n);
    assert.deepEqual({ q: independentWord >> 80n, p: independentWord & MASK80 }, state);
  }
  assert.deepEqual(encodeStatePixel160({ q: MASK80, p: MASK80 }), Array(5).fill(0xffffffff));
});

test("Each virtual axis word produces bounded exact Pixel160 units", () => {
  const cfg = config(),
    field = virtualField(cfg),
    dimensions = dimensionsOf(cfg);
  for (let axis = 0; axis < 5; axis++) {
    for (const index of [0n, dimensions[axis] - 1n]) {
      const unit = field.generator.wordUnit(axis, index);
      assert.equal(encodePixel160(unit).length, 20);
      assert.deepEqual(field.generator.wordUnit(axis, index), unit);
    }
    assert.throws(() => field.generator.wordUnit(axis, dimensions[axis]));
    assert.throws(() => field.generator.wordUnit(axis, -1n));
  }
  assert.throws(() => field.generator.wordUnit(5, 0n));
});

test("Fixed-law cell evolution matches direct steps and inverse replay", () => {
  const cfg = config({ mode: "cell", size: 8, tick: "11" });
  const field = virtualField(cfg),
    index = packCoordinates([3n, 7n, 2n, 3n, 4n], dimensionsOf(cfg));
  const cell = field.observe(index);
  let reference = { ...cell.initial };
  for (let i = 0; i < 11; i++) reference = stepCell(reference, "gf80", BigInt(cfg.kappa));
  assert.deepEqual(cell.state, reference);
  assert.equal(cell.initialInvariant, cell.currentInvariant);
  assert(verifyInverse(cell, cfg));
  assert.deepEqual(field.observe(index).pixel, encodeStatePixel160(reference));
  assert(
    cell.state.q >= 0n && cell.state.q <= MASK80 && cell.state.p >= 0n && cell.state.p <= MASK80,
  );
});

test("Every axis pairs coordinate neighbors consistently from either slot", () => {
  for (let axis = 0; axis < 5; axis++) {
    const cfg = config({ couplingAxis: axis, size: 8, tick: "5" });
    const dimensions = dimensionsOf(cfg),
      field = virtualField(cfg);
    const coordinates = [3n, 7n, 3n, 5n, 5n],
      partnerCoordinates = [...coordinates];
    partnerCoordinates[axis] ^= 1n;
    const a = field.observe(packCoordinates(coordinates, dimensions));
    const b = field.observe(packCoordinates(partnerCoordinates, dimensions));
    assert.equal(a.partnerIndex, b.index);
    assert.equal(b.partnerIndex, a.index);
    assert.deepEqual(a.partnerState, b.state);
    assert.deepEqual(b.partnerState, a.state);
    assert.deepEqual(a.partnerInitial, b.initial);
    let reference: PairState = [{ ...a.initial }, { ...b.initial }];
    for (let i = 0; i < 5; i++)
      reference = stepPair(reference, "gf80", BigInt(cfg.kappa), BigInt(cfg.coupling));
    assert.deepEqual([a.state, b.state], reference);
    assert.equal(a.initialInvariant, a.currentInvariant);
    assert.equal(b.initialInvariant, b.currentInvariant);
    assert(verifyInverse(a, cfg));
    assert(verifyInverse(b, cfg));
  }
});

test("An odd-length final word unit evolves as an unpaired standalone cell", () => {
  const cfg = config({ words: ["64", "64", "8", "8", "5"], couplingAxis: 4, size: 8, tick: "9" });
  const field = virtualField(cfg),
    index = packCoordinates([3n, 7n, 2n, 3n, 4n], dimensionsOf(cfg));
  const cell = field.observe(index);
  assert.equal(cell.partnerIndex, null);
  assert.equal(cell.partnerInitial, null);
  assert.equal(cell.partnerState, null);
  assert.deepEqual(cell.state, advanceCell(cell.initial, 9n, "gf80", BigInt(cfg.kappa)));
  assert.equal(cell.initialInvariant, cell.currentInvariant);
  assert(verifyInverse(cell, cfg));
  assert.notEqual(
    field.observe(packCoordinates([3n, 7n, 2n, 3n, 3n], dimensionsOf(cfg))).partnerIndex,
    null,
  );
  const slice = sampleSlice(cfg);
  assert(slice.cells.every((observation) => observation.partnerIndex === null));
  assert.equal(slice.manifest.slice.observedSliceCells, 64);
  assert.equal(slice.manifest.slice.evaluatedCells, 64);
});

test("Off-plane coupling counts dependencies separately from materialized cells", () => {
  const cfg = config({ couplingAxis: 4, size: 8, tick: "3" }),
    dimensions = dimensionsOf(cfg),
    slice = sampleSlice(cfg);
  assert(slice.cells.every((cell) => cell.partnerState !== null && cell.coords[4] === 4n));
  assert(slice.cells.every((cell) => unpackCoordinates(cell.partnerIndex!, dimensions)[4] === 5n));
  assert.equal(slice.manifest.slice.observedSliceCells, 64);
  assert.equal(slice.manifest.slice.evaluatedCells, 128);
});

test("Slices export exact full-state pixels and a dynamic-domain replay recipe", () => {
  const cfg = config({ size: 8, tick: "17", axes: [4, 2], origin: ["0", "0"] }),
    slice = sampleSlice(cfg);
  assert.equal(slice.cells.length, 64);
  assert.equal(slice.pixelBytes.length, 64 * 20);
  assert.equal("phaseBytes" in slice, false);
  assert.deepEqual(slice.cells[0].coords, [0n, 0n, 0n, 3n, 0n]);
  assert.deepEqual(slice.cells[63].coords, [0n, 0n, 7n, 3n, 7n]);
  for (let i = 0; i < slice.cells.length; i++) {
    const cell = slice.cells[i],
      bytes = slice.pixelBytes.subarray(i * 20, (i + 1) * 20);
    assert.deepEqual(decodePixel160(bytes), cell.pixel);
    assert.deepEqual(decodeStatePixel160(decodePixel160(bytes)), cell.state);
    assert.equal(BigInt("0x" + slice.manifest.fullStatesHex[i].q), cell.state.q);
    assert.equal(BigInt("0x" + slice.manifest.fullStatesHex[i].p), cell.state.p);
    assert.equal(slice.manifest.fullStatesHex[i].q.length, 20);
    assert.equal(slice.manifest.fullStatesHex[i].p.length, 20);
  }
  assert.equal(slice.manifest.domain.cells, domainSize(dimensionsOf(cfg)).toString());
  assert(slice.manifest.checks.invariantPreserved);
  const replayConfig = JSON.parse(JSON.stringify(slice.manifest.config)) as SliceConfig;
  assert.deepEqual(replayConfig.words, cfg.words);
  const replay = sampleSlice(replayConfig);
  assert.deepEqual(replay.pixelBytes, slice.pixelBytes);
  assert.deepEqual(replay.manifest.fullStatesHex, slice.manifest.fullStatesHex);
});

test("Tiny independent words support bounded slices including a singleton", () => {
  const singleton = sampleSlice(
    config({
      words: ["1", "1", "1", "1", "1"],
      fixed: ["0", "0", "0", "0", "0"],
      size: 1,
      tick: "2",
    }),
  );
  assert.equal(singleton.manifest.domain.cells, "1");
  assert.equal(singleton.pixelBytes.length, 20);
  assert.equal(singleton.cells[0].partnerIndex, null);
  assert(verifyInverse(singleton.cells[0], singleton.config));
  const tiny = sampleSlice(
    config({ words: ["2", "4", "1", "1", "1"], fixed: ["0", "0", "0", "0", "0"], size: 2 }),
  );
  assert.equal(tiny.manifest.domain.cells, "8");
  assert.equal(tiny.cells.length, 4);
});

test("A one-unit coupling word leaves a nontrivial slice unpaired", () => {
  const cfg = config({
    words: ["8", "8", "3", "5", "1"],
    couplingAxis: 4,
    fixed: ["0", "0", "2", "3", "0"],
    size: 8,
    tick: "7",
  });
  const slice = sampleSlice(cfg);
  assert.equal(slice.manifest.domain.cells, "960");
  assert.equal(slice.manifest.slice.evaluatedCells, slice.cells.length);
  for (const cell of slice.cells) {
    assert.equal(cell.partnerIndex, null);
    assert.deepEqual(cell.state, advanceCell(cell.initial, 7n, "gf80", BigInt(cfg.kappa)));
    assert.equal(cell.initialInvariant, cell.currentInvariant);
    assert(verifyInverse(cell, cfg));
  }
});

test("All five opaque source units contribute to the declared 800-to-160-bit recipe", () => {
  const cfg = config({ size: 8, tick: "0" }),
    field = virtualField(cfg),
    dimensions = dimensionsOf(cfg);
  const baseCoordinates = [0n, 0n, 0n, 0n, 0n],
    base = field.observe(packCoordinates(baseCoordinates, dimensions));
  const sourceStates = base.wordUnits.map(decodeStatePixel160);
  const combined = sourceStates.reduce(
    (state, unit, axis) => ({
      q: state.q ^ gfMul(unit.q, BigInt(axis + 1), "gf80"),
      p: state.p ^ gfMul(unit.p, BigInt(3 * (axis + 1)), "gf80"),
    }),
    { q: 0n, p: 0n },
  );
  assert.deepEqual(base.initial, combined);
  for (let axis = 0; axis < 5; axis++) {
    const changedCoordinates = [...baseCoordinates];
    changedCoordinates[axis] = 1n;
    const changed = field.observe(packCoordinates(changedCoordinates, dimensions));
    assert.notDeepEqual(changed.wordUnits[axis], base.wordUnits[axis]);
    assert.notDeepEqual(changed.initial, base.initial);
    for (let other = 0; other < 5; other++)
      if (other !== axis) assert.deepEqual(changed.wordUnits[other], base.wordUnits[other]);
  }
  const manifest = sampleSlice(cfg).manifest;
  assert.match(manifest.generator.information, /800 bits into 160/);
  assert.match(manifest.generator.information, /not an injective embedding/);
  assert.equal(manifest.words.length, 5);
  assert(manifest.words.every((word) => word.unitBytes === 20));
  assert.equal(manifest.generator.arbitraryIndependentUnitStorage, false);
});

test("Evolution keeps the recipe fixed and zero coupling matches standalone cells", () => {
  const initial = sampleSlice(config({ size: 8, tick: "0" })),
    evolved = sampleSlice(config({ size: 8, tick: "1" }));
  assert.notDeepEqual(evolved.pixelBytes, initial.pixelBytes);
  assert.deepEqual(evolved.manifest.generator, initial.manifest.generator);
  assert.notDeepEqual(sampleSlice(config({ size: 8, seed: "14" })).pixelBytes, initial.pixelBytes);
  assert.deepEqual(
    sampleSlice(config({ size: 8, tick: "25", coupling: "0" })).pixelBytes,
    sampleSlice(config({ size: 8, tick: "25", mode: "cell" })).pixelBytes,
  );
});

test("Observation snapshots cannot corrupt cached trajectories", () => {
  const field = virtualField(config({ tick: "5" })),
    observation = field.observe(0n);
  const expected = { ...observation.state },
    expectedPartner = { ...observation.partnerState! };
  observation.state.q ^= 1n;
  observation.partnerState!.p ^= 1n;
  const replay = field.observe(0n);
  assert.deepEqual(replay.state, expected);
  assert.deepEqual(replay.partnerState, expectedPartner);
  assert.equal(replay.initialInvariant, replay.currentInvariant);
  assert(Object.isFrozen(field.config));
});

test("Public field metadata cannot change address or word interpretation", () => {
  const input = config({ tick: "5" }),
    field = virtualField(input),
    before = field.observe(0n);
  assert(Object.isFrozen(field.dimensions));
  assert(Object.isFrozen(field.generator));
  assert(Object.isFrozen(field.generator.parameters));
  assert(field.generator.parameters.every(Object.isFrozen));
  assert.equal(Reflect.set(field.dimensions, "0", 1n), false);
  assert.equal(Reflect.set(field.generator.parameters, "0", field.generator.parameters[1]), false);
  assert.equal(Reflect.set(field.generator.parameters[0], "aq", 0n), false);
  input.words[0] = "1";
  input.fixed[2] = "0";
  input.origin[0] = "7";
  const unit = field.generator.wordUnit(0, 0n),
    state = field.generator.stateAt(0n);
  unit[0] ^= 1;
  state.q ^= 1n;
  const replay = field.observe(0n);
  assert.deepEqual(replay.coords, before.coords);
  assert.deepEqual(replay.wordUnits, before.wordUnits);
  assert.deepEqual(replay.initial, before.initial);
  assert.deepEqual(replay.state, before.state);
  assert.deepEqual(field.dimensions, [64n, 64n, 8n, 8n, 8n]);
});

test("Hidden fixed entries on the slice axes normalize without blocking short words", () => {
  const cfg = config({ axes: [2, 3], words: ["64", "64", "1", "1", "8"], size: 1 });
  const validated = validateConfig(cfg);
  assert.deepEqual(validated.fixed, ["0", "0", "0", "0", "4"]);
  assert.deepEqual(cfg.fixed, ["0", "0", "2", "3", "4"]);
  assert.deepEqual(sampleSlice(cfg).cells[0].coords, [0n, 0n, 0n, 0n, 4n]);
  assert.throws(() => validateConfig({ ...cfg, fixed: ["0", "0", "2", "3", "8"] }));
  assert.throws(() => validateConfig({ ...cfg, fixed: ["0", "0", "-1", "3", "4"] }));
  assert.throws(() => validateConfig({ ...cfg, fixed: ["0", "0", "1.5", "3", "4"] }));
});

test("Word lengths, bounds and malformed arrays reject ambiguous configurations", () => {
  const patches = [
    { seed: "-1" },
    { tick: "4294967296" },
    { kappa: (1n << 80n).toString() },
    { coupling: "1.5" },
    { size: 64 },
    { couplingAxis: 5 },
    { axes: [1, 1] },
    { words: ["64", "64", "0", "8", "8"] },
    { words: ["64", "1.5", "8", "8", "8"] },
    { words: ["4", "64", "8", "8", "8"], size: 8 },
    { words: ["64", "64", "8", "8"] },
    { origin: ["63", "0"], size: 8 },
    { fixed: ["0", "0", "8", "0", "0"] },
  ];
  for (const patch of patches)
    assert.throws(() => validateConfig(config(patch as Partial<SliceConfig>)));
  assert.throws(() => validateConfig(config({ words: new Array<string>(5) as FiveStrings })));
  assert.throws(() => validateConfig(config({ fixed: new Array<string>(5) as FiveStrings })));
  assert.throws(() => validateConfig(config({ origin: new Array<string>(2) as [string, string] })));
  assert.throws(() =>
    validateConfig(config({ axes: [0, undefined] as unknown as [number, number] })),
  );
});
