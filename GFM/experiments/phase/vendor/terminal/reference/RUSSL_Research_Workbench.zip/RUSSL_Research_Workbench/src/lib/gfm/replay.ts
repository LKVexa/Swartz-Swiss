import { encodeTiff, encodeZip } from "./export.ts";
import { AXIS_NAMES } from "./penteract.ts";
import type { SliceResult } from "./penteract.ts";
import { EMPTY_WORD_SOURCES, importRawWord } from "./raw-words.ts";
import type { ImportedWord, WordSources, RawWordFormat } from "./raw-words.ts";

const encoder = new TextEncoder();
const PIXEL_PROFILE = "gfm-full-state-q80-p80-v1";

function record(value: unknown, label: string): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError(`${label} must be an object`);
  }
  return value as Record<string, unknown>;
}

function metadata(manifest: unknown) {
  const root = record(manifest, "Replay manifest");
  if (root.schema !== "RUSSL-five-word-cube/2" && root.schema !== "RUSSL-five-word-cube/3") {
    throw new TypeError("Unsupported replay manifest schema");
  }
  if (!Array.isArray(root.words) || root.words.length !== 5) {
    throw new TypeError("Replay manifest needs five word descriptors");
  }
  const words = Array.from(root.words, (word: unknown) => record(word, "Word descriptor"));
  const config = record(root.config, "Replay configuration");
  if (!Array.isArray(config.words) || config.words.length !== 5) {
    throw new TypeError("Replay configuration needs five word lengths");
  }
  const lengths = Array.from(config.words, (value: unknown) => {
    if (typeof value !== "string" || value.length > 1024 || !/^[1-9][0-9]*$/.test(value)) {
      throw new TypeError("Replay word lengths must be positive decimal integers");
    }
    return BigInt(value);
  });
  words.forEach((word) => {
    const allowed =
      word.source === "generated" ||
      (root.schema === "RUSSL-five-word-cube/2" && word.source === undefined);
    if (word.source !== "imported" && !allowed)
      throw new TypeError("Unknown replay word source kind");
    if (word.source === "imported" && root.schema !== "RUSSL-five-word-cube/3") {
      throw new TypeError("Imported words require a version 3 replay manifest");
    }
  });
  return { root, words, lengths };
}

function sourceEntry(axis: number): string {
  return `words/${axis}-${AXIS_NAMES[axis]}.bin`;
}

function importedDescriptor(word: Record<string, unknown>, axis: number) {
  if (word.entry !== sourceEntry(axis))
    throw new TypeError("Imported word entry does not match its expected axis path");
  if (word.sourceFormat !== "appliance-le" && word.sourceFormat !== "russl-be")
    throw new TypeError("Unsupported imported word format");
  if (typeof word.originalName !== "string")
    throw new TypeError("Imported word needs its original filename");
  if (
    typeof word.sourceBits !== "number" ||
    !Number.isSafeInteger(word.sourceBits) ||
    word.sourceBits < 1
  )
    throw new TypeError("Imported source bit count is invalid");
  if (
    typeof word.sourceByteLength !== "number" ||
    !Number.isSafeInteger(word.sourceByteLength) ||
    word.sourceByteLength < 1
  )
    throw new TypeError("Imported source byte count is invalid");
  if (
    typeof word.paddingBits !== "number" ||
    !Number.isInteger(word.paddingBits) ||
    word.paddingBits < 0 ||
    word.paddingBits > 159
  )
    throw new TypeError("Imported padding bit count is invalid");
  if (
    typeof word.unitCount !== "string" ||
    word.unitCount.length > 32 ||
    !/^[1-9][0-9]*$/.test(word.unitCount)
  )
    throw new TypeError("Imported unit count is invalid");
  if (word.unitProfile !== PIXEL_PROFILE)
    throw new TypeError("Imported word unit profile is unsupported");
  const hashes = [word.sourceSha256, word.canonicalSha256];
  if (hashes.some((value) => typeof value !== "string" || !/^[a-f0-9]{64}$/i.test(value)))
    throw new TypeError("Imported word hashes are invalid");
  return {
    entry: sourceEntry(axis),
    name: word.originalName,
    format: word.sourceFormat as RawWordFormat,
    sourceBits: word.sourceBits,
    sourceByteLength: word.sourceByteLength,
    paddingBits: word.paddingBits,
    unitCount: BigInt(word.unitCount),
    sourceSha256: String(word.sourceSha256).toLowerCase(),
    canonicalSha256: String(word.canonicalSha256).toLowerCase(),
  };
}

function compareSource(
  source: ImportedWord,
  word: Record<string, unknown>,
  axis: number,
  length: bigint,
) {
  const declared = importedDescriptor(word, axis);
  if (
    source.name !== declared.name ||
    source.format !== declared.format ||
    source.sourceBits !== declared.sourceBits ||
    source.sourceByteLength !== declared.sourceByteLength ||
    source.paddingBits !== declared.paddingBits ||
    source.unitCount !== declared.unitCount ||
    source.unitCount !== length ||
    source.sha256 !== declared.sourceSha256 ||
    source.canonicalSha256 !== declared.canonicalSha256
  ) {
    throw new Error(`Imported ${AXIS_NAMES[axis]} source differs from the replay descriptor`);
  }
  return declared;
}

/** Includes original imported bytes; virtual-only bundles retain the original four entries. */
export function createReplayBundle(
  slice: SliceResult,
  manifest: unknown,
  sources: WordSources | null,
  stem: string,
): Uint8Array {
  const meta = metadata(manifest);
  if (
    typeof stem !== "string" ||
    !stem ||
    stem.length > 255 ||
    Array.from(stem).some((character) => {
      const code = character.charCodeAt(0);
      return (
        code < 32 || code === 127 || character === "/" || character === "\\" || character === ":"
      );
    }) ||
    stem === "." ||
    stem === ".."
  )
    throw new TypeError("Replay filename stem must be a safe basename");
  if (sources !== null && (!Array.isArray(sources) || sources.length !== 5))
    throw new TypeError("Replay needs exactly five source slots");
  if (sources !== null && Array.from(sources).some((source) => source === undefined))
    throw new TypeError("Replay source slots cannot be sparse or undefined");
  const extra: { name: string; bytes: Uint8Array }[] = [];
  meta.words.forEach((word, axis) => {
    const source = sources?.[axis] ?? null;
    if (word.source === "imported") {
      if (source === null) throw new Error(`Missing original imported ${AXIS_NAMES[axis]} bytes`);
      compareSource(source, word, axis, meta.lengths[axis]);
      extra.push({ name: sourceEntry(axis), bytes: source.bytes() });
    } else if (source !== null) {
      throw new Error(`Imported ${AXIS_NAMES[axis]} bytes cannot be exported as a generated word`);
    }
  });
  const description = JSON.stringify(manifest, null, 2);
  const readme =
    "RUSSL five-word cube replay\n\nPixel160=(q<<80)|p retains both complete 80-bit cell coordinates.\nThe TIFF contains five uint32 pages L4..L8 and the JSON manifest. pixel160.bin is the same row-major state payload, five BE32 lanes per cell.\nThe manifest records dimensions, mixed-radix addressing, fixed evolution law, tick and source-unit witnesses.\nImported source files are preserved in words/{axis}-{axisname}.bin with original filename, format, bit count, padding, SHA-256 and canonical hash in manifest.json.\nNative appliance words use the declared little-endian adapter; russl-be sources contain canonical 20-byte units. Only the final native unit may be zero padded.\nGenerated axes are reproduced from the declared seed recipe. A missing or altered imported file must be rejected; it must never be regenerated from that recipe.\nThe five word units combine into one cell using a declared 800-to-160-bit recipe. This is not an injective embedding of arbitrary input words.\nSHA-256 pixelPayloadBE covers pixel160.bin, not the TIFF container.\n";
  return encodeZip([
    {
      name: `${stem}.tiff`,
      bytes: encodeTiff(slice.pixels, slice.config.size, slice.config.size, manifest),
    },
    { name: "manifest.json", bytes: encoder.encode(description) },
    { name: "pixel160.bin", bytes: slice.pixelBytes },
    { name: "README.txt", bytes: encoder.encode(readme) },
    ...extra,
  ]);
}

/** Reimports and rehashes every original source before any replay can use it. */
export async function restoreWordSources(
  manifest: unknown,
  readEntry: (name: string) => Uint8Array | undefined,
): Promise<WordSources> {
  const meta = metadata(manifest);
  const slots: [
    ImportedWord | null,
    ImportedWord | null,
    ImportedWord | null,
    ImportedWord | null,
    ImportedWord | null,
  ] = [null, null, null, null, null];
  for (let axis = 0; axis < 5; axis++) {
    const word = meta.words[axis];
    if (word.source !== "imported") continue;
    const declared = importedDescriptor(word, axis);
    const bytes = readEntry(declared.entry);
    if (!(bytes instanceof Uint8Array))
      throw new Error(`Missing original imported ${AXIS_NAMES[axis]} file`);
    if (bytes.byteLength !== declared.sourceByteLength)
      throw new Error(`Imported ${AXIS_NAMES[axis]} byte count differs from the manifest`);
    const source = await importRawWord(bytes, {
      name: declared.name,
      format: declared.format,
      sourceBits: declared.sourceBits,
    });
    compareSource(source, word, axis, meta.lengths[axis]);
    slots[axis] = source;
  }
  return slots.every((source) => source === null) ? EMPTY_WORD_SOURCES : Object.freeze(slots);
}
