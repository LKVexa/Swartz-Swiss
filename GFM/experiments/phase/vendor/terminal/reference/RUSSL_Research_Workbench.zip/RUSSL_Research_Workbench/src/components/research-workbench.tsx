import { useCallback, useEffect, useRef, useState } from "react";
import { GfmWorkbench } from "@/components/gfm-workbench";
import type { SliceResult } from "@/lib/gfm/penteract";
import { createResearchSnapshot, replayResearchSlice } from "@/lib/gfm/research-bridge";
import terminalHtml from "@/lib/research-terminal/terminal.html?raw";

const PROTOCOL = "RUSSL-research-adapter/1";
const MAX_DIGEST_BYTES = 4 * 1024 * 1024;
const tabClass = "min-h-11 border border-rule px-4 py-2 font-mono text-sm text-ink";

export function ResearchWorkbench() {
  const [view, setView] = useState<"words" | "research">("words");
  const [researchMounted, setResearchMounted] = useState(false);
  const [activeSlice, setActiveSlice] = useState<SliceResult | null>(null);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const receiveSlice = useCallback((slice: SliceResult, index: number) => {
    setActiveSlice(slice);
    setSelectedIndex(index);
  }, []);
  const frame = useRef<HTMLIFrameElement>(null);
  const inFlight = useRef(false);
  useEffect(() => {
    async function receive(event: MessageEvent) {
      const data = event.data;
      if (
        !frame.current ||
        event.source !== frame.current.contentWindow ||
        !data ||
        data.protocol !== PROTOCOL ||
        typeof data.id !== "string" ||
        !/^[A-Za-z0-9_-]{1,80}$/.test(data.id)
      )
        return;
      const target = event.source as Window;
      function answer(response: object) {
        target.postMessage({ protocol: PROTOCOL, id: data.id, ...response }, "*");
      }
      if (inFlight.current) {
        answer({ ok: false, error: "A slice request is already running." });
        return;
      }
      inFlight.current = true;
      try {
        if (data.method === "snapshot") {
          if (!activeSlice) throw new Error("The word workbench is still loading.");
          answer({
            ok: true,
            value: createResearchSnapshot(activeSlice, { selectedIndex, inverseWitness: true }),
          });
        } else if (data.method === "replay") {
          if (JSON.stringify(data.snapshot).length > 2 * 1024 * 1024)
            throw new Error("The research slice exceeds its bounded record size.");
          const replay = replayResearchSlice(data.snapshot);
          const digest = await crypto.subtle.digest(
            "SHA-256",
            new Uint8Array(replay.pixelBytes).buffer,
          );
          const hash = Array.from(new Uint8Array(digest), (v) =>
            v.toString(16).padStart(2, "0"),
          ).join("");
          const declaredHash = replay.checks.declaredPixelPayloadSha256;
          if (declaredHash !== null && declaredHash !== hash)
            throw new Error("The slice payload hash does not match its manifest.");
          answer({
            ok: true,
            value: {
              schema: "RUSSL-research-result/1",
              bridgeVersion: "1",
              field: "GF(2^80)",
              valid: replay.valid,
              config: replay.config,
              pixelCount: replay.cells.length,
              pixelPayloadSHA256: hash,
              checks: { ...replay.checks, declaredPixelPayloadHashVerified: declaredHash !== null },
              sourceHashScope: replay.sourceHashScope,
              ...(replay.selected ? { selected: replay.selected } : {}),
            },
          });
        } else if (data.method === "digest" || data.method === "digest-bytes") {
          let bytes: Uint8Array;
          if (data.method === "digest") {
            if (typeof data.text !== "string" || data.text.length > MAX_DIGEST_BYTES)
              throw new Error("The research record exceeds its bounded hash size.");
            bytes = new TextEncoder().encode(data.text);
            if (bytes.byteLength > MAX_DIGEST_BYTES)
              throw new Error("The research record exceeds its bounded hash size.");
          } else {
            if (
              typeof data.hex !== "string" ||
              data.hex.length > 2 * 1024 * 1024 ||
              data.hex.length % 2 !== 0 ||
              !/^[0-9a-f]*$/i.test(data.hex)
            )
              throw new Error("Invalid bounded byte payload for hashing.");
            bytes = Uint8Array.from(data.hex.match(/../g) ?? [], (byte: string) =>
              parseInt(byte, 16),
            );
          }
          const digest = await crypto.subtle.digest("SHA-256", new Uint8Array(bytes).buffer);
          answer({
            ok: true,
            value: Array.from(new Uint8Array(digest), (v) => v.toString(16).padStart(2, "0")).join(
              "",
            ),
          });
        } else throw new Error("Unsupported research adapter request.");
      } catch (error) {
        answer({ ok: false, error: error instanceof Error ? error.message : String(error) });
      } finally {
        inFlight.current = false;
      }
    }
    window.addEventListener("message", receive);
    return () => window.removeEventListener("message", receive);
  }, [activeSlice, selectedIndex]);
  return (
    <div className="mt-6">
      <div role="tablist" aria-label="Workbench views" className="flex flex-wrap gap-2">
        <button
          type="button"
          role="tab"
          id="word-view-tab"
          aria-selected={view === "words"}
          aria-controls="word-view"
          className={tabClass + (view === "words" ? " border-signal" : "")}
          onClick={() => setView("words")}
        >
          Word dynamics
        </button>
        <button
          type="button"
          role="tab"
          id="research-view-tab"
          aria-selected={view === "research"}
          aria-controls="research-view"
          className={tabClass + (view === "research" ? " border-signal" : "")}
          onClick={() => {
            setResearchMounted(true);
            setView("research");
          }}
        >
          Research terminal
        </button>
      </div>
      <div
        id="word-view"
        role="tabpanel"
        aria-labelledby="word-view-tab"
        hidden={view !== "words"}
        className="mx-auto max-w-3xl"
      >
        <GfmWorkbench onResearchSlice={receiveSlice} />
      </div>
      <div
        id="research-view"
        role="tabpanel"
        aria-labelledby="research-view-tab"
        hidden={view !== "research"}
      >
        <p className="my-3 text-sm text-muted">
          Research laboratories, source evidence and replayable records. Open RUSSL word dynamics
          inside the terminal to record the current Pixel160 slice. Your imported words remain
          loaded.
        </p>
        {researchMounted ? (
          <iframe
            ref={frame}
            title="GFM research terminal"
            srcDoc={terminalHtml}
            sandbox="allow-scripts allow-downloads"
            className="h-[1050px] w-full border border-rule"
          />
        ) : null}
        <p className="mt-2 text-xs text-muted">
          The terminal session stays in memory. Export its JSON records to preserve them. Replay
          records contain bounded source witnesses; complete original words remain in the TIFF
          replay bundle.
        </p>
      </div>
    </div>
  );
}
