import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/spec-B2N2j0lU.js
var import_jsx_runtime = require_jsx_runtime();
/** v0.9.0-chat — the prose stack, verbatim, before this audit. */
var V0_PROSE = `Stack now
1. Bit/anti-bit toy model, written up. Separate from every “bit” below.
2. p-adic geometry that is actually mathematics. The 2-adic NPU plan for LAMB stays rejected.
3. 1-bit LAMB: training compression only. Execution path, if any, is packed signs, frozen vvv, ReduceScatter then average then AllGather. Unikernel is optional and painful. Not ternary weights.
4. Inference compression: GPTQ, AWQ, SmoothQuant, MX, KV FP8, BitNet. Different layer of the stack.
5. Optics to treat as buildable: ASM, double phase or GS, LUT, TIFF float in, 8-bit frame out, temporal focusing if the spots must be 3D. D2NN as a trained linear (or weakly nonlinear) map.
6. HRR as algebra: convolution, cleanup, permutation for order, SSP for continuous variables. Optical only at the convolution step, and only if a directive says so.
7. Storage: BigTIFF / COG / OME-TIFF / OME-Zarr, with the chunk-axis tradeoff explicit. Not the hybrid format with private tags.
8. GIF the quantum frame: a bookkeeping trick for pump depletion and Wigner negativity in pulsed squeezing. No role in the file path.
9. IdeaPad note and the neurophotonics survey: reference material, not subsystems of the hologram pipeline.`;
var V0_VERSION = "0.9.0-chat";
var V1_VERSION = "1.0.0";
function parseNumberedProse(text) {
	const body = text.replace(/^\s*Stack now\s*/i, "").trim();
	if (!body) return [];
	const parts = body.split(/\n(?=\d+\.\s)/);
	const clauses = [];
	for (const part of parts) {
		const match = part.match(/^(\d+)\.\s+([\s\S]*)$/);
		if (!match) throw new Error(`Unparsed clause: ${part.slice(0, 48)}`);
		clauses.push({
			n: Number(match[1]),
			body: match[2].replace(/\s+/g, " ").trim()
		});
	}
	return clauses;
}
function clause(items, n) {
	return items.find((item) => item.n === n)?.body ?? "";
}
/** What v0.9.0-chat still left loose, mistyped, or easy to misuse. */
function auditProse(items) {
	const findings = [];
	const c3 = clause(items, 3);
	const c5 = clause(items, 5);
	const c6 = clause(items, 6);
	const c8 = clause(items, 8);
	const c9 = clause(items, 9);
	if (/vvv/.test(c3)) findings.push({
		id: "F1",
		kind: "fix",
		layer: "train.one-bit-lamb",
		title: "Second moment is v, not vvv",
		detail: "The v0 line froze “vvv”. That is a typesetting collision, not a tensor. The frozen object is the second-moment vector v."
	});
	findings.push({
		id: "F2",
		kind: "harden",
		layer: "math.padic",
		title: "Name the rejection, keep the mathematics",
		detail: "v0 already refuses the 2-adic NPU. v1 files that refusal as rej.2adic-npu so the number theory can be cited without importing sign-as-unit-sphere, majority-vote reduction, or the essay’s energy figures."
	});
	if (/Unikernel/.test(c3)) findings.push({
		id: "F3",
		kind: "harden",
		layer: "train.one-bit-lamb",
		title: "Unikernel leaves the numerical contract",
		detail: "v0 put the unikernel on the execution path and then called it optional. v1 deletes it from the contract. Any host may run the same tensors. The contract is the warmup, the freeze, the mask, the error buffer, and ReduceScatter → average → AllGather."
	});
	findings.push({
		id: "F4",
		kind: "fix",
		layer: "infer.quant",
		title: "Pin the KV worked example",
		detail: "v0 named “KV FP8” and did not pin a size. The quantization essay’s 135 GB for Llama-70B at one million tokens, FP16, does not match the formula. v1 uses 2·80·8·128·10⁶·2 = 327,680,000,000 bytes."
	});
	findings.push({
		id: "F5",
		kind: "upgrade",
		layer: "infer.quant",
		title: "Forbid the cross-layer substitution",
		detail: "v0 said the inference layer is different and that 1-bit LAMB is not ternary weights. v1 states the denied edge: a momentum sign stream is not a weight format, and BitNet b1.58 is not 1-bit LAMB."
	});
	if (/weakly nonlinear/.test(c5)) findings.push({
		id: "F6",
		kind: "harden",
		layer: "optics.field",
		title: "A linear stack is one map",
		detail: "“Trained linear (or weakly nonlinear)” reads as permission to stack masks and call it depth. Cascaded linear diffraction is exactly one linear transform. Depth counts only with a real nonlinearity. A four-pattern sorter is not an ALU."
	});
	if (/cleanup/.test(c6) && !/mandatory|required/.test(c6)) findings.push({
		id: "F7",
		kind: "harden",
		layer: "algebra.hrr",
		title: "Cleanup is fail-closed",
		detail: "v0 listed cleanup. v1 makes the layer invalid without it. Circular correlation returns a noisy vector. The symbol is the nearest codeword, or there is no symbol."
	});
	findings.push({
		id: "F8",
		kind: "upgrade",
		layer: "storage.containers",
		title: "The four containers are not substitutes",
		detail: "v0 named BigTIFF, COG, OME-TIFF, and OME-Zarr and the chunk-axis tradeoff. v1 adds the selection rule: they answer different queries. A float hologram is not a GeoTIFF and not a Zarr until someone writes that conversion."
	});
	if (/^GIF\b/.test(c8)) findings.push({
		id: "F9",
		kind: "harden",
		layer: "ref.gaussian-interaction-frame",
		title: "Retire the bare token GIF",
		detail: "v0’s layer title is “GIF the quantum frame”. That token already means GIF89a. v1’s layer id is ref.gaussian-interaction-frame. GIF89a stays in the homonym ledger and is not a compute layer."
	});
	if (/IdeaPad/.test(c9) && /neurophotonics/.test(c9)) findings.push({
		id: "F10",
		kind: "upgrade",
		layer: "ref.neurophotonics",
		title: "Split the reference bin",
		detail: "v0 taped the IdeaPad note to the neurophotonics survey. v1 splits them. The only sentence that may inform optics is the 3D-SHOT axial constraint. Nothing else in either note is a subsystem."
	});
	findings.push({
		id: "F11",
		kind: "harden",
		layer: "lexicon",
		title: "Homonym ledger is normative",
		detail: "The failure mode across the source essays was shared words: bit, holographic, GIF, RAM sampling. v0 handled this in prose. v1 fails validation if a layer id or a normative claim uses one of those words without a qualifier."
	});
	findings.push({
		id: "F12",
		kind: "upgrade",
		layer: "spec",
		title: "Semver, starting at 1.0.0",
		detail: "0.9.0-chat was an unparsed list. 1.0.0 is the first document with a schema, invariants, denied edges, and a version policy. Major: a status change or a newly allowed edge. Minor: an added invariant. Patch: a citation or a worked number."
	});
	return findings;
}
var BARE_GIF = /\bGIF\b/;
function validateSpec(spec) {
	const violations = [];
	const ids = /* @__PURE__ */ new Set();
	if (spec.version !== "1.0.0") violations.push(`version ${spec.version} is not ${V1_VERSION}`);
	if (spec.previous !== "0.9.0-chat") violations.push(`previous ${spec.previous} is not ${V0_VERSION}`);
	if (spec.llama70bFp16KvBytes !== 32768e7) violations.push("KV worked example is not 327680000000 bytes");
	for (const layer of spec.layers) {
		if (ids.has(layer.id)) violations.push(`duplicate id ${layer.id}`);
		ids.add(layer.id);
		if (layer.id === "gif" || /(^|\.)gif($|\.)/.test(layer.id)) violations.push(`bare GIF id: ${layer.id}`);
		const blob = `${layer.title}\n${layer.summary}\n${layer.invariants.join("\n")}`;
		if (BARE_GIF.test(blob)) violations.push(`${layer.id} uses the bare token GIF`);
		if (/\bholographic\b/i.test(blob)) {
			const namedHrr = layer.id === "algebra.hrr" && /reduced representation/i.test(layer.title);
			const opticalHome = layer.id === "optics.field";
			if (!namedHrr && !opticalHome) violations.push(`${layer.id} uses “holographic” outside its two named homes`);
		}
		if (layer.id === "train.one-bit-lamb") {
			const contract = layer.invariants.join(" ");
			if (!/ReduceScatter/.test(contract)) violations.push("1-bit LAMB contract dropped ReduceScatter");
			if (/majority vote/i.test(contract)) violations.push("1-bit LAMB contract contains majority vote");
			if (/unikernel/i.test(contract)) violations.push("unikernel leaked back into the LAMB contract");
			if (/vvv/.test(contract)) violations.push("vvv survived in the LAMB contract");
		}
		if (layer.id === "optics.field") {
			const contract = layer.invariants.join(" ");
			if (!/one linear/.test(contract)) violations.push("optics contract lost the linear-collapse rule");
			if (/zero energy|speed of light/i.test(contract)) violations.push("optics contract repeats a zero-energy claim");
		}
		if (layer.id === "algebra.hrr") {
			if (!layer.invariants.some((line) => /mandatory/i.test(line))) violations.push("HRR cleanup is not mandatory");
		}
	}
	for (const edge of spec.edges) if (!ids.has(edge.from) || !ids.has(edge.to)) violations.push(`edge ${edge.from} → ${edge.to} names an unknown layer`);
	for (const hom of spec.homonyms) if (hom.senses.length < 2) violations.push(`homonym ${hom.token} has fewer than two senses`);
	const allowed = spec.edges.filter((edge) => edge.allow);
	const denied = spec.edges.filter((edge) => !edge.allow);
	if (allowed.length < 2) violations.push("allowed-edge list collapsed");
	if (!denied.some((edge) => edge.from === "math.padic" && edge.to === "train.one-bit-lamb")) violations.push("p-adic → LAMB denial missing");
	if (!denied.some((edge) => edge.from === "ref.gaussian-interaction-frame" && edge.to === "storage.containers")) violations.push("interaction-frame → storage denial missing");
	return violations;
}
var STACK = {
	version: "1.0.0",
	previous: "0.9.0-chat",
	llama70bFp16KvBytes: 32768e7,
	homonyms: [
		{
			token: "bit",
			senses: [
				{
					name: "BMV bit / anti-bit sector",
					livesIn: "closed.bit-antibit"
				},
				{
					name: "1-bit LAMB momentum sign",
					livesIn: "train.one-bit-lamb"
				},
				{
					name: "Ternary weight in {−1, 0, 1}",
					livesIn: "infer.quant"
				},
				{
					name: "Machine bit in Z/2^n Z",
					livesIn: "math.padic"
				},
				{
					name: "Positional digit in an OAM shift demo",
					livesIn: "optics.field"
				}
			]
		},
		{
			token: "holographic",
			senses: [
				{
					name: "Complex optical field, CGH, ASM",
					livesIn: "optics.field"
				},
				{
					name: "Plate HRR, circular convolution",
					livesIn: "algebra.hrr"
				},
				{
					name: "AdS/CFT or HaPPY tensor network",
					livesIn: "lexicon only — not a layer"
				}
			]
		},
		{
			token: "GIF",
			senses: [{
				name: "GIF89a paletted byte stream",
				livesIn: "lexicon only — not a layer"
			}, {
				name: "Gaussian interaction frame",
				livesIn: "ref.gaussian-interaction-frame"
			}]
		},
		{
			token: "RAM sampling",
			senses: [
				{
					name: "PEBS / perf on a hybrid Intel laptop",
					livesIn: "ref.ideapad"
				},
				{
					name: "Audio direct-from-disk preload",
					livesIn: "ref.ideapad"
				},
				{
					name: "Live forensic memory image",
					livesIn: "ref.ideapad"
				},
				{
					name: "DRAM stress, Rowhammer, on-die ECC",
					livesIn: "ref.ideapad"
				},
				{
					name: "DMA of an optical field",
					livesIn: "rejected — not this stack"
				}
			]
		}
	],
	layers: [
		{
			id: "closed.bit-antibit",
			n: "01",
			title: "Bit / anti-bit",
			status: "closed",
			summary: "Bose–Marletto–Vedral toy theory. Two classical sectors sit inside one quantum message. Product observables miss a global sector phase, so the tomography is non-local. The witness is the five-swap protocol. This layer is an explanation of that loophole. It is not a wire, a weight, or a sign.",
			invariants: [
				"A sector label is not a voltage and not a sign bit.",
				"The anti-bit is not bitwise complement, not two’s-complement −1, and not an HRR involution.",
				"No other layer may import this one."
			],
			rejects: ["Using the toy model as a memory cell, a quantizer, or a 2-adic negation."]
		},
		{
			id: "math.padic",
			n: "02",
			title: "p-adic geometry",
			status: "normative",
			summary: "The normative object is Q_p and the ring of p-adic integers. Ultrametric inequality, Hensel lifting of units, the Monna map, Kozyrev wavelets, the Vladimirov operator, and the Bruhat–Tits tree are mathematics. The only hardware sentence allowed: an n-bit two’s-complement word is Z/2^n Z, the truncation of the 2-adic integers. That licenses exact inversion of odd denominators. It does not license an optimizer.",
			invariants: [
				"Odd modular inverses via Hensel lifting are exact in Z/2^n Z.",
				"Carry runs from low significance to high. That is a statement about the ring, not about gradient descent.",
				"The Monna map is a named bridge to a Euclidean grid. It is not an encoding of model weights."
			],
			rejects: ["rej.2adic-npu. sign of a real momentum is not a projection onto the 2-adic unit group. The residual against a signed scale is a real vector, not an element of the maximal ideal. Majority vote of signs is not the 1-bit LAMB reducer. Picojoule and gate-count figures in that essay are not measurements."]
		},
		{
			id: "train.one-bit-lamb",
			n: "03",
			title: "1-bit LAMB",
			status: "normative",
			summary: "Training-time communication compression (Li, Awan, Tang, Rajbhandari, He). LAMB’s layer ratio is a norm of a norm; Adam-style variance is nonlinear. Both facts break naive 1-bit error feedback. The repair is a warmup, a freeze, a mask, and a soft threshold. This is not an inference format.",
			invariants: [
				"Warmup runs full-precision LAMB and tracks a moving average of the layer scale.",
				"At the freeze step, store v and that average. Do not quantize the gradient that updates v.",
				"After the freeze, communicate the sign of momentum plus the local error, with a scale. Write the residual back into the error buffer.",
				"Coordinates with a structural zero gradient stay masked at zero. The sign code cannot represent 0.",
				"Collective: ReduceScatter of packed signs and scales, decompress and average on the shard, requantize, AllGather.",
				"Clamp the layer ratio to a band around the frozen average, then apply the outer clamp.",
				"The error buffer is per rank and the size of the parameter tensor. A checkpoint keeps every copy or drops the buffer. Dropping it changes the trajectory."
			],
			rejects: [
				"Majority vote or popcount as the reducer.",
				"Feeding a quantized gradient into v.",
				"One global freeze when layers plateau at different times, without the soft threshold.",
				"Averaging error buffers across ranks.",
				"Treating a unikernel, a columnar allocator, or a 2-adic ALU as part of this contract."
			]
		},
		{
			id: "infer.quant",
			n: "04",
			title: "Inference compression",
			status: "normative",
			summary: "Serving formats. They cut bytes so a memory-bound kernel moves right on the roofline. They do not compress the training collective in layer 03, and they do not accept its sign stream as weights.",
			invariants: [
				"GPTQ compensates a rounded weight using the inverse Hessian of the layer output error. In that local problem the Hessian is the uncentered activation covariance.",
				"AWQ scales up channels that see large activations, then rounds.",
				"SmoothQuant moves outlier scale from activations onto weights with a per-channel factor, then quantizes both.",
				"OCP microscaling, v1.0: blocks of 32 share one E8M0 power-of-two scale. MXFP4’s element is sign, 2 exponent bits, 1 mantissa bit, about 4.25 bits with the scale.",
				"BitNet b1.58 trains weights in {−1, 0, 1}. Post-training ternarization is a different method. Stored checkpoints include scales, so the file is wider than 1.58 bits.",
				"KV cache bytes = 2 · layers · kv-heads · head-dim · tokens · bytes-per-element. Llama-70B, FP16, 10^6 tokens: 80, 8, 128, two bytes → 327,680,000,000 bytes.",
				"FP8 on the cache halves that footprint. The cache tolerates it better than the weights do, because attention normalizes. That is not a license to quantize the weights the same way."
			],
			rejects: [
				"The essay figure of 135 GB for that Llama-70B cache.",
				"Substituting 1-bit LAMB signs for GPTQ, AWQ, MX, or BitNet weights.",
				"Treating the Horowitz-style picojoule table in the source essay as the 2014 measurements. It is a sketch, and a DRAM access without a width is not a number."
			]
		},
		{
			id: "optics.field",
			n: "05",
			title: "Optical field path",
			status: "normative",
			summary: "How a complex scalar field is propagated, encoded onto a phase panel, and stored. Computer-generated holography and a diffractive stack live here. Plate’s algebra does not, except for one gated convolution.",
			invariants: [
				"Propagator for parallel planes: angular spectrum. FFT, multiply by the exact longitudinal phase, inverse FFT.",
				"A phase-only panel needs Gerchberg–Saxton, or double phase. Double phase spends two panel pixels on one complex sample.",
				"Panel codes pass through a measured look-up table. Phase is not linear in the 8-bit code.",
				"While the field is still a field, keep floats. Uncompressed TIFF is a legal container. The panel is fed pixels, not a compressed file.",
				"Maximum diffraction angle scales as wavelength over pixel pitch.",
				"A holographic spot’s axial thickness grows with its lateral size. A thin spot at an arbitrary depth needs temporal focusing. That is the only import from the neurophotonics note.",
				"Cascaded linear masks are one linear map. Depth requires a real nonlinearity.",
				"Energy sits in the source, the panel drive, the detectors, and any absorber. Free-space propagation does not erase bits and does not repeal a Landauer cost at the detector."
			],
			rejects: [
				"A trained four-input sorter described as a logic family or a Turing machine.",
				"LZW, GIF89a, or a private TIFF tag as the panel interface.",
				"Orbital-angular-momentum spot shifting described as a general multiplier. A sideways route of beams is multiplication by the base only, with no carry.",
				"Rotating one phase plate and calling the result an instruction set."
			]
		},
		{
			id: "algebra.hrr",
			n: "06",
			title: "Holographic reduced representation",
			status: "normative",
			summary: "Plate’s fixed-width vector algebra. Binding is circular convolution. The representation is holographic only in that every coordinate carries every binding. It is not an optical recording.",
			invariants: [
				"Atoms are drawn independently in high dimension and are quasi-orthogonal.",
				"Bundle by addition. Bind by circular convolution, via an FFT.",
				"Unbind by circular correlation, which is convolution with the involution. The result is noisy.",
				"Cleanup against the item memory is mandatory. Without a nearest codeword there is no symbol.",
				"Convolution commutes. Sequence is a fixed permutation applied before the bind, or it is invisible.",
				"Continuous quantities use fractional binding. They do not replace random atoms.",
				"An optical Fourier stage may implement the convolution and nothing else, and only under an explicit directive. It does not implement cleanup, the lexicon, or the permutation."
			],
			rejects: ["Identifying this layer with a spatial-light-modulator hologram, a diffractive network, or a bulk reconstruction code.", "Reading an XOR of binary hypervectors as a saturable absorber."]
		},
		{
			id: "storage.containers",
			n: "07",
			title: "Containers",
			status: "normative",
			summary: "Pick the container by the query. These four names are not interchangeable, and none of them is a p-adic tree.",
			invariants: [
				"TIFF: image-file directories, 12-byte entries, magic 42, 32-bit offsets. Hard stop at 4 GiB.",
				"BigTIFF: magic 43, 64-bit offsets, 20-byte entries. Use it when one TIFF would cross 4 GiB.",
				"Cloud Optimized GeoTIFF: directories at the front, internal tiles, overviews, read by range request. It answers 2D windows. PixelIsArea versus PixelIsPoint is a half-pixel shift if missed.",
				"OME-TIFF: one plane per directory, the 5D index in OME-XML on tag 270 of the first directory. Dimension order says which axis runs fastest. Multi-file sets repeat the XML. Pyramids live in subdirectories.",
				"OME-Zarr: one object per chunk. A chunk long in time makes a time series cheap and a single plane expensive. The hot axis is the chunk axis. There is no neutral shape."
			],
			rejects: [
				"Private tags, stream-cipher payloads, or a hybrid that is not one of the formats above.",
				"Storing a working optical field as GIF89a.",
				"Treating a GeoTIFF, an OME-TIFF, and a Zarr as drop-in copies of the same array."
			]
		},
		{
			id: "ref.gaussian-interaction-frame",
			n: "08",
			title: "Gaussian interaction frame",
			status: "reference",
			summary: "Yanagimoto, Ng, and coauthors, Optica 2022. A bookkeeping split for pulsed squeezing once the pump depletes. The Gaussian unitary carries displacement and squeezing. The residual state carries the non-Gaussian part, including Wigner negativity. No file format, no panel, no training collective.",
			invariants: [
				"The lab state factors as a time-dependent Gaussian unitary times a residual.",
				"Choosing that unitary so the interaction-frame Hamiltonian has no linear or quadratic piece pins the residual at the origin of phase space.",
				"The pump’s equation of motion gains a back-action term. That is how particle number survives, which the undepleted-pump approximation gives up.",
				"A few principal supermodes, often kept as a matrix-product state, are a numerical basis for the residual. They are not optical “neurons”."
			],
			rejects: ["Any edge into storage, the panel path, or the training compressor.", "Using the bare word GIF as this layer’s name."]
		},
		{
			id: "ref.ideapad",
			n: "09a",
			title: "IdeaPad memory note",
			status: "reference",
			summary: "Four laptop operations share a name with an optical DMA that is not in this stack. Performance counters, sample-library preload, a live memory image, and DRAM stress. Useful only if the question is that machine.",
			invariants: [
				"Precise load-latency events exist on the performance cores. The efficiency cores do not implement the same counters.",
				"DDR5 on-die ECC corrects a single-bit cell fault inside the die and does not report it. A clean memory test does not prove healthy cells.",
				"A Windows virtualization-based dump is the normal world. The secure world comes back empty."
			],
			rejects: ["Importing any of these procedures as a stage of the optical path or the training collective."]
		},
		{
			id: "ref.neurophotonics",
			n: "09b",
			title: "Neurophotonics survey",
			status: "reference",
			summary: "Opsins, scanless two-photon stimulation, deep-tissue transducers, synaptic barcodes, and super-resolution of the synapse. A literature crib. One sentence is copied into the optical contract; the rest stays here.",
			invariants: [
				"The copied sentence: axial confinement of a wide computer-generated spot collapses as the spot grows laterally. Temporal focusing is the countermeasure. It already lives in optics.field.",
				"Channelrhodopsin variants, upconversion particles, sono-optogenetic particles, and X-ray scintillators are stimulation methods, not compute elements.",
				"The trans-synaptic nanocolumn and the spine-neck result from STED are anatomy. Synaptic MEMOIR is recent enough to treat as provisional."
			],
			rejects: ["A “biological holography” subsystem.", "Any further edge into optics.field, storage, or the algebras."]
		}
	],
	edges: [
		{
			from: "optics.field",
			to: "storage.containers",
			allow: true,
			relation: "A float field may be written as TIFF or BigTIFF, or as an OME plane if it is one slice of a stack."
		},
		{
			from: "ref.neurophotonics",
			to: "optics.field",
			allow: true,
			relation: "Only the axial-confinement fact. Already inlined. Do not add a second copy."
		},
		{
			from: "algebra.hrr",
			to: "optics.field",
			allow: true,
			relation: "Directive-gated. Convolution only. No cleanup, no lexicon, no permutation."
		},
		{
			from: "math.padic",
			to: "train.one-bit-lamb",
			allow: false,
			relation: "rej.2adic-npu. No Hensel datapath for layer norms or sign residuals."
		},
		{
			from: "train.one-bit-lamb",
			to: "infer.quant",
			allow: false,
			relation: "A momentum sign is not a weight. BitNet is not 1-bit LAMB."
		},
		{
			from: "infer.quant",
			to: "train.one-bit-lamb",
			allow: false,
			relation: "GPTQ, AWQ, SmoothQuant, and MX do not replace the freeze-and-sign collective."
		},
		{
			from: "closed.bit-antibit",
			to: "train.one-bit-lamb",
			allow: false,
			relation: "Sector bits are not signs and not weights."
		},
		{
			from: "ref.gaussian-interaction-frame",
			to: "storage.containers",
			allow: false,
			relation: "The interaction frame is not a file format."
		},
		{
			from: "ref.gaussian-interaction-frame",
			to: "optics.field",
			allow: false,
			relation: "Pump-depletion bookkeeping is not a hologram encoder."
		},
		{
			from: "ref.ideapad",
			to: "optics.field",
			allow: false,
			relation: "Laptop memory operations are not optical DMA."
		},
		{
			from: "algebra.hrr",
			to: "storage.containers",
			allow: false,
			relation: "A hypervector is not an image directory. Do not store it as a GIF."
		}
	]
};
var parsed = parseNumberedProse(V0_PROSE);
var findings = auditProse(parsed);
var violations = validateSpec(STACK);
var KIND_LABEL = {
	fix: "Fix",
	upgrade: "Upgrade",
	harden: "Harden"
};
function countKind(kind) {
	return findings.filter((finding) => finding.kind === kind).length;
}
var bytes = STACK.llama70bFp16KvBytes;
var gigabytes = bytes / 1e9;
var gibibytes = bytes / 1024 ** 3;
function StackSpecView() {
	const normative = STACK.layers.filter((layer) => layer.status === "normative").length;
	const allowed = STACK.edges.filter((edge) => edge.allow).length;
	const denied = STACK.edges.length - allowed;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-3xl px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "border-b border-rule pb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-xs tracking-wide text-muted uppercase",
						children: [
							"Spec ",
							V1_VERSION,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-2 text-rule",
								children: "/"
							}),
							"was ",
							V0_VERSION
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-serif text-4xl leading-tight font-medium text-ink sm:text-5xl",
						children: "Audited stack"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 max-w-xl text-lg text-ink",
						children: [
							"Parsed the nine-line list, corrected the numbers, split what had been taped together, and froze the result as ",
							V1_VERSION,
							". ",
							violations.length === 0 ? "The spec validates." : "The spec failed validation."
						]
					})
				]
			}),
			violations.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 border border-oxide px-3 py-2 font-mono text-sm text-oxide",
				role: "alert",
				children: violations.join(" · ")
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-6 grid grid-cols-2 gap-px overflow-hidden border border-rule bg-rule sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Clauses parsed",
						value: String(parsed.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Normative layers",
						value: String(normative)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Edges denied",
						value: String(denied)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Validation",
						value: violations.length === 0 ? "Clean" : "Failed"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-ink",
						children: "What changed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-muted",
						children: [
							countKind("fix"),
							" fixes, ",
							countKind("upgrade"),
							" upgrades, ",
							countKind("harden"),
							" hardenings. Fixes correct a false or missing number. Upgrades add a rule v0 only implied. Hardenings close a reading that would let a rejected essay back in."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 divide-y divide-rule border-y border-rule",
						children: findings.map((finding) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid gap-1 py-3 sm:grid-cols-[7.5rem_1fr] sm:gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-oxide",
								children: [finding.id, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-muted",
									children: KIND_LABEL[finding.kind]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-ink",
									children: finding.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: finding.detail
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-mono text-xs text-muted",
									children: finding.layer
								})
							] })]
						}, finding.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-ink",
						children: "Reserved words"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted",
						children: "A claim that uses one of these without naming the sense is not a statement in this spec."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-col gap-4",
						children: STACK.homonyms.map((hom) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-rule",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "border-b border-rule px-3 py-2 font-mono text-sm text-ink",
								children: hom.token
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: hom.senses.map((sense) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "grid gap-1 border-b border-rule px-3 py-2 last:border-b-0 sm:grid-cols-[1fr_auto] sm:items-baseline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: sense.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-muted",
									children: sense.livesIn
								})]
							}, sense.name)) })]
						}, hom.token))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-ink",
						children: "Layers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted",
						children: "Six normative layers, one closed analysis, three references. The old ninth line is now two of those references, so the count is ten."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-col gap-3",
						children: STACK.layers.map((layer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "group border border-rule",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
								className: "flex min-h-11 cursor-pointer list-none items-baseline gap-3 px-3 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-muted",
										children: layer.n
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 text-ink",
										children: layer.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-oxide",
										children: layer.status
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-rule px-3 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs text-muted",
										children: layer.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2",
										children: layer.summary
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-mono text-xs tracking-wide text-muted uppercase",
										children: "Holds"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-2 list-disc pl-5 text-sm",
										children: layer.invariants.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "mt-1",
											children: line
										}, line))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-mono text-xs tracking-wide text-oxide uppercase",
										children: "Refuses"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-2 list-disc pl-5 text-sm",
										children: layer.rejects.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "mt-1",
											children: line
										}, line))
									})
								]
							})]
						}, layer.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-ink",
						children: "Edges"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-muted",
						children: [
							allowed,
							" allowed, ",
							denied,
							" denied. A missing edge is not an invitation."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-rule border-y border-rule",
						children: STACK.edges.map((edge) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: edge.allow ? "text-ink" : "text-oxide",
									children: edge.allow ? "allow" : "deny"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted",
									children: [
										" ",
										edge.from,
										" → ",
										edge.to
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm",
								children: edge.relation
							})]
						}, `${edge.from}-${edge.to}`))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 border-t border-rule pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-ink",
						children: "Worked number"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: "Llama-70B key-value cache, FP16, one million tokens. Eighty layers, eight key-value heads, head size 128, two bytes, keys and values."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-mono text-sm text-ink",
						children: [
							"2 × 80 × 8 × 128 × 10^6 × 2 = ",
							bytes.toLocaleString("en-US"),
							" bytes"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-sm text-muted",
						children: [
							gigabytes.toLocaleString("en-US"),
							" GB decimal · ",
							gibibytes.toFixed(1),
							" GiB"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "The source essay’s 135 GB is withdrawn. FP8 halves the byte count. It does not change the formula."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 border-t border-rule pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-ink",
						children: "Version policy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 list-disc pl-5 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Major — a layer changes status, or a denied edge becomes allowed." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Minor — an invariant is added and none is removed." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Patch — a citation or a worked number is corrected." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 font-mono text-xs text-muted",
						children: [
							V0_VERSION,
							" → ",
							V1_VERSION
						]
					})
				]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-paper px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "font-mono text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-serif text-2xl text-ink",
			children: value
		})]
	});
}
var SplitComponent = StackSpecView;
//#endregion
export { SplitComponent as component };
