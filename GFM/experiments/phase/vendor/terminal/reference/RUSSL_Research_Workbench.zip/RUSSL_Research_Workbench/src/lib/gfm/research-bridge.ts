import {
  AXIS_NAMES,
  GENERATOR_ID,
  PIXEL_PROFILE,
  dimensionsOf,
  makeWordGenerator,
  packCoordinates,
  unpackCoordinates,
  sampleSlice,
  validateConfig,
} from "./penteract.ts";
import type { CellObservation, SliceConfig, SliceResult } from "./penteract.ts";
import {
  advanceCell,
  advancePair,
  inverseCell,
  inversePair,
  cellInvariant,
  pairInvariant,
} from "./dynamics.ts";
import type { PhaseState, PairState } from "./dynamics.ts";
import { gfMul } from "./field.ts";
import {
  decodePixel160,
  decodeStatePixel160,
  encodePixel160,
  encodeStatePixel160,
  pixelHex,
} from "./pixel.ts";
import type { Pixel160 } from "./pixel.ts";

type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };
type JsonObject = { [key: string]: JsonValue };

export const RESEARCH_SNAPSHOT_SCHEMA = "RUSSL-research-slice/1";
export type ResearchSelectedWitness = {
  rowMajorIndex: number;
  address: string;
  coordinates: string[];
  pixelHex: string;
  qHex: string;
  pHex: string;
  partnerAddress: string | null;
  partnerQHex: string | null;
  partnerPHex: string | null;
  initialInvariantHex: string;
  currentInvariantHex: string;
  cellInvariantHex: string;
  inverseVerified: boolean;
};
export type ResearchSnapshot = {
  schema: typeof RESEARCH_SNAPSHOT_SCHEMA;
  manifest: JsonObject;
  pixelPayloadHex: string;
  selected?: ResearchSelectedWitness;
};

const MAX_SNAPSHOT_BYTES = 2 * 1024 * 1024;
const MAX_JSON_NODES = 100000;
const stateHex = (value: bigint) => value.toString(16).padStart(20, "0");

function object(value: unknown, label: string): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new TypeError(`${label} must be an object.`);
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null)
    throw new TypeError(`${label} must contain plain JSON data.`);
  return value as Record<string, unknown>;
}

/** A snapshot is data, never a document command or an executable source. */
function jsonCopy(value: unknown): JsonValue {
  const ancestors = new Set<object>();
  let nodes = 0;
  const visit = (item: unknown, depth: number): void => {
    if (++nodes > MAX_JSON_NODES || depth > 16)
      throw new RangeError("Research snapshot exceeds its bounded JSON structure.");
    if (item === null || typeof item === "boolean" || typeof item === "string") return;
    if (typeof item === "number" && Number.isFinite(item)) return;
    if (typeof item !== "object" || !item)
      throw new TypeError("Research snapshot must be plain serializable JSON data.");
    if (ancestors.has(item)) throw new TypeError("Research snapshot cannot contain cycles.");
    if (!Array.isArray(item)) object(item, "Research snapshot value");
    ancestors.add(item);
    if (Array.isArray(item)) {
      if (Object.getPrototypeOf(item) !== Array.prototype)
        throw new TypeError("Research snapshot arrays must be plain JSON arrays.");
      if (item.length > MAX_JSON_NODES) throw new RangeError("Research array is too large.");
      const descriptors = Object.getOwnPropertyDescriptors(item);
      for (const key of Reflect.ownKeys(descriptors)) {
        if (key === "length") continue;
        if (
          typeof key !== "string" ||
          !/^(?:0|[1-9][0-9]*)$/.test(key) ||
          Number(key) >= item.length
        )
          throw new TypeError("Research arrays cannot contain extra or executable properties.");
      }
      for (let index = 0; index < item.length; index++) {
        const descriptor = descriptors[index];
        if (!descriptor) throw new TypeError("Research arrays cannot be sparse.");
        if (!Object.hasOwn(descriptor, "value"))
          throw new TypeError("Research JSON data cannot contain accessors.");
        visit(descriptor.value, depth + 1);
      }
    } else {
      const descriptors = Object.getOwnPropertyDescriptors(item);
      for (const key of Reflect.ownKeys(descriptors)) {
        if (typeof key !== "string")
          throw new TypeError("Research snapshot objects cannot contain symbol properties.");
        const descriptor = descriptors[key];
        if (!Object.hasOwn(descriptor, "value"))
          throw new TypeError("Research JSON data cannot contain accessors.");
        visit(descriptor.value, depth + 1);
      }
    }
    ancestors.delete(item);
  };
  visit(value, 0);
  const text = JSON.stringify(value);
  if (typeof text !== "string" || new TextEncoder().encode(text).length > MAX_SNAPSHOT_BYTES)
    throw new RangeError("Research snapshot exceeds the 2 MiB transfer limit.");
  return JSON.parse(text) as JsonValue;
}

function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  if (value && typeof value === "object")
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${canonical((value as Record<string, unknown>)[key])}`)
      .join(",")}}`;
  return JSON.stringify(value);
}
function same(actual: unknown, expected: unknown, label: string): void {
  if (canonical(actual) !== canonical(expected))
    throw new Error(`${label} differs from the declared GF80 workbench model.`);
}
function exactKeys(value: Record<string, unknown>, keys: readonly string[], label: string): void {
  same(Object.keys(value).sort(), [...keys].sort(), `${label} fields`);
}
function hexBytes(value: unknown, byteLength: number, label: string): Uint8Array {
  if (typeof value !== "string" || value.length !== byteLength * 2 || !/^[0-9a-f]+$/.test(value))
    throw new TypeError(`${label} requires exactly ${byteLength} canonical hexadecimal bytes.`);
  return Uint8Array.from({ length: byteLength }, (_, index) =>
    Number.parseInt(value.slice(index * 2, index * 2 + 2), 16),
  );
}
function positiveDecimal(value: unknown, label: string): bigint {
  if (typeof value !== "string" || value.length > 1024 || !/^[1-9][0-9]*$/.test(value))
    throw new TypeError(`${label} must be a positive decimal integer.`);
  return BigInt(value);
}
function unitIndex(value: unknown, length: bigint): bigint {
  if (typeof value !== "string" || value.length > 1024 || !/^(?:0|[1-9][0-9]*)$/.test(value))
    throw new TypeError("Witness index must be a canonical nonnegative decimal integer.");
  const result = BigInt(value);
  if (result >= length) throw new RangeError("Witness unit index lies outside its axis word.");
  return result;
}
function hash(value: unknown, label: string): string {
  if (typeof value !== "string" || !/^[0-9a-f]{64}$/.test(value))
    throw new TypeError(`${label} requires a canonical SHA-256 digest.`);
  return value;
}

function inverseVerified(cell: CellObservation, config: SliceConfig): boolean {
  const tick = BigInt(config.tick),
    kappa = BigInt(config.kappa),
    coupling = BigInt(config.coupling);
  if (tick === 0n) {
    return (
      cell.state.q === cell.initial.q &&
      cell.state.p === cell.initial.p &&
      (cell.partnerState === null ||
        (cell.partnerInitial !== null &&
          cell.partnerState.q === cell.partnerInitial.q &&
          cell.partnerState.p === cell.partnerInitial.p))
    );
  }
  if (cell.partnerState === null) {
    const previous = advanceCell(cell.initial, tick - 1n, "gf80", kappa),
      recovered = inverseCell(cell.state, "gf80", kappa);
    return recovered.q === previous.q && recovered.p === previous.p;
  }
  if (!cell.partnerInitial) return false;
  const previous = advancePair(
      [cell.initial, cell.partnerInitial],
      tick - 1n,
      "gf80",
      kappa,
      coupling,
    ),
    recovered = inversePair([cell.state, cell.partnerState], "gf80", kappa, coupling);
  return recovered.every(
    (state, index) => state.q === previous[index].q && state.p === previous[index].p,
  );
}

function selectedWitness(
  cell: CellObservation,
  index: number,
  config: SliceConfig,
): ResearchSelectedWitness {
  return {
    rowMajorIndex: index,
    address: cell.index.toString(),
    coordinates: cell.coords.map(String),
    pixelHex: pixelHex(cell.pixel),
    qHex: stateHex(cell.state.q),
    pHex: stateHex(cell.state.p),
    partnerAddress: cell.partnerIndex?.toString() ?? null,
    partnerQHex: cell.partnerState ? stateHex(cell.partnerState.q) : null,
    partnerPHex: cell.partnerState ? stateHex(cell.partnerState.p) : null,
    initialInvariantHex: stateHex(cell.initialInvariant),
    currentInvariantHex: stateHex(cell.currentInvariant),
    cellInvariantHex: stateHex(cell.cellInvariant),
    inverseVerified: inverseVerified(cell, config),
  };
}

/** Transfer the exact slice manifest and bounded canonical state payload, never whole words. */
export function createResearchSnapshot(
  slice: SliceResult,
  options: { selectedIndex?: number; inverseWitness?: boolean } = {},
): ResearchSnapshot {
  const snapshot: ResearchSnapshot = {
    schema: RESEARCH_SNAPSHOT_SCHEMA,
    manifest: jsonCopy(slice.manifest) as JsonObject,
    pixelPayloadHex: Array.from(slice.pixelBytes, (byte) =>
      byte.toString(16).padStart(2, "0"),
    ).join(""),
  };
  if (options.selectedIndex !== undefined) {
    if (
      !Number.isInteger(options.selectedIndex) ||
      options.selectedIndex < 0 ||
      options.selectedIndex >= slice.cells.length
    )
      throw new RangeError("Selected research cell lies outside this bounded slice.");
    snapshot.selected = selectedWitness(
      slice.cells[options.selectedIndex],
      options.selectedIndex,
      slice.config,
    );
    if (
      options.inverseWitness !== undefined &&
      options.inverseWitness !== snapshot.selected.inverseVerified
    )
      throw new Error("Supplied inverse witness disagrees with the exact reversible dynamics.");
  } else if (options.inverseWitness !== undefined) {
    throw new Error("An inverse witness requires a selected research cell.");
  }
  // Catch stale or mismatched result objects before publishing a self-contained receipt.
  replayResearchSlice(snapshot);
  return snapshot;
}

/** Replay a bounded GF80 slice from generated recipes and complete imported unit witnesses. */
export function replayResearchSlice(input: unknown) {
  const snapshot = object(jsonCopy(input), "Research snapshot");
  exactKeys(
    snapshot,
    [
      "schema",
      "manifest",
      "pixelPayloadHex",
      ...(snapshot.selected !== undefined ? ["selected"] : []),
    ],
    "Research snapshot",
  );
  if (snapshot.schema !== RESEARCH_SNAPSHOT_SCHEMA)
    throw new TypeError("Unsupported research snapshot schema.");
  const manifest = object(snapshot.manifest, "Research manifest");
  if (manifest.schema !== "RUSSL-five-word-cube/2" && manifest.schema !== "RUSSL-five-word-cube/3")
    throw new TypeError("Research replay requires a version 2 or 3 GF80 workbench manifest.");
  const rawConfig = object(manifest.config, "Research slice configuration");
  exactKeys(
    rawConfig,
    [
      "words",
      "seed",
      "tick",
      "mode",
      "kappa",
      "coupling",
      "couplingAxis",
      "axes",
      "fixed",
      "origin",
      "size",
    ],
    "Research slice configuration",
  );
  const config = validateConfig(rawConfig as unknown as SliceConfig);
  same(rawConfig, config, "Canonical slice configuration");
  // Metadata has the same model and source recipe for a one-cell tile; avoid
  // evolving an unrelated full generated tile just to validate model labels.
  const baseline = sampleSlice({ ...config, size: 1 }).manifest,
    dimensions = dimensionsOf(config),
    generated = makeWordGenerator(BigInt(config.seed), dimensions),
    tick = BigInt(config.tick),
    kappa = BigInt(config.kappa),
    coupling = BigInt(config.coupling);
  for (const key of ["domain", "field", "dynamics", "observation"] as const)
    same(manifest[key], baseline[key], `Research ${key} metadata`);
  if (!Array.isArray(manifest.words) || manifest.words.length !== 5)
    throw new TypeError("Research replay requires exactly five axis words.");
  const words = manifest.words.map((word, axis) => object(word, `${AXIS_NAMES[axis]} word`));
  const importedAxes: number[] = [];
  const importedWords = words.flatMap((word, axis) => {
    if (word.source !== "imported") {
      const expected = {
        ...baseline.words[axis],
        ...(manifest.schema === "RUSSL-five-word-cube/3" ? { source: "generated" } : {}),
      };
      same(word, expected, `${AXIS_NAMES[axis]} generated word recipe`);
      return [];
    }
    if (manifest.schema !== "RUSSL-five-word-cube/3")
      throw new TypeError("Imported word witnesses require a version 3 manifest.");
    exactKeys(
      word,
      [
        "name",
        "length",
        "unitBytes",
        "wordBytes",
        "id",
        "source",
        "originalName",
        "sourceFormat",
        "sourceBits",
        "sourceByteLength",
        "paddingBits",
        "sourceSha256",
        "canonicalSha256",
        "entry",
        "unitCount",
        "unitProfile",
      ],
      "Imported word descriptor",
    );
    same(
      [
        word.name,
        word.id,
        word.entry,
        word.length,
        word.unitBytes,
        word.wordBytes,
        word.unitProfile,
      ],
      [
        AXIS_NAMES[axis],
        `word-${axis}-${AXIS_NAMES[axis]}`,
        `words/${axis}-${AXIS_NAMES[axis]}.bin`,
        dimensions[axis].toString(),
        20,
        (dimensions[axis] * 20n).toString(),
        PIXEL_PROFILE,
      ],
      "Imported axis layout",
    );
    if (positiveDecimal(word.unitCount, "Imported unit count") !== dimensions[axis])
      throw new Error("Imported unit count differs from its axis length.");
    if (
      typeof word.originalName !== "string" ||
      !word.originalName.trim() ||
      word.originalName.length > 255 ||
      word.originalName === "." ||
      word.originalName === ".." ||
      Array.from(word.originalName).some((character) => {
        const code = character.charCodeAt(0);
        return code < 32 || code === 127 || character === "/" || character === "\\";
      })
    )
      throw new TypeError("Imported word filename is invalid.");
    if (word.sourceFormat !== "appliance-le" && word.sourceFormat !== "russl-be")
      throw new TypeError("Imported word format is unsupported.");
    const bits = word.sourceBits,
      bytes = word.sourceByteLength,
      padding = word.paddingBits;
    if (
      typeof bits !== "number" ||
      !Number.isSafeInteger(bits) ||
      bits < 8 ||
      typeof bytes !== "number" ||
      !Number.isSafeInteger(bytes) ||
      bytes < 1 ||
      Math.ceil(bits / 8) !== bytes ||
      typeof padding !== "number" ||
      !Number.isInteger(padding) ||
      padding < 0 ||
      padding > 159 ||
      BigInt(bits) + BigInt(padding) !== dimensions[axis] * 160n
    )
      throw new TypeError("Imported word width or final-unit padding is inconsistent.");
    if (
      (word.sourceFormat === "appliance-le" && bytes > 131072) ||
      (word.sourceFormat === "russl-be" &&
        (bytes > 8 * 1024 * 1024 || bytes % 20 !== 0 || bits !== bytes * 8 || padding !== 0))
    )
      throw new RangeError("Imported word exceeds its supported raw format or byte limit.");
    importedAxes.push(axis);
    return [
      {
        axis,
        name: AXIS_NAMES[axis],
        sourceSha256: hash(word.sourceSha256, "Original source hash"),
        canonicalSha256: hash(word.canonicalSha256, "Canonical source hash"),
        originalHashesVerified: false as const,
        witnessUnits: 0,
      },
    ];
  });
  const imported = importedAxes.length > 0;
  if ((manifest.schema === "RUSSL-five-word-cube/3") !== imported)
    throw new Error("Manifest version differs from the actual imported source kinds.");
  same(
    manifest.generator,
    {
      ...baseline.generator,
      id: imported ? "five-axis-source-pixel160-units-v1" : GENERATOR_ID,
      wordUnitRule: imported
        ? "imported axes use exact source unit(index); generated axes use fold(i) by big-endian byte Horner in GF80, factor256; q=aq*fold(i)+bq; p=ap*fold(i)+bp"
        : baseline.generator.wordUnitRule,
      arbitraryIndependentUnitStorage: imported,
      indexSemantics: imported
        ? "imported words directly index their finite stored Pixel160 units; generated axes fold arbitrary integer indices into finite values and can repeat values"
        : baseline.generator.indexSemantics,
    },
    "Research generator metadata",
  );
  const allowedManifestKeys = [
    "schema",
    "config",
    "domain",
    "words",
    "field",
    "dynamics",
    "generator",
    "observation",
    "slice",
    "fullStatesHex",
    "checks",
    ...(imported ? ["wordWitnesses"] : []),
    ...(manifest.sha256 !== undefined ? ["sha256"] : []),
  ];
  exactKeys(manifest, allowedManifestKeys, "Research manifest");

  const observedCoordinates: bigint[][] = [],
    dependencies = new Set<string>();
  for (let row = 0; row < config.size; row++)
    for (let column = 0; column < config.size; column++) {
      const coords = config.fixed.map(BigInt);
      coords[config.axes[0]] = BigInt(config.origin[0]) + BigInt(column);
      coords[config.axes[1]] = BigInt(config.origin[1]) + BigInt(row);
      observedCoordinates.push(coords);
      dependencies.add(packCoordinates(coords, dimensions).toString());
      const partner = [...coords];
      partner[config.couplingAxis] ^= 1n;
      if (config.mode === "pair" && partner[config.couplingAxis] < dimensions[config.couplingAxis])
        dependencies.add(packCoordinates(partner, dimensions).toString());
    }
  const requiredUnits = dimensions.map(
    (_, axis) =>
      new Set(
        [...dependencies].map((address) =>
          unpackCoordinates(BigInt(address), dimensions)[axis].toString(),
        ),
      ),
  );
  same(
    manifest.slice,
    {
      ...baseline.slice,
      shape: [config.size, config.size],
      observedSliceCells: observedCoordinates.length,
      evaluatedCells: dependencies.size,
      pixelPayloadBytes: observedCoordinates.length * 20,
    },
    "Research slice metadata",
  );
  const unitMaps = new Map<number, Map<string, Pixel160>>();
  if (imported) {
    if (
      !Array.isArray(manifest.wordWitnesses) ||
      manifest.wordWitnesses.length !== importedAxes.length
    )
      throw new Error("Imported axes require exactly one complete word witness each.");
    for (let position = 0; position < importedAxes.length; position++) {
      const axis = importedAxes[position],
        witness = object(manifest.wordWitnesses[position], "Imported word witness");
      exactKeys(witness, ["axis", "name", "unitCount", "units"], "Imported word witness");
      same(
        [witness.axis, witness.name, witness.unitCount],
        [axis, AXIS_NAMES[axis], dimensions[axis].toString()],
        "Imported witness axis",
      );
      if (!Array.isArray(witness.units) || witness.units.length !== requiredUnits[axis].size)
        throw new Error(
          "Imported word witness coverage must include every observed and off-slice partner unit exactly.",
        );
      const map = new Map<string, Pixel160>();
      let last = -1n;
      for (const item of witness.units) {
        const unit = object(item, "Imported unit witness");
        exactKeys(unit, ["index", "pixelHex"], "Imported unit witness");
        const index = unitIndex(unit.index, dimensions[axis]),
          key = index.toString();
        if (index <= last || map.has(key))
          throw new Error("Imported witness indices must be sorted, unique and complete.");
        if (!requiredUnits[axis].has(key))
          throw new Error(
            "Imported witness includes an unused unit instead of a required dependency.",
          );
        const pixel = decodePixel160(hexBytes(unit.pixelHex, 20, "Imported Pixel160 witness"));
        if (
          index === dimensions[axis] - 1n &&
          Number(words[axis].paddingBits) > 0 &&
          BigInt(`0x${unit.pixelHex}`) >> BigInt(160 - Number(words[axis].paddingBits)) !== 0n
        )
          throw new Error("Imported final-unit witness has nonzero high padding bits.");
        map.set(key, pixel);
        last = index;
      }
      unitMaps.set(axis, map);
      importedWords[position].witnessUnits = map.size;
    }
  }
  const wordUnit = (axis: number, index: bigint): Pixel160 => {
    const map = unitMaps.get(axis);
    if (!map) return generated.wordUnit(axis, index);
    const value = map.get(index.toString());
    if (!value)
      throw new Error("Imported dependency witness is missing; regeneration is forbidden.");
    return [...value] as Pixel160;
  };
  const initialStates = new Map<string, PhaseState>();
  const initialAt = (address: bigint): PhaseState => {
    const key = address.toString(),
      cached = initialStates.get(key);
    if (cached) return { ...cached };
    const coords = unpackCoordinates(address, dimensions);
    let q = 0n,
      p = 0n;
    for (let axis = 0; axis < 5; axis++) {
      const unit = decodeStatePixel160(wordUnit(axis, coords[axis]));
      q ^= gfMul(unit.q, BigInt(axis + 1), "gf80");
      p ^= gfMul(unit.p, BigInt(3 * (axis + 1)), "gf80");
    }
    const state = { q, p };
    initialStates.set(key, state);
    return { ...state };
  };
  const pairs = new Map<string, PairState>();
  const cells: CellObservation[] = observedCoordinates.map((coords) => {
    const index = packCoordinates(coords, dimensions),
      initial = initialAt(index),
      wordUnits = coords.map((coordinate, axis) => wordUnit(axis, coordinate)),
      partnerCoords = [...coords];
    partnerCoords[config.couplingAxis] ^= 1n;
    if (
      config.mode !== "pair" ||
      partnerCoords[config.couplingAxis] >= dimensions[config.couplingAxis]
    ) {
      const state = advanceCell(initial, tick, "gf80", kappa);
      return {
        index,
        coords,
        initial,
        state,
        pixel: encodeStatePixel160(state),
        wordUnits,
        partnerIndex: null,
        partnerInitial: null,
        partnerState: null,
        initialInvariant: cellInvariant(initial, "gf80", kappa),
        currentInvariant: cellInvariant(state, "gf80", kappa),
        cellInvariant: cellInvariant(state, "gf80", kappa),
      };
    }
    const partnerIndex = packCoordinates(partnerCoords, dimensions),
      low = index < partnerIndex ? index : partnerIndex,
      high = index < partnerIndex ? partnerIndex : index,
      slot = index === low ? 0 : 1,
      key = low.toString();
    const initialPair: PairState = [initialAt(low), initialAt(high)];
    let pair = pairs.get(key);
    if (!pair) {
      pair = advancePair(initialPair, tick, "gf80", kappa, coupling);
      pairs.set(key, pair);
    }
    const state = { ...pair[slot] };
    return {
      index,
      coords,
      initial,
      state,
      pixel: encodeStatePixel160(state),
      wordUnits,
      partnerIndex,
      partnerInitial: { ...initialPair[1 - slot] },
      partnerState: { ...pair[1 - slot] },
      initialInvariant: pairInvariant(initialPair, "gf80", kappa, coupling),
      currentInvariant: pairInvariant(pair, "gf80", kappa, coupling),
      cellInvariant: cellInvariant(state, "gf80", kappa),
    };
  });
  const pixelBytes = new Uint8Array(cells.length * 20);
  cells.forEach((cell, index) => pixelBytes.set(encodePixel160(cell.pixel), index * 20));
  const declaredPayload = hexBytes(
    snapshot.pixelPayloadHex,
    pixelBytes.length,
    "Research state payload",
  );
  same(Array.from(declaredPayload), Array.from(pixelBytes), "Reconstructed Pixel160 payload");
  same(
    manifest.fullStatesHex,
    cells.map((cell) => ({ q: stateHex(cell.state.q), p: stateHex(cell.state.p) })),
    "Reconstructed full states",
  );
  const invariantsHold = cells.every((cell) => cell.initialInvariant === cell.currentInvariant);
  const checks = object(manifest.checks, "Research manifest checks");
  if (checks.invariantPreserved !== invariantsHold || !invariantsHold)
    throw new Error("Reconstructed field invariant is not preserved.");
  if (checks.selectedInverseWitness !== undefined || checks.selectedInverseReplay !== undefined) {
    const witness = object(checks.selectedInverseWitness, "Manifest selected inverse witness");
    exactKeys(
      witness,
      ["addressHex", "coordinates", "column", "row", "tick"],
      "Manifest selected inverse witness",
    );
    if (
      !Number.isInteger(witness.column) ||
      !Number.isInteger(witness.row) ||
      Number(witness.column) < 0 ||
      Number(witness.row) < 0 ||
      Number(witness.column) >= config.size ||
      Number(witness.row) >= config.size
    )
      throw new RangeError("Manifest inverse witness lies outside its slice.");
    const cell = cells[Number(witness.row) * config.size + Number(witness.column)];
    same(
      [witness.addressHex, witness.coordinates, witness.tick],
      [stateHex(cell.index), cell.coords.map(String), config.tick],
      "Manifest inverse witness address",
    );
    same(
      checks.selectedInverseReplay,
      inverseVerified(cell, config),
      "Manifest inverse verification",
    );
  }
  let declaredPixelPayloadSha256: string | null = null;
  if (manifest.sha256 !== undefined) {
    const digest = object(manifest.sha256, "Manifest payload hash");
    exactKeys(digest, ["pixelPayloadBE"], "Manifest payload hash");
    declaredPixelPayloadSha256 = hash(digest.pixelPayloadBE, "Pixel payload hash");
  }
  let selected: ResearchSelectedWitness | undefined;
  if (snapshot.selected !== undefined) {
    const witness = object(snapshot.selected, "Selected research witness"),
      index = witness.rowMajorIndex;
    if (typeof index !== "number" || !Number.isInteger(index) || index < 0 || index >= cells.length)
      throw new RangeError("Selected research witness lies outside its slice.");
    selected = selectedWitness(cells[index], index, config);
    same(witness, selected, "Selected research inverse witness");
  }
  return {
    valid: true as const,
    config,
    cells,
    pixelBytes,
    checks: {
      pixelPayloadMatches: true,
      fullStatesMatch: true,
      coordinatesValid: true,
      invariantPreserved: true,
      inverseVerified: cells.every((cell) => inverseVerified(cell, config)),
      observedCells: cells.length,
      evaluatedCells: dependencies.size,
      declaredPixelPayloadSha256,
      declaredPixelPayloadHashVerified: false,
    },
    sourceHashScope: {
      scope: "bounded source-unit witnesses only",
      verifiedFromOriginalBytes: false,
      importedWords,
      explanation: imported
        ? "Original and canonical word hashes identify the declared source files. They are not verified from bounded witnesses; verifying them requires the complete original word files."
        : "All five generated word recipes are reproduced. No imported original source files are claimed or hashed.",
    },
    ...(selected ? { selected } : {}),
  };
}
