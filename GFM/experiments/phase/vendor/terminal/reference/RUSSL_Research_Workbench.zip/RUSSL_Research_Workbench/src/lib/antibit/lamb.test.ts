import assert from "node:assert/strict";
import test from "node:test";
import { emitBytes, emitReleases, lambWave, releases, waveReferences } from "./lamb.ts";

test("1-bit LAMB carries neighbor signs across two ranks", () => {
  const report = lambWave(13n, 8, 32);
  assert.equal(report.holds, true);
  assert.equal(report.packedBytes, 4);
  assert.equal(report.denseBytes, 128);
  assert.equal(report.waves, 4);
  assert.equal(report.varianceDrift, 0);
  assert.equal(report.replicasMatch, true);
  assert.ok(report.cpuSigns.every((bit) => bit === 1 || bit === -1));
  assert.equal(report.agreed + report.ties, 32);
  assert.equal(report.tiers.DRAM, 8);
  assert.deepEqual(
    waveReferences(13n, 8, report.packedHex)?.map((item) => item.name),
    ["Schrödinger", "Bloch", "Jaynes–Cummings", "Uncertainty"],
  );
  assert.equal(waveReferences(14n, 8, report.packedHex), null);
  assert.equal(emitBytes(report.packedHex, [false, false, false, false]), "");
  assert.equal(emitBytes(report.packedHex, [false, true, false, false]), "40");
  assert.equal(emitBytes(report.packedHex, [true, true, true, true]), report.packedHex);
  const streams = releases(13n, 8, 32);
  assert.deepEqual(
    streams.map((item) => item.label),
    ["Schrödinger", "Bloch", "Jaynes–Cummings", "Uncertainty", "GPU", "Roles", "Antis", "Gather"],
  );
  assert.equal(streams.find((item) => item.id === "gpu")?.bytes, "ffbfff5f");
  assert.equal(streams.find((item) => item.id === "gather")?.bytes, "00".repeat(32));
  assert.equal(emitReleases(streams, { "wave-1": true, gpu: true }).map((item) => item.bytes).join(" "), "40 ffbfff5f");
});
