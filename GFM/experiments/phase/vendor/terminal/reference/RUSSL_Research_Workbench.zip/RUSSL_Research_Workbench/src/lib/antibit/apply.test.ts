import assert from "node:assert/strict";
import test from "node:test";
import { aesSbox, eraseSymbol } from "./apply.ts";

test("the AES S-box is inversion in the AES field, then the affine map", () => {
  assert.equal(aesSbox(0x00).image, "63");
  assert.equal(aesSbox(0x01).image, "7c");
  assert.equal(aesSbox(0x53).holds, true);
  assert.equal(aesSbox(0x53).image, "ed");
});

test("one erased Reed-Solomon symbol comes back", () => {
  for (const bits of [8, 16, 32]) {
    for (const erased of [0, 1, 2] as const) {
      const report = eraseSymbol(13n, 243n, bits, erased);
      assert.equal(report.holds, true);
      assert.equal(report.recovered, report.symbols[erased]);
    }
  }
});
