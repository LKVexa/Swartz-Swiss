import assert from "node:assert/strict";
import test from "node:test";
import { isIdentity, matrixProduct, monomialMatrix, quantumProcedure } from "./weyl.ts";

test("the anti-word is the inverse procedure", () => {
  for (const width of [8, 16, 32] as const) {
    const report = quantumProcedure(13n, width);
    assert.equal(report.holds, true);
    assert.equal(report.forward.k, 13n);
    assert.equal(report.forward.a, 1n);
    assert.equal(report.forward.b, 13n);
    assert.equal(report.inverse.k, 0n);
    assert.equal(report.inverse.a, (1n << BigInt(width)) - 1n);
    assert.equal(report.inverse.b, (1n << BigInt(width)) - 13n);
  }
  assert.equal(quantumProcedure(0n, 8).holds, true);
});

test("the matrix of the inverse product is the identity", () => {
  for (const bits of [2, 3, 4]) {
    const report = quantumProcedure(13n, bits);
    const forward = monomialMatrix(report.forward, bits);
    const inverse = monomialMatrix(report.inverse, bits);
    assert.equal(forward.every((row) => row.filter((entry) => entry !== null).length === 1), true);
    assert.equal(isIdentity(matrixProduct(inverse, forward)), true);
    assert.equal(isIdentity(matrixProduct(forward, inverse)), true);
  }
});
