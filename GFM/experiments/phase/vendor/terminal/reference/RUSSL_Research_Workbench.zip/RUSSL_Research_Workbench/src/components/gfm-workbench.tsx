import { useEffect, useMemo, useRef, useState } from "react";
import {
  AXIS_NAMES,
  DEFAULT_CONFIG,
  sampleSlice,
  validateConfig,
  verifyInverse,
  unpackCoordinates,
  dimensionsOf,
} from "@/lib/gfm/penteract";
import type { SliceConfig, SliceResult, FiveStrings } from "@/lib/gfm/penteract";
import { MAX_TICK } from "@/lib/gfm/dynamics";
import { pixelHex, LANE_NAMES } from "@/lib/gfm/pixel";
import { encodeTiff } from "@/lib/gfm/export";
import { EMPTY_WORD_SOURCES, importRawWord } from "@/lib/gfm/raw-words";
import type { ImportedWord, RawWordFormat, WordSources } from "@/lib/gfm/raw-words";
import { createReplayBundle } from "@/lib/gfm/replay";

const hex = (n: bigint) => n.toString(16).padStart(20, "0");
const button =
  "min-h-11 border border-rule px-3 py-2 font-mono text-sm text-ink hover:border-signal disabled:opacity-40";
const input = "min-h-11 w-full border border-rule bg-well px-3 py-2 font-mono text-sm text-ink";
function saveBytes(bytes: Uint8Array, name: string, mime: string) {
  const url = URL.createObjectURL(new Blob([new Uint8Array(bytes).buffer], { type: mime }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
async function sha256(bytes: Uint8Array) {
  const digest = await crypto.subtle.digest("SHA-256", new Uint8Array(bytes).buffer);
  return Array.from(new Uint8Array(digest), (v) => v.toString(16).padStart(2, "0")).join("");
}

export function GfmWorkbench({
  onResearchSlice,
}: { onResearchSlice?: (slice: SliceResult, selectedIndex: number) => void } = {}) {
  const [config, setConfig] = useState<SliceConfig>(() => ({
    ...DEFAULT_CONFIG,
    words: [...DEFAULT_CONFIG.words],
    fixed: [...DEFAULT_CONFIG.fixed],
    axes: [...DEFAULT_CONFIG.axes],
    origin: [...DEFAULT_CONFIG.origin],
  }));
  const [draft, setDraft] = useState<SliceConfig>(config);
  const [stepText, setStepText] = useState("0");
  const [selected, setSelected] = useState({ column: 0, row: 0 });
  const [error, setError] = useState("");
  const [exporting, setExporting] = useState(false);
  const [sources, setSources] = useState<WordSources>(EMPTY_WORD_SOURCES);
  const [importFormat, setImportFormat] = useState<RawWordFormat>("appliance-le");
  const [importingAxis, setImportingAxis] = useState<number | null>(null);
  const [notice, setNotice] = useState("");
  const busy = exporting || importingAxis !== null;
  const importedCount = sources.filter(Boolean).length;
  const slice = useMemo(() => sampleSlice(config, sources), [config, sources]);
  const column = Math.min(selected.column, config.size - 1),
    row = Math.min(selected.row, config.size - 1);
  const current = slice.cells[row * config.size + column];
  const inverseVerified = useMemo(
    () => verifyInverse(current, config, sources),
    [current, config, sources],
  );
  const held = slice.manifest.checks.invariantPreserved;
  useEffect(() => {
    onResearchSlice?.(slice, row * config.size + column);
  }, [slice, onResearchSlice, row, column, config.size]);
  useEffect(() => setStepText(config.tick), [config.tick]);
  function applySetup() {
    if (busy) return;
    try {
      const next = validateConfig({ ...draft, tick: "0" });
      setConfig(next);
      setDraft(next);
      setSelected({ column: 0, row: 0 });
      setError("");
      setNotice("");
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }
  function goTo(tick: string) {
    if (busy) return;
    try {
      const next = validateConfig({ ...config, tick });
      setConfig(next);
      setError("");
      setNotice("");
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }
  const step = BigInt(config.tick);
  function chooseAxis(slot: 0 | 1, axis: number) {
    setDraft((d) => {
      const axes: [number, number] = [...d.axes];
      axes[slot] = axis;
      return { ...d, axes };
    });
  }
  function replaceWord(axis: number, word: ImportedWord | null) {
    const nextSources = Object.freeze(
      sources.map((source, index) => (index === axis ? word : source)),
    ) as WordSources;
    const words = [...config.words] as FiveStrings;
    words[axis] = word ? word.unitCount.toString() : DEFAULT_CONFIG.words[axis];
    const next = fitImportedWords({ ...config, words, tick: "0" });
    sampleSlice(next, nextSources);
    setSources(nextSources);
    setConfig(next);
    setDraft(next);
    setSelected({ column: 0, row: 0 });
    setError("");
  }
  async function loadAxisFile(axis: number, file: File) {
    if (busy) return;
    setImportingAxis(axis);
    setError("");
    setNotice("");
    try {
      const limit = importFormat === "appliance-le" ? 131072 : 8 * 1024 * 1024;
      if (file.size > limit)
        throw new Error(
          importFormat === "appliance-le"
            ? "Choose one appliance operand of at most 131,072 bytes. Split a word chain into individual operands first."
            : "A Pixel160 word must be at most 8 MiB.",
        );
      const word = await importRawWord(new Uint8Array(await file.arrayBuffer()), {
        name: file.name,
        format: importFormat,
      });
      replaceWord(axis, word);
      setNotice(
        `${AXIS_NAMES[axis]} imported: ${word.unitCount} Pixel160 units. Evolution restarted at step 0.`,
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setImportingAxis(null);
    }
  }
  function clearAxis(axis: number) {
    if (busy) return;
    try {
      replaceWord(axis, null);
      setNotice(
        `${AXIS_NAMES[axis]} returned to the generated recipe. Evolution restarted at step 0.`,
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }
  async function download(kind: "tiff" | "bundle") {
    if (busy) return;
    setExporting(true);
    setError("");
    setNotice("");
    try {
      const manifest = {
        ...slice.manifest,
        checks: {
          ...slice.manifest.checks,
          selectedInverseReplay: inverseVerified,
          selectedInverseWitness: {
            addressHex: hex(current.index),
            coordinates: current.coords.map(String),
            column,
            row,
            tick: config.tick,
          },
        },
        sha256: { pixelPayloadBE: await sha256(slice.pixelBytes) },
      };
      const stem = `russl-five-word-step-${config.tick}`;
      if (kind === "tiff")
        saveBytes(
          encodeTiff(slice.pixels, config.size, config.size, manifest),
          stem + ".tiff",
          "image/tiff",
        );
      else
        saveBytes(
          createReplayBundle(slice, manifest, sources, stem),
          stem + ".zip",
          "application/zip",
        );
      setNotice(`${kind === "tiff" ? "TIFF" : "Replay bundle"} exported at step ${config.tick}.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setExporting(false);
    }
  }
  return (
    <section
      id="cell-mechanics"
      className="mt-8 border-t border-rule pt-6"
      aria-label="Reversible cell mechanics"
    >
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="font-serif text-3xl text-ink">Cell mechanics</h2>
        <span
          className={
            "font-mono text-xs " + (held && inverseVerified ? "text-signal" : "text-oxide")
          }
          role="status"
        >
          {held
            ? current.partnerIndex !== null
              ? "Pair invariant held"
              : "Cell invariant held"
            : "Invariant changed"}{" "}
          ·{" "}
          {step === 0n ? "initial state" : inverseVerified ? "inverse verified" : "inverse failed"}
        </span>
      </div>
      <p className="mt-2 text-sm text-muted">
        Five ultra-wide words define the 5-cube. Each word unit is a RUSSL Pixel160; each evolving
        cell also fits exactly in one Pixel160.
      </p>
      <p className="mt-1 text-xs text-muted">
        {importedCount} of 5 axes use imported words. Remaining axes use the repeatable recipe.
        Equal word lengths form a cube; different lengths form a five-axis box.
      </p>
      <details className="mt-4 border border-rule p-3" open>
        <summary className="font-mono text-sm text-signal">Import appliance words</summary>
        <p className="mt-2 text-sm text-muted">
          Choose one raw word for each axis. Its Pixel160 unit count sets that axis length. Imports
          stay on this device and restart evolution at step zero.
        </p>
        <label className="mt-3 block font-mono text-xs text-muted">
          File format
          <select
            aria-label="Word file format"
            className={input + " mt-1"}
            disabled={busy}
            value={importFormat}
            onChange={(e) => setImportFormat(e.target.value as RawWordFormat)}
          >
            <option value="appliance-le">Ultra-wide appliance word</option>
            <option value="russl-be">RUSSL Pixel160 stream</option>
          </select>
        </label>
        <p className="mt-2 text-xs text-muted">
          {importFormat === "appliance-le"
            ? "Native little-endian operand bytes. A standard 131,072-byte word becomes 6,554 units; its final unit has 64 high zero padding bits. Every source bit is retained."
            : "Canonical big-endian Pixel160 bytes, five unsigned lanes per unit. The file must contain whole 20-byte units."}
        </p>
        <div className="mt-3 space-y-3">
          {AXIS_NAMES.map((name, axis) => (
            <div key={name} className="min-w-0 border-t border-rule pt-3">
              <label className="block font-mono text-xs text-muted">
                {name[0].toUpperCase() + name.slice(1)} word
                <input
                  aria-label={`Import ${name} word`}
                  type="file"
                  accept=".bin,.raw,.word,.pixel160,application/octet-stream"
                  className={input + " mt-1"}
                  disabled={busy}
                  onChange={(e) => {
                    const file = e.currentTarget.files?.[0];
                    e.currentTarget.value = "";
                    if (file) void loadAxisFile(axis, file);
                  }}
                />
              </label>
              <p
                data-testid={`word-source-${axis}`}
                className="mt-1 break-all font-mono text-xs text-muted"
              >
                {sources[axis]
                  ? `${sources[axis].name} · ${sources[axis].unitCount} units · ${sources[axis].paddingBits} padding bits · ${sources[axis].format === "appliance-le" ? "appliance" : "Pixel160"}`
                  : "Generated recipe"}
              </p>
              {sources[axis] ? (
                <>
                  <p className="mt-1 break-all font-mono text-xs text-muted">
                    SHA-256 {sources[axis].sha256}
                  </p>
                  <button
                    type="button"
                    className={button + " mt-1"}
                    disabled={busy}
                    onClick={() => clearAxis(axis)}
                  >
                    Use generated {name} word
                  </button>
                </>
              ) : null}
            </div>
          ))}
        </div>
        <p className="mt-3 text-xs text-muted">
          Replay bundles retain the exact imported files. TIFF metadata retains the source units
          needed for the selected slice and its coupled neighbors.
        </p>
        {importingAxis !== null ? (
          <p className="mt-2 font-mono text-xs text-signal" role="status">
            Reading {AXIS_NAMES[importingAxis]} word…
          </p>
        ) : null}
      </details>
      <form
        className="mt-4"
        onSubmit={(e) => {
          e.preventDefault();
          applySetup();
        }}
      >
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {AXIS_NAMES.map((name, axis) => (
            <label key={name} className="min-w-0 font-mono text-xs text-muted">
              {name[0].toUpperCase() + name.slice(1)} word units{" "}
              <input
                aria-label={`${name} word units`}
                className={input}
                inputMode="numeric"
                value={draft.words[axis]}
                readOnly={sources[axis] !== null}
                disabled={busy}
                onChange={(e) =>
                  setDraft((d) => {
                    const words: FiveStrings = [...d.words];
                    words[axis] = e.target.value;
                    return { ...d, words };
                  })
                }
              />
            </label>
          ))}
        </div>
        <button type="submit" className={button + " mt-2"} disabled={busy}>
          Apply words and restart
        </button>
      </form>
      <p className="mt-2 break-all font-mono text-xs text-muted">
        20 bytes per unit · {config.words.join(" × ")} = {slice.manifest.domain.cells} cell
        positions
      </p>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button
          type="button"
          className={button}
          disabled={step === 0n || busy}
          onClick={() => goTo((step - 1n).toString())}
        >
          Back
        </button>
        <button
          type="button"
          className={button + " border-signal bg-signal text-well"}
          disabled={step === MAX_TICK || busy}
          onClick={() => goTo((step + 1n).toString())}
        >
          Forward
        </button>
        <button
          type="button"
          className={button}
          disabled={step > MAX_TICK - 10n || busy}
          onClick={() => goTo((step + 10n).toString())}
        >
          Advance 10
        </button>
        <button
          type="button"
          className={button}
          disabled={step === 0n || busy}
          onClick={() => goTo("0")}
        >
          Return to start
        </button>
      </div>
      <form
        className="mt-2 flex flex-wrap items-center gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          goTo(stepText);
        }}
      >
        <label className="flex items-center gap-2 font-mono text-xs text-muted">
          Step{" "}
          <input
            aria-label="Evolution step"
            className={input + " max-w-40"}
            disabled={busy}
            value={stepText}
            inputMode="numeric"
            onChange={(e) => setStepText(e.target.value)}
          />
        </label>
        <button type="submit" className={button} disabled={busy}>
          Go to step
        </button>
      </form>

      <div className="mt-4 grid gap-4 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <div className="min-w-0">
          <div className="mb-2 flex justify-between gap-2 font-mono text-xs text-muted">
            <span>
              {AXIS_NAMES[config.axes[0]]} × {AXIS_NAMES[config.axes[1]]}
            </span>
            <span>
              {config.size} × {config.size} cells
            </span>
          </div>
          <PhaseTile
            slice={slice}
            column={column}
            row={row}
            onSelect={(column, row) => setSelected({ column, row })}
          />
          <p className="mt-2 font-mono text-xs text-muted">
            L8 phase · color wraps at 2π · visualization
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            <label className="min-w-0 flex-1 font-mono text-xs text-muted">
              Column{" "}
              <input
                className={input}
                type="number"
                min="0"
                max={config.size - 1}
                value={column}
                onChange={(e) => {
                  const n = Number(e.target.value);
                  if (Number.isInteger(n) && n >= 0 && n < config.size)
                    setSelected((s) => ({ ...s, column: n }));
                }}
              />
            </label>
            <label className="min-w-0 flex-1 font-mono text-xs text-muted">
              Row{" "}
              <input
                className={input}
                type="number"
                min="0"
                max={config.size - 1}
                value={row}
                onChange={(e) => {
                  const n = Number(e.target.value);
                  if (Number.isInteger(n) && n >= 0 && n < config.size)
                    setSelected((s) => ({ ...s, row: n }));
                }}
              />
            </label>
          </div>
        </div>
        <div className="min-w-0" aria-live="polite">
          <p className="font-mono text-xs text-muted">Selected cell · step {config.tick}</p>
          <p className="mt-1 break-all font-mono text-sm">
            ({current.coords.map(String).join(", ")})
          </p>
          <dl className="mt-3 space-y-2 font-mono text-xs">
            <StateValue label="q · full 80 bits" value={hex(current.state.q)} />
            <StateValue label="p · full 80 bits" value={hex(current.state.p)} />
            <StateValue
              label={current.partnerIndex !== null ? "Pair invariant" : "Cell invariant"}
              value={hex(current.currentInvariant)}
            />
          </dl>
          {current.partnerIndex !== null ? (
            <p className="mt-3 break-all font-mono text-xs text-muted">
              Coupled neighbor: (
              {unpackCoordinates(current.partnerIndex, dimensionsOf(config)).map(String).join(", ")}
              )
            </p>
          ) : config.mode === "pair" ? (
            <p className="mt-3 font-mono text-xs text-muted">
              Unpaired word end · independent evolution
            </p>
          ) : null}
          <h3 className="mt-4 font-serif text-xl">RUSSL Pixel160</h3>
          <p className="mt-1 break-all font-mono text-xs text-signal" data-testid="pixel160-hex">
            {pixelHex(current.pixel)}
          </p>
          <dl className="mt-2 grid grid-cols-2 gap-1 font-mono text-xs">
            {current.pixel.map((v, i) => (
              <div key={i}>
                <dt className="inline text-muted">{LANE_NAMES[i]} </dt>
                <dd className="inline">{v}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-2 text-xs text-muted">
            All 160 cell-state bits are retained. The TIFF preserves the five unsigned lanes.
          </p>
          <details className="mt-3">
            <summary className="font-mono text-xs text-signal">Selected word units</summary>
            <dl className="mt-2 space-y-2 font-mono text-xs">
              {current.wordUnits.map((unit, axis) => (
                <div key={axis}>
                  <dt className="text-muted">
                    {AXIS_NAMES[axis]}[{current.coords[axis].toString()}]
                  </dt>
                  <dd className="break-all">{pixelHex(unit)}</dd>
                </div>
              ))}
            </dl>
          </details>
        </div>
      </div>

      <details className="mt-4 border-y border-rule py-3">
        <summary className="font-mono text-sm text-signal">Model and slice setup</summary>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <label className="font-mono text-xs text-muted">
            Evolution{" "}
            <select
              aria-label="Evolution"
              className={input}
              disabled={busy}
              value={draft.mode}
              onChange={(e) =>
                setDraft((d) => ({ ...d, mode: e.target.value as SliceConfig["mode"] }))
              }
            >
              <option value="cell">Single cells</option>
              <option value="pair">Coupled neighbors</option>
            </select>
          </label>
          <label className="font-mono text-xs text-muted">
            Word recipe seed (generated axes){" "}
            <input
              className={input}
              disabled={busy || importedCount === 5}
              value={draft.seed}
              onChange={(e) => setDraft((d) => ({ ...d, seed: e.target.value }))}
            />
          </label>
          <label className="font-mono text-xs text-muted">
            Cell coefficient κ{" "}
            <input
              className={input}
              disabled={busy}
              value={draft.kappa}
              onChange={(e) => setDraft((d) => ({ ...d, kappa: e.target.value }))}
            />
          </label>
          <label className="font-mono text-xs text-muted">
            Coupling λ{" "}
            <input
              className={input}
              disabled={busy || draft.mode === "cell"}
              value={draft.coupling}
              onChange={(e) => setDraft((d) => ({ ...d, coupling: e.target.value }))}
            />
          </label>
          <label className="font-mono text-xs text-muted">
            Coupling axis{" "}
            <AxisSelect
              label="Coupling axis"
              className={input}
              value={draft.couplingAxis}
              disabled={busy || draft.mode === "cell"}
              onChange={(axis) => setDraft((d) => ({ ...d, couplingAxis: axis }))}
            />
          </label>
          <label className="font-mono text-xs text-muted">
            Slice size{" "}
            <select
              aria-label="Slice size"
              className={input}
              disabled={busy}
              value={draft.size}
              onChange={(e) => setDraft((d) => ({ ...d, size: Number(e.target.value) }))}
            >
              {[1, 2, 4, 8, 16, 32].map((n) => (
                <option key={n} value={n}>
                  {n} × {n}
                </option>
              ))}
            </select>
          </label>
          <label className="font-mono text-xs text-muted">
            Horizontal axis{" "}
            <AxisSelect
              label="Horizontal axis"
              className={input}
              disabled={busy}
              value={draft.axes[0]}
              onChange={(axis) => chooseAxis(0, axis)}
            />
          </label>
          <label className="font-mono text-xs text-muted">
            Vertical axis{" "}
            <AxisSelect
              label="Vertical axis"
              className={input}
              disabled={busy}
              value={draft.axes[1]}
              onChange={(axis) => chooseAxis(1, axis)}
            />
          </label>
          {([0, 1] as const).map((slot) => (
            <label key={slot} className="font-mono text-xs text-muted">
              {slot === 0 ? "Horizontal" : "Vertical"} origin{" "}
              <input
                className={input}
                disabled={busy}
                value={draft.origin[slot]}
                onChange={(e) =>
                  setDraft((d) => {
                    const origin: [string, string] = [...d.origin];
                    origin[slot] = e.target.value;
                    return { ...d, origin };
                  })
                }
              />
            </label>
          ))}
          {[0, 1, 2, 3, 4]
            .filter((axis) => !draft.axes.includes(axis))
            .map((axis) => (
              <label key={axis} className="font-mono text-xs text-muted">
                Fixed {AXIS_NAMES[axis]} coordinate{" "}
                <input
                  className={input}
                  disabled={busy}
                  value={draft.fixed[axis]}
                  onChange={(e) =>
                    setDraft((d) => {
                      const fixed: FiveStrings = [...d.fixed];
                      fixed[axis] = e.target.value;
                      return { ...d, fixed };
                    })
                  }
                />
              </label>
            ))}
        </div>
        <button type="button" className={button + " mt-3"} disabled={busy} onClick={applySetup}>
          Apply setup and restart
        </button>
        <p className="mt-2 text-xs text-muted">
          The cell uses two 80-bit finite-field coordinates, packed exactly into Pixel160. Coupling
          joins adjacent pairs on the chosen word axis; an odd-length word ends with one independent
          cell.
        </p>
      </details>
      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="button"
          className={button}
          disabled={busy}
          onClick={() => void download("tiff")}
        >
          Export TIFF slice
        </button>
        <button
          type="button"
          className={button}
          disabled={busy}
          onClick={() => void download("bundle")}
        >
          Export replay bundle
        </button>
      </div>
      <p className="mt-2 text-xs text-muted">
        {slice.cells.length.toLocaleString()} observed cells ·{" "}
        {slice.manifest.slice.evaluatedCells.toLocaleString()} dependency cells evaluated. The five
        word lengths determine the virtual cube; only this slice is materialized.
      </p>
      {notice ? (
        <p className="mt-2 font-mono text-xs text-signal" role="status">
          {notice}
        </p>
      ) : null}
      {error ? (
        <p className="mt-3 break-words border border-oxide p-3 text-sm text-oxide" role="alert">
          {error}
        </p>
      ) : null}
    </section>
  );
}
function fitImportedWords(config: SliceConfig): SliceConfig {
  const dimensions = dimensionsOf(config);
  const limit =
    dimensions[config.axes[0]] < dimensions[config.axes[1]]
      ? dimensions[config.axes[0]]
      : dimensions[config.axes[1]];
  const size = [32, 16, 8, 4, 2, 1].find((n) => n <= config.size && BigInt(n) <= limit)!;
  const fixed = config.fixed.map((value, axis) => {
    const n = BigInt(value),
      max = dimensions[axis] - 1n;
    return (n > max ? max : n).toString();
  }) as FiveStrings;
  const origin = config.origin.map((value, slot) => {
    const n = BigInt(value),
      max = dimensions[config.axes[slot]] - BigInt(size);
    return (n > max ? max : n).toString();
  }) as [string, string];
  return validateConfig({ ...config, size, fixed, origin });
}
function StateValue({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-muted">{label}</dt>
      <dd className="mt-1 break-all">{value}</dd>
    </div>
  );
}
function AxisSelect({
  label,
  value,
  onChange,
  className,
  disabled = false,
}: {
  label: string;
  value: number;
  onChange: (n: number) => void;
  className: string;
  disabled?: boolean;
}) {
  return (
    <select
      aria-label={label}
      className={className}
      value={value}
      disabled={disabled}
      onChange={(e) => onChange(Number(e.target.value))}
    >
      {AXIS_NAMES.map((name, axis) => (
        <option key={axis} value={axis}>
          {name[0].toUpperCase() + name.slice(1)}
        </option>
      ))}
    </select>
  );
}
function PhaseTile({
  slice,
  column,
  row,
  onSelect,
}: {
  slice: SliceResult;
  column: number;
  row: number;
  onSelect: (column: number, row: number) => void;
}) {
  const canvas = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const target = canvas.current;
    if (!target) return;
    const ctx = target.getContext("2d");
    if (!ctx) return;
    const scale = 12,
      size = slice.config.size;
    target.width = size * scale;
    target.height = size * scale;
    slice.pixels.forEach((pixel, index) => {
      ctx.fillStyle = `hsl(${(pixel[4] / 2 ** 32) * 360} 65% 42%)`;
      ctx.fillRect((index % size) * scale, Math.floor(index / size) * scale, scale, scale);
    });
    ctx.strokeStyle = getComputedStyle(target).getPropertyValue("--color-ink").trim() || "#eceae2";
    ctx.lineWidth = 2;
    ctx.strokeRect(column * scale + 1, row * scale + 1, scale - 2, scale - 2);
  }, [slice, column, row]);
  return (
    <canvas
      ref={canvas}
      className="aspect-square w-full border border-rule"
      style={{ imageRendering: "pixelated" }}
      role="img"
      aria-label={`RUSSL L8 phase slice at step ${slice.config.tick}; selected column ${column}, row ${row}`}
      onClick={(event) => {
        const rect = event.currentTarget.getBoundingClientRect(),
          size = slice.config.size;
        onSelect(
          Math.max(
            0,
            Math.min(size - 1, Math.floor(((event.clientX - rect.left) / rect.width) * size)),
          ),
          Math.max(
            0,
            Math.min(size - 1, Math.floor(((event.clientY - rect.top) / rect.height) * size)),
          ),
        );
      }}
    >
      The slice phase is shown as colors. Use column and row controls to select a cell.
    </canvas>
  );
}
