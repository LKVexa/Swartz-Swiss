import { anti, modPow2 } from "./ops.ts";

export type Mono = { k: bigint; a: bigint; b: bigint };

export type ProcedureReport = {
  modulus: string;
  residue: string;
  anti: string;
  forward: Mono;
  inverse: Mono;
  relationHolds: boolean;
  leftInverse: boolean;
  rightInverse: boolean;
  holds: boolean;
};

function mod(value: bigint, modulus: bigint): bigint {
  const residue = value % modulus;
  return residue < 0n ? residue + modulus : residue;
}

export function multiply(left: Mono, right: Mono, modulus: bigint): Mono {
  return {
    k: mod(left.k + right.k + right.a * left.b, modulus),
    a: mod(left.a + right.a, modulus),
    b: mod(left.b + right.b, modulus),
  };
}

function same(left: Mono, right: Mono): boolean {
  return left.k === right.k && left.a === right.a && left.b === right.b;
}

const IDENTITY: Mono = { k: 0n, a: 0n, b: 0n };

export function quantumProcedure(word: bigint, width: number): ProcedureReport {
  const modulus = 1n << BigInt(width);
  const residue = modPow2(word, width);
  const partner = anti(residue, width);
  const omega: Mono = { k: 1n, a: 0n, b: 0n };
  const ex: Mono = { k: 0n, a: 1n, b: 0n };
  const zee: Mono = { k: 0n, a: 0n, b: 1n };
  const forward = multiply({ k: 0n, a: 0n, b: residue }, ex, modulus);
  const inverse: Mono = { k: 0n, a: modulus - 1n, b: partner };
  const relationHolds = same(multiply(zee, ex, modulus), multiply(omega, multiply(ex, zee, modulus), modulus));
  const rightInverse = same(multiply(forward, inverse, modulus), IDENTITY);
  const leftInverse = same(multiply(inverse, forward, modulus), IDENTITY);
  return {
    modulus: modulus.toString(),
    residue: residue.toString(),
    anti: partner.toString(),
    forward,
    inverse,
    relationHolds,
    leftInverse,
    rightInverse,
    holds: relationHolds && leftInverse && rightInverse && anti(partner, width) === residue,
  };
}

export function monomialMatrix(mono: Mono, width: number): (number | null)[][] {
  const modulus = 1n << BigInt(width);
  const order = Number(modulus);
  const rows: (number | null)[][] = Array.from({ length: order }, () => Array<number | null>(order).fill(null));
  for (let column = 0; column < order; column++) {
    const source = BigInt(column);
    const target = Number(mod(source + mono.a, modulus));
    rows[target][column] = Number(mod(mono.k + mono.b * source, modulus));
  }
  return rows;
}

export function matrixProduct(left: (number | null)[][], right: (number | null)[][]): (number | null)[][] {
  const order = right.length;
  const rows: (number | null)[][] = Array.from({ length: order }, () => Array<number | null>(order).fill(null));
  for (let column = 0; column < order; column++) {
    let through = -1;
    let phase = 0;
    for (let row = 0; row < order; row++) {
      const entry = right[row][column];
      if (entry !== null) {
        through = row;
        phase = entry;
      }
    }
    if (through < 0) continue;
    for (let row = 0; row < order; row++) {
      const entry = left[row][through];
      if (entry !== null) rows[row][column] = (entry + phase) % order;
    }
  }
  return rows;
}

export function isIdentity(rows: (number | null)[][]): boolean {
  return rows.every((row, index) => row.every((entry, column) => (index === column ? entry === 0 : entry === null)));
}
