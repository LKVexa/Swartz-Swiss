import assert from "node:assert/strict";
import test from "node:test";
import { exactTransform, ntt } from "./ntt.ts";

test("the length-32 transform over GF(97) is exact", () => {
  const signal = Array.from({ length: 32 }, (_, index) => (index * 3 + 1) % 97);
  const back = ntt(ntt(signal, false), true);
  assert.deepEqual(back, signal);
  const report = exactTransform([13n, 243n, 0n, 255n]);
  assert.equal(report.holds, true);
  assert.equal(report.prime, "97");
});
