export function gpuAverageSigns(cpu: readonly number[], gpu: readonly number[]): number[] | null {
  if (typeof document === "undefined") return null;
  const canvas = document.createElement("canvas");
  const gl = canvas.getContext("webgl", { antialias: false, preserveDrawingBuffer: true });
  if (!gl) return null;
  const n = cpu.length;
  canvas.width = n;
  canvas.height = 1;
  const verts = gl.createShader(gl.VERTEX_SHADER);
  const frags = gl.createShader(gl.FRAGMENT_SHADER);
  if (!verts || !frags) return null;
  gl.shaderSource(verts, "attribute vec2 pos; varying vec2 uv; void main(){ uv = pos * 0.5 + 0.5; gl_Position = vec4(pos, 0.0, 1.0); }");
  gl.shaderSource(
    frags,
    "precision mediump float; uniform sampler2D signs; uniform float n; varying vec2 uv; void main(){ float x = (floor(uv.x * n) + 0.5) / n; vec4 s = texture2D(signs, vec2(x, 0.5)); gl_FragColor = vec4((s.r + s.g) * 0.5, 0.0, 0.0, 1.0); }",
  );
  gl.compileShader(verts);
  gl.compileShader(frags);
  if (!gl.getShaderParameter(verts, gl.COMPILE_STATUS) || !gl.getShaderParameter(frags, gl.COMPILE_STATUS)) return null;
  const program = gl.createProgram();
  if (!program) return null;
  gl.attachShader(program, verts);
  gl.attachShader(program, frags);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return null;
  gl.useProgram(program);
  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  const pos = gl.getAttribLocation(program, "pos");
  gl.enableVertexAttribArray(pos);
  gl.vertexAttribPointer(pos, 2, gl.FLOAT, false, 0, 0);
  const data = new Uint8Array(n * 4);
  for (let index = 0; index < n; index++) {
    data[index * 4] = cpu[index] > 0 ? 255 : 0;
    data[index * 4 + 1] = gpu[index] > 0 ? 255 : 0;
    data[index * 4 + 3] = 255;
  }
  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, n, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
  gl.uniform1f(gl.getUniformLocation(program, "n"), n);
  gl.viewport(0, 0, n, 1);
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  const pixels = new Uint8Array(n * 4);
  gl.readPixels(0, 0, n, 1, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
  return Array.from({ length: n }, (_, index) => {
    const red = pixels[index * 4];
    if (red > 200) return 1;
    if (red < 40) return -1;
    return 0;
  });
}
