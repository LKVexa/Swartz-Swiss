import { createFileRoute } from "@tanstack/react-router";
import { StackSpecView } from "@/components/stack-spec";

export const Route = createFileRoute("/spec")({ component: StackSpecView });
