//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ErtTIUak.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Codex/2026-10-10/ple-3/outputs/RUSSL_GFM_Workbench/src/routes/__root.tsx",
		children: ["/", "/spec"],
		preloads: ["/assets/index-CuGKBlbs.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CuGKBlbs.js"
		} }]
	},
	"/": {
		filePath: "D:/Codex/2026-10-10/ple-3/outputs/RUSSL_GFM_Workbench/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BBttAM_E.js"]
	},
	"/spec": {
		filePath: "D:/Codex/2026-10-10/ple-3/outputs/RUSSL_GFM_Workbench/src/routes/spec.tsx",
		children: void 0,
		preloads: ["/assets/spec-sb3T6AOG.js"]
	}
} });
//#endregion
export { tsrStartManifest };
