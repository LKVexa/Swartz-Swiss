import assert from "node:assert/strict";
import test from "node:test";
import { fieldOf, gfMul, gfPow, productTable } from "./galois.ts";

test("GF(4) matches the polynomial x^2 + x + 1", () => {
  assert.equal(gfMul(2n, 2n, 2), 3n);
  assert.equal(gfMul(2n, 3n, 2), 1n);
});

test("field negation is not the ring anti-word", () => {
  for (const bits of [8, 16, 32]) {
    const report = fieldOf(13n, bits);
    assert.equal(report.holds, true);
    assert.equal(report.negationAgrees, false);
    assert.notEqual(report.fieldSum, "0");
    assert.equal(report.product, "1");
    assert.equal(gfPow(2n, (1n << BigInt(bits)) - 1n, bits), 1n);
  }
});

test("the product table is the field multiplication", () => {
  const table = productTable(3);
  assert.equal(table.length, 8);
  assert.equal(table[0].every((entry) => entry === 0), true);
  assert.equal(table[1][5], 5);
  assert.equal(table[2][2], Number(gfMul(2n, 2n, 3)));
});
